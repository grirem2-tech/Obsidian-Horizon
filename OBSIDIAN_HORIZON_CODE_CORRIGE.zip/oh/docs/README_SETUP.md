# OBSIDIAN HORIZON — Setup des scripts

## Autoloads à déclarer (Project Settings → Autoload)

| Nom          | Chemin du script          | Description                    |
|--------------|---------------------------|--------------------------------|
| `Inventaire` | `res://autoloads/inventaire.gd`     | Inventaire, or, équipement     |
| `Titres`     | `res://autoloads/titres.gd`         | Catalogue + progression titres |
| `Competences`| `res://autoloads/competences.gd`    | Catalogue compétences          |

**Ordre recommandé** : Inventaire → Titres → Competences

## Scripts joueur / UI

- `player.gd` → attacher au CharacterBody3D du joueur
- `inventaire_ui.gd` → attacher à un Control racine (ex: InventaireUI.tscn)
- `titres_ui.gd` → chargé dynamiquement par l’onglet Titre

## Fonctionnalités déjà en place

### Inventaire
- Grille 8×5 + barre rapide 9 cases
- Équipement (casque, collier, 4 anneaux, plastron, bouclier, jambières, bottes, 2 armes)
- Or + signal pour le titre Millionnaire
- `vider_sauf_equipement_base()` pour la mort

### Titres
- ~45 titres déjà définis (compteur / seuil / manuel)
- Secrets (affichage « ??? »)
- Boost +50 % d’efficacité en mode Gnome sur les effets positifs

### Compétences
- Passifs de base (Peau de métal/pierre/diamant, Médecin, Résistant, Monstre, Cannibale, Omnivore, Nictalope…)
- Ligne Forgeron (Apprenti → Chevronné → Maître)
- Easter Eggs : Route du Sacrifice, Dernier Rempart, Zombie, Berserker, Archimage, Doppelgänger
- Quelques actives exemples (Boule de feu, Soin, Dash, Cri de guerre)

### Joueur
- Calcul dynamique des stats (titres + compétences passives)
- Mode Gnome complet
- Mort normale + Route Divine (permadeath)
- Respawn Guilde / Base

## Prochaines étapes recommandées

1. **Système de combat** (dégâts, critiques, application des bonus conditionnels)
2. **Cycle jour/nuit** + appels aux titres liés
3. **Branchement complet de la forge au système d’équipement/combat**
4. **Construction de base** (template de fondation)
5. **UI Compétences** (équipement des 5+5 slots)
6. **Bestiaire**
7. **Sauvegarde** (titres + compétences + inventaire + flags secrets)

## Notes de design respectées

- Pas de niveaux classiques → uniquement % via titres/compétences/objets
- Titres permanents même à la mort
- Mode Gnome = malus extrêmes représentés par des multiplicateurs valides + boost titres
- Route Divine = mort permanente
- Secrets et conditions manuelles laissés aux systèmes concernés

## Monde & Déplacement

### Scripts
| Fichier | Rôle |
|---------|------|
| `joueur/controleur_deplacement.gd` | Contrôleur FPS (ZQSD/WASD, souris, saut, accroupi, course) |
| `world_manager.gd` | Streaming de chunks + wrap-around nord/sud/est/ouest |
| `chunk.gd` | Terrain low-poly procédural (style Tunic) |
| `world_streamer.gd` | Téléportation soft aux bords pour garder les coords propres |

### Mise en place scène
1. Créer une scène principale (`Main.tscn` ou `World.tscn`)
2. Ajouter un nœud `WorldManager` (script `world_manager.gd`) + le mettre dans le groupe `world_manager`
3. Ajouter `WorldStreamer` comme enfant et lui donner le path du WorldManager
4. Le joueur (CharacterBody3D) doit être dans le groupe `joueur`
5. Pour le mouvement : `player.gd` utilise `joueur/controleur_deplacement.gd` en composition. Le contrôleur est créé automatiquement par `Player` s'il n'existe pas déjà dans la scène.

### Input Map recommandée
- `move_forward` → Z / W
- `move_back` → S
- `move_left` → Q / A
- `move_right` → D
- `jump` → Espace
- `sprint` → Shift
- `crouch` → Ctrl
- `interact` → E

### Paramètres monde (WorldManager)
- `CHUNK_SIZE` = 64
- `WORLD_SIZE_CHUNKS` = 32 (→ monde de 2048×2048 unités)
- `VIEW_RADIUS` = 3 / `PRELOAD_RADIUS` = 4
- Change `bruit.seed` pour un autre relief

### Principe du sans-barrière
Le monde est **toroïdal** :
- Tu marches vers le nord extrême → les chunks du sud extrême se chargent devant toi
- Pareil pour est/ouest
- Aucun mur invisible, le terrain se continue naturellement
