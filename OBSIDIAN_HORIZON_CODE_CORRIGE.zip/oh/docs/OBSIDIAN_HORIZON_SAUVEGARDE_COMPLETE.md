# OBSIDIAN HORIZON — Sauvegarde complète du code

**Date :** 2026-09-19 05:02  
**Projet :** Obsidian Horizon (Godot / GDScript)  
**Usage :** Archive pour relecture / reprise de session. Coller les scripts dans `res://` selon le README.

---

## Sommaire des fichiers

| Fichier | Rôle |
|---------|------|
| README_SETUP.md | Installation Autoloads + contrôles |
| player.gd | Joueur unifié (stats, FPS, combat, mort) |
| player_controller.gd | Ancien contrôleur FPS (réf. / fusionné dans player) |
| titres.gd | Autoload Titres |
| titres_ui.gd | UI onglet Titres |
| competences.gd | Autoload Compétences |
| inventaire.gd | Autoload Inventaire |
| inventaire_ui.gd | UI Inventaire |
| forge.gd | Autoload Forge (minerais, RNG, secondaire) |
| forge_ui.gd | UI Forge par étapes |
| ennemi.gd | Ennemi basique (loup) |
| ressource_node.gd | Arbres / minerais récoltables |
| chunk.gd | Terrain low-poly + peuplement |
| world_manager.gd | Streaming + monde toroïdal |
| world_streamer.gd | Wrap joueur aux bords |
| hud.gd | HUD PV / PM / or |
| main.gd | Bootstrap scène principale |

### Autoloads à déclarer
1. `Inventaire` → inventaire.gd  
2. `Titres` → titres.gd  
3. `Competences` → competences.gd  
4. `Forge` → forge.gd  

---



============================================================
## FICHIER : `README_SETUP.md`
============================================================

```markdown
# OBSIDIAN HORIZON — Setup des scripts

## Autoloads à déclarer (Project Settings → Autoload)

| Nom          | Chemin du script          | Description                    |
|--------------|---------------------------|--------------------------------|
| `Inventaire` | `res://inventaire.gd`     | Inventaire, or, équipement     |
| `Titres`     | `res://titres.gd`         | Catalogue + progression titres |
| `Competences`| `res://competences.gd`    | Catalogue compétences          |

**Ordre recommandé** : Inventaire → Titres → Competences

## Scripts joueur / UI

- `player.gd` → attacher au CharacterBody3D du joueur
- `inventaire_ui.gd` → attacher à un Control racine (ex: InventaireUI.tscn)
- `titres_ui.gd` → chargé dynamiquement par l’onglet Titre

## Fonctionnalités déjà en place

### Inventaire
- Grille 8×5 + barre rapide 9 cases
- Équipement (casque, collier, 4 anneaux, plastron, bouclier, jambières, bottes, 2 armes)
- Or + signal pour le titre Millionnaire
- `vider_sauf_equipement_base()` pour la mort

### Titres
- ~45 titres déjà définis (compteur / seuil / manuel)
- Secrets (affichage « ??? »)
- Boost +50 % d’efficacité en mode Gnome sur les effets positifs

### Compétences
- Passifs de base (Peau de métal/pierre/diamant, Médecin, Résistant, Monstre, Cannibale, Omnivore, Nictalope…)
- Ligne Forgeron (Apprenti → Chevronné → Maître)
- Easter Eggs : Route du Sacrifice, Dernier Rempart, Zombie, Berserker, Archimage, Doppelgänger
- Quelques actives exemples (Boule de feu, Soin, Dash, Cri de guerre)

### Joueur
- Calcul dynamique des stats (titres + compétences passives)
- Mode Gnome complet
- Mort normale + Route Divine (permadeath)
- Respawn Guilde / Base

## Prochaines étapes recommandées

1. **Système de combat** (dégâts, critiques, application des bonus conditionnels)
2. **Cycle jour/nuit** + appels aux titres liés
3. **Système de forge / craft**
4. **Construction de base** (template de fondation)
5. **UI Compétences** (équipement des 5+5 slots)
6. **Bestiaire**
7. **Sauvegarde** (titres + compétences + inventaire + flags secrets)

## Notes de design respectées

- Pas de niveaux classiques → uniquement % via titres/compétences/objets
- Titres permanents même à la mort
- Mode Gnome = debuffs extrêmes + boost titres
- Route Divine = mort permanente
- Secrets et conditions manuelles laissés aux systèmes concernés

## Monde & Déplacement (nouveaux)

### Scripts
| Fichier | Rôle |
|---------|------|
| `player_controller.gd` | Contrôleur FPS (ZQSD/WASD, souris, saut, accroupi, course) |
| `world_manager.gd` | Streaming de chunks + wrap-around nord/sud/est/ouest |
| `chunk.gd` | Terrain low-poly procédural (style Tunic) |
| `world_streamer.gd` | Téléportation soft aux bords pour garder les coords propres |

### Mise en place scène
1. Créer une scène principale (`Main.tscn` ou `World.tscn`)
2. Ajouter un nœud `WorldManager` (script `world_manager.gd`) + le mettre dans le groupe `world_manager`
3. Ajouter `WorldStreamer` comme enfant et lui donner le path du WorldManager
4. Le joueur (CharacterBody3D) doit être dans le groupe `joueur`
5. Pour le mouvement : soit fusionner `player_controller.gd` dans `player.gd`, soit faire hériter le joueur de PlayerController et garder les stats dans un nœud enfant / composant

### Input Map recommandée
- `move_forward` → Z / W
- `move_back` → S
- `move_left` → Q / A
- `move_right` → D
- `jump` → Espace
- `sprint` → Shift
- `crouch` → Ctrl
- `interact` → E

### Paramètres monde (WorldManager)
- `CHUNK_SIZE` = 64
- `WORLD_SIZE_CHUNKS` = 32 (→ monde de 2048×2048 unités)
- `VIEW_RADIUS` = 3 / `PRELOAD_RADIUS` = 4
- Change `bruit.seed` pour un autre relief

### Principe du sans-barrière
Le monde est **toroïdal** :
- Tu marches vers le nord extrême → les chunks du sud extrême se chargent devant toi
- Pareil pour est/ouest
- Aucun mur invisible, le terrain se continue naturellement

```


============================================================
## FICHIER : `player.gd`
============================================================

```gdscript
extends CharacterBody3D
class_name Player

# ==========================================================
#  OBSIDIAN HORIZON — Joueur unifié
#  Stats / Titres / Compétences + FPS + Combat léger
# ==========================================================

# ----------------------------------------------------------
#  STATISTIQUES DE BASE
# ----------------------------------------------------------
@export_group("Statistiques de base")
@export var PV_max: float = 100.0
var PV_actuels: float = 100.0

@export var PM_max: float = 50.0
var PM_actuels: float = 50.0

@export var vitesse_deplacement: float = 5.0
@export var degats_base: float = 10.0
@export var taux_drop: float = 1.0

# ----------------------------------------------------------
#  BUILD
# ----------------------------------------------------------
@export_group("Système de Build")
var titres_debloques: Array[Dictionary] = []
const MAX_SLOTS_ACTIFS: int = 5
var competences_actives: Array = []
const MAX_SLOTS_PASSIFS: int = 5
var competences_passives: Array = []
var reputation_pnj: Dictionary = {
	"prix_multiplicateur": 1.0,
	"taxe_garde": 0.0
}

# ----------------------------------------------------------
#  MODE GNOME
# ----------------------------------------------------------
@export_group("Mode Gnome Caché")
var est_gnome: bool = false
var degats_finaux: float = 0.0
var vitesse_finale: float = 0.0
var taux_drop_final: float = 0.0
var multiplicateur_prix_final: float = 1.0
var bonus_generique: Dictionary = {}
var bonus_degats_contre: Dictionary = {}
var bonus_reduction_degats_recus_de: Dictionary = {}

# ----------------------------------------------------------
#  MORT / TOUR
# ----------------------------------------------------------
@export_group("Mort et Respawn")
var etage_actuel: int = 0
var possede_une_base: bool = false
var en_route_divine: bool = false

# ----------------------------------------------------------
#  FPS — RÉFÉRENCES & PARAMÈTRES
# ----------------------------------------------------------
@export_group("Déplacement FPS")
@export var vitesse_course_mult: float = 1.45
@export var vitesse_accroupi_mult: float = 0.45
@export var force_saut: float = 6.5
@export var gravite: float = 18.0
@export var acceleration: float = 14.0
@export var friction: float = 12.0
@export var sensibilite_souris: float = 0.12
@export var distance_interaction: float = 3.5

@export_group("Combat")
@export var portee_attaque: float = 2.8
@export var cooldown_attaque: float = 0.45
@export var degats_sans_arme_mult: float = 0.6

var head: Node3D
var camera: Camera3D
var ray_interact: RayCast3D
var ray_attaque: RayCast3D

var rotation_x: float = 0.0
var rotation_y: float = 0.0
var est_accroupi: bool = false
var direction_visee: Vector3 = Vector3.FORWARD
var _timer_attaque: float = 0.0
var invulnerable_timer: float = 0.0


func _ready() -> void:
	add_to_group("joueur")
	PV_actuels = PV_max
	PM_actuels = PM_max
	_assurer_structure_camera()
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	calculer_stats_finales()


func _assurer_structure_camera() -> void:
	if not has_node("Head"):
		head = Node3D.new()
		head.name = "Head"
		head.position = Vector3(0, 1.65, 0)
		add_child(head)
	else:
		head = $Head

	if not head.has_node("Camera3D"):
		camera = Camera3D.new()
		camera.name = "Camera3D"
		camera.current = true
		camera.fov = 75.0
		head.add_child(camera)
	else:
		camera = head.get_node("Camera3D")

	if not camera.has_node("RayInteract"):
		ray_interact = RayCast3D.new()
		ray_interact.name = "RayInteract"
		ray_interact.target_position = Vector3(0, 0, -distance_interaction)
		ray_interact.enabled = true
		ray_interact.collide_with_areas = true
		camera.add_child(ray_interact)
	else:
		ray_interact = camera.get_node("RayInteract")

	if not camera.has_node("RayAttaque"):
		ray_attaque = RayCast3D.new()
		ray_attaque.name = "RayAttaque"
		ray_attaque.target_position = Vector3(0, 0, -portee_attaque)
		ray_attaque.enabled = true
		camera.add_child(ray_attaque)
	else:
		ray_attaque = camera.get_node("RayAttaque")


# ==========================================================
#  INPUT & PHYSIQUE
# ==========================================================
func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		rotation_y -= event.relative.x * sensibilite_souris
		rotation_x -= event.relative.y * sensibilite_souris
		rotation_x = clampf(rotation_x, -89.0, 89.0)
		head.rotation_degrees.x = rotation_x
		rotation_degrees.y = rotation_y

	if event.is_action_pressed("ui_cancel"):
		Input.mouse_mode = (
			Input.MOUSE_MODE_VISIBLE
			if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED
			else Input.MOUSE_MODE_CAPTURED
		)


func _physics_process(delta: float) -> void:
	if invulnerable_timer > 0.0:
		invulnerable_timer -= delta
	if _timer_attaque > 0.0:
		_timer_attaque -= delta

	_appliquer_gravite(delta)
	_gerer_saut()
	_gerer_accroupi()
	_deplacer(delta)
	move_and_slide()

	if camera:
		direction_visee = -camera.global_transform.basis.z

	# Attaque clic gauche
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) and _timer_attaque <= 0.0:
		_attaquer()

	# Interaction E
	if Input.is_physical_key_pressed(KEY_E):
		_tenter_interaction()


func _deplacer(delta: float) -> void:
	var input_dir := Vector2.ZERO
	if Input.is_physical_key_pressed(KEY_Z) or Input.is_physical_key_pressed(KEY_W):
		input_dir.y -= 1
	if Input.is_physical_key_pressed(KEY_S):
		input_dir.y += 1
	if Input.is_physical_key_pressed(KEY_Q) or Input.is_physical_key_pressed(KEY_A):
		input_dir.x -= 1
	if Input.is_physical_key_pressed(KEY_D):
		input_dir.x += 1
	input_dir = input_dir.limit_length(1.0)

	var direction := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()

	var vitesse_cible: float = vitesse_finale if vitesse_finale > 0.0 else vitesse_deplacement
	if Input.is_physical_key_pressed(KEY_SHIFT) and not est_accroupi:
		vitesse_cible *= vitesse_course_mult
	elif est_accroupi:
		vitesse_cible *= vitesse_accroupi_mult

	# Bonus conditionnels (ex: vitesse hors combat, PV bas…)
	vitesse_cible *= (1.0 + obtenir_bonus("vitesse_hors_combat_pourcent") / 100.0)

	if direction != Vector3.ZERO:
		velocity.x = lerpf(velocity.x, direction.x * vitesse_cible, acceleration * delta)
		velocity.z = lerpf(velocity.z, direction.z * vitesse_cible, acceleration * delta)
	else:
		velocity.x = lerpf(velocity.x, 0.0, friction * delta)
		velocity.z = lerpf(velocity.z, 0.0, friction * delta)


func _appliquer_gravite(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= gravite * delta
	elif velocity.y < 0.0:
		velocity.y = 0.0


func _gerer_saut() -> void:
	if (Input.is_physical_key_pressed(KEY_SPACE) or Input.is_action_just_pressed("ui_accept")) and is_on_floor() and not est_accroupi:
		velocity.y = force_saut


func _gerer_accroupi() -> void:
	var veut := Input.is_physical_key_pressed(KEY_CTRL)
	if veut != est_accroupi:
		est_accroupi = veut
		if head:
			head.position.y = 1.05 if est_accroupi else 1.65


# ==========================================================
#  COMBAT
# ==========================================================
func _attaquer() -> void:
	_timer_attaque = cooldown_attaque

	var degats := degats_finaux if degats_finaux != 0.0 else degats_base
	# Sans arme équipée → malus (titre Poing d'acier peut compenser)
	var a_une_arme := false
	if Inventaire and Inventaire.equipement.get("arme_principale") != null:
		a_une_arme = true
	if not a_une_arme:
		degats *= degats_sans_arme_mult
		degats *= (1.0 + obtenir_bonus("degats_pourcent_sans_arme") / 100.0)

	if ray_attaque and ray_attaque.is_colliding():
		var cible = ray_attaque.get_collider()
		if cible and cible.has_method("recevoir_degats"):
			# Bonus contre catégorie / id
			var bonus_ciblé := 0.0
			if "id_mob" in cible:
				bonus_ciblé += obtenir_bonus_degats_contre(cible.id_mob)
			if "categories" in cible:
				for cat in cible.categories:
					bonus_ciblé += obtenir_bonus_degats_contre(cat)
			degats *= (1.0 + bonus_ciblé / 100.0)

			# Conditionnel PV haut (titre Boucher)
			if "PV_actuels" in cible and "PV_max" in cible:
				if cible.PV_actuels / maxf(cible.PV_max, 1.0) > 0.5:
					degats *= (1.0 + obtenir_bonus("degats_pourcent_contre_pv_haut") / 100.0)

			cible.recevoir_degats(degats, self)
			return

	# Coup dans le vide (feedback plus tard)
	pass


func recevoir_degats(montant: float, source: Node = null) -> void:
	if invulnerable_timer > 0.0 or PV_actuels <= 0.0:
		return

	var reduction := 0.0
	if source:
		if "id_mob" in source:
			reduction += obtenir_reduction_degats_recus_de(source.id_mob)
		if "categories" in source:
			for cat in source.categories:
				reduction += obtenir_reduction_degats_recus_de(cat)

	reduction += obtenir_bonus("defense_pourcent")
	# Conditionnel PV bas
	if PV_actuels / maxf(PV_max, 1.0) < 0.25:
		reduction += obtenir_bonus("defense_pourcent_pv_bas")

	var facteur := maxf(0.05, 1.0 - reduction / 100.0)
	var degats_finaux_recus := montant * facteur
	PV_actuels -= degats_finaux_recus
	invulnerable_timer = 0.35  # i-frames courts

	if PV_actuels <= 0.0:
		PV_actuels = 0.0
		mourir()


func soigner(montant: float) -> void:
	var bonus := 1.0 + obtenir_bonus("soins_recus_pourcent") / 100.0
	PV_actuels = minf(PV_max, PV_actuels + montant * bonus)


# ==========================================================
#  INTERACTION
# ==========================================================
func _tenter_interaction() -> void:
	if not ray_interact or not ray_interact.is_colliding():
		return
	var cible = ray_interact.get_collider()
	if cible == null:
		return
	if cible.has_method("interagir"):
		cible.interagir(self)
	elif cible.get_parent() and cible.get_parent().has_method("interagir"):
		cible.get_parent().interagir(self)


# ==========================================================
#  MODE GNOME
# ==========================================================
func activer_mode_gnome() -> void:
	if est_gnome:
		push_warning("Le mode Gnome est déjà actif.")
		return
	est_gnome = true
	degats_base *= -9.0
	vitesse_deplacement *= -9.0
	taux_drop = 0.01
	reputation_pnj["prix_multiplicateur"] *= 1.5
	calculer_stats_finales()


# ==========================================================
#  STATS
# ==========================================================
func calculer_stats_finales() -> void:
	var nouveau_bonus_generique: Dictionary = {}
	var nouveau_bonus_contre: Dictionary = {}
	var nouveau_bonus_reduction_de: Dictionary = {}

	for titre in titres_debloques:
		for effet in titre.get("effets", []):
			var type_effet: String = effet.get("type", "")
			var valeur: float = _appliquer_boost_gnome(effet.get("valeur", 0.0))
			match type_effet:
				"degats_pourcent_contre_cible":
					var c: String = effet.get("cible", "")
					nouveau_bonus_contre[c] = nouveau_bonus_contre.get(c, 0.0) + valeur
				"reduction_degats_recus_pourcent_contre_cible":
					var c2: String = effet.get("cible", "")
					nouveau_bonus_reduction_de[c2] = nouveau_bonus_reduction_de.get(c2, 0.0) + valeur
				"", "aucun_bonus", "comportemental":
					pass
				_:
					nouveau_bonus_generique[type_effet] = nouveau_bonus_generique.get(type_effet, 0.0) + valeur

	bonus_generique = nouveau_bonus_generique
	bonus_degats_contre = nouveau_bonus_contre
	bonus_reduction_degats_recus_de = nouveau_bonus_reduction_de

	if Competences:
		Competences.appliquer_passifs_au_joueur(self)

	degats_finaux = degats_base * (1.0 + obtenir_bonus("degats_pourcent") / 100.0)
	vitesse_finale = vitesse_deplacement * (1.0 + obtenir_bonus("vitesse_pourcent") / 100.0)
	taux_drop_final = taux_drop * (1.0 + obtenir_bonus("taux_drop_pourcent") / 100.0)
	multiplicateur_prix_final = reputation_pnj["prix_multiplicateur"] * (1.0 + obtenir_bonus("prix_pnj_pourcent") / 100.0)


func obtenir_bonus(type_effet: String) -> float:
	return bonus_generique.get(type_effet, 0.0)


func obtenir_bonus_degats_contre(id_cible: String) -> float:
	return bonus_degats_contre.get(id_cible, 0.0)


func obtenir_reduction_degats_recus_de(id_cible: String) -> float:
	return bonus_reduction_degats_recus_de.get(id_cible, 0.0)


func _appliquer_boost_gnome(valeur_effet: float) -> float:
	if est_gnome and valeur_effet > 0.0:
		return valeur_effet * 1.5
	return valeur_effet


# ==========================================================
#  COMPÉTENCES / TITRES
# ==========================================================
func ajouter_competence_active(competence) -> bool:
	if competences_actives.size() >= MAX_SLOTS_ACTIFS:
		return false
	competences_actives.append(competence)
	return true


func ajouter_competence_passive(competence) -> bool:
	if competences_passives.size() >= MAX_SLOTS_PASSIFS:
		return false
	competences_passives.append(competence)
	calculer_stats_finales()
	return true


func debloquer_titre(titre: Dictionary) -> void:
	titres_debloques.append(titre)
	calculer_stats_finales()


# ==========================================================
#  MORT
# ==========================================================
func mourir() -> void:
	if en_route_divine:
		_game_over_definitif()
		return

	etage_actuel = 0
	if Inventaire:
		Inventaire.vider_sauf_equipement_base()
	calculer_stats_finales()
	PV_actuels = PV_max
	PM_actuels = PM_max
	teleporter_apres_mort()


func teleporter_apres_mort() -> void:
	if possede_une_base:
		print("Respawn : Lit du joueur (Base)")
	else:
		print("Respawn : Lit de la Guilde")
		# Point de respawn par défaut au centre du monde
		global_position = Vector3(16, 20, 16)


func _game_over_definitif() -> void:
	print("GAME OVER — Route Divine : la mort est définitive.")
	set_physics_process(false)
	set_process(false)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

```


============================================================
## FICHIER : `player_controller.gd`
============================================================

```gdscript
extends CharacterBody3D
class_name PlayerController

# ==========================================================
#  OBSIDIAN HORIZON — Contrôleur FPS (déplacement + caméra)
#  À attacher au même nœud que player.gd (ou fusionner).
#  Style : vue première personne, low-poly lisible.
# ==========================================================

# ----------------------------------------------------------
#  RÉFÉRENCES
# ----------------------------------------------------------
@onready var camera: Camera3D = $Camera3D
@onready var head: Node3D = $Head          # pivot vertical de la caméra
@onready var ray_interact: RayCast3D = $Head/Camera3D/RayInteract

# ----------------------------------------------------------
#  PARAMÈTRES DE DÉPLACEMENT
# ----------------------------------------------------------
@export_group("Déplacement")
@export var vitesse_marche: float = 5.0
@export var vitesse_course: float = 8.5
@export var vitesse_accroupi: float = 2.5
@export var force_saut: float = 6.5
@export var gravite: float = 18.0
@export var acceleration: float = 12.0
@export var friction: float = 10.0

@export_group("Caméra")
@export var sensibilite_souris: float = 0.12
@export var angle_min: float = -89.0
@export var angle_max: float = 89.0
@export var lissage_camera: float = 0.0   # 0 = instantané (recommandé FPS)

@export_group("Interaction")
@export var distance_interaction: float = 3.5

# ----------------------------------------------------------
#  ÉTAT INTERNE
# ----------------------------------------------------------
var est_accroupi: bool = false
var est_en_air: bool = false
var direction_visee: Vector3 = Vector3.ZERO

# Souris
var rotation_x: float = 0.0   # pitch
var rotation_y: float = 0.0   # yaw


func _ready() -> void:
	# Capture de la souris pour le look FPS
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

	# Création automatique de la structure si absente
	_assurer_structure_camera()


func _assurer_structure_camera() -> void:
	if not has_node("Head"):
		var h := Node3D.new()
		h.name = "Head"
		h.position = Vector3(0, 1.6, 0)  # hauteur yeux
		add_child(h)
		head = h

	if not head.has_node("Camera3D"):
		var cam := Camera3D.new()
		cam.name = "Camera3D"
		cam.current = true
		cam.fov = 75.0
		head.add_child(cam)
		camera = cam

	if not camera.has_node("RayInteract"):
		var ray := RayCast3D.new()
		ray.name = "RayInteract"
		ray.target_position = Vector3(0, 0, -distance_interaction)
		ray.enabled = true
		camera.add_child(ray)
		ray_interact = ray


func _unhandled_input(event: InputEvent) -> void:
	# Look
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		rotation_y -= event.relative.x * sensibilite_souris
		rotation_x -= event.relative.y * sensibilite_souris
		rotation_x = clampf(rotation_x, angle_min, angle_max)

		# Application immédiate (ou lissée)
		head.rotation_degrees.x = rotation_x
		rotation_degrees.y = rotation_y

	# Toggle capture souris (Échap)
	if event.is_action_pressed("ui_cancel"):
		if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		else:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _physics_process(delta: float) -> void:
	_appliquer_gravite(delta)
	_gerer_saut()
	_gerer_accroupi()
	_deplacer(delta)
	move_and_slide()

	# Mise à jour de la direction de visée (utile pour le combat plus tard)
	if camera:
		direction_visee = -camera.global_transform.basis.z


# ----------------------------------------------------------
#  DÉPLACEMENT
# ----------------------------------------------------------
func _deplacer(delta: float) -> void:
	var input_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	# Fallback ZQSD / WASD si les actions ne sont pas définies
	if input_dir == Vector2.ZERO:
		input_dir = Vector2(
			Input.get_action_strength("ui_right") - Input.get_action_strength("ui_left"),
			Input.get_action_strength("ui_down") - Input.get_action_strength("ui_up")
		)
		# Mapping clavier direct si besoin
		if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_Q):
			input_dir.x -= 1
		if Input.is_key_pressed(KEY_D):
			input_dir.x += 1
		if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_Z):
			input_dir.y -= 1
		if Input.is_key_pressed(KEY_S):
			input_dir.y += 1
		input_dir = input_dir.limit_length(1.0)

	var direction := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()

	# Vitesse cible selon l'état
	var vitesse_cible: float = vitesse_marche
	if Input.is_key_pressed(KEY_SHIFT) and not est_accroupi:
		vitesse_cible = vitesse_course
	elif est_accroupi:
		vitesse_cible = vitesse_accroupi

	# Bonus / malus du joueur (titres, mode Gnome, etc.)
	if "vitesse_finale" in self:
		vitesse_cible = self.vitesse_finale
		if Input.is_key_pressed(KEY_SHIFT) and not est_accroupi:
			vitesse_cible *= 1.4   # course relative
		elif est_accroupi:
			vitesse_cible *= 0.5

	if direction != Vector3.ZERO:
		velocity.x = lerpf(velocity.x, direction.x * vitesse_cible, acceleration * delta)
		velocity.z = lerpf(velocity.z, direction.z * vitesse_cible, acceleration * delta)
	else:
		velocity.x = lerpf(velocity.x, 0.0, friction * delta)
		velocity.z = lerpf(velocity.z, 0.0, friction * delta)


func _appliquer_gravite(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= gravite * delta
		est_en_air = true
	else:
		est_en_air = false
		if velocity.y < 0:
			velocity.y = 0


func _gerer_saut() -> void:
	if Input.is_action_just_pressed("ui_accept") or Input.is_key_pressed(KEY_SPACE):
		if is_on_floor() and not est_accroupi:
			velocity.y = force_saut


func _gerer_accroupi() -> void:
	# Ctrl pour s'accroupir
	var veut_accroupir := Input.is_key_pressed(KEY_CTRL)
	if veut_accroupir != est_accroupi:
		est_accroupi = veut_accroupir
		# Ajuste la hauteur de la caméra
		if head:
			var cible_y: float = 1.0 if est_accroupi else 1.6
			head.position.y = lerpf(head.position.y, cible_y, 0.2)


# ----------------------------------------------------------
#  INTERACTION (E)
# ----------------------------------------------------------
func _process(_delta: float) -> void:
	if Input.is_action_just_pressed("interact") or Input.is_key_pressed(KEY_E):
		_tenter_interaction()


func _tenter_interaction() -> void:
	if ray_interact and ray_interact.is_colliding():
		var cible = ray_interact.get_collider()
		if cible and cible.has_method("interagir"):
			cible.interagir(self)
		elif cible and cible.has_method("on_interact"):
			cible.on_interact(self)
		else:
			print("Objet interactif détecté : ", cible.name if cible else "null")

```


============================================================
## FICHIER : `titres.gd`
============================================================

```gdscript
extends Node

# ==========================================================
#  OBSIDIAN HORIZON — Gestionnaire des Titres
#  À déclarer en Autoload (Project Settings > Autoload) sous
#  le nom "Titres".
#
#  Principes :
#  - Un titre non débloqué est un succès caché : nom, description et
#    condition ne sont jamais exposés côté UI (voir obtenir_titres_pour_affichage).
#  - Les titres sont PERMANENTS : jamais retirés, y compris à la mort.
#  - 3 types de conditions, pour couvrir toute la fiche de conception sans
#    connaître à l'avance le détail de chaque système du jeu (combat,
#    craft, exploration...) :
#      "compteur" : une action se répète N fois (ex: 100 kills de loup).
#                   -> incrementer_progression(action, cible, contexte)
#      "seuil"    : une valeur ACTUELLE dépasse un seuil à un instant T
#                   (ex: posséder 100 000 or simultanément), pas cumulatif.
#                   -> verifier_seuil(action, valeur_actuelle)
#      "manuel"   : condition trop spécifique/évènementielle pour un suivi
#                   générique (ex: "terminer les 100 étages sans dégât").
#                   -> le système concerné appelle debloquer_titre(id)
#                   lui-même au moment où IL constate que c'est rempli.
# ==========================================================

signal titre_debloque(id_titre: String)

## Catalogue complet, y compris les titres non débloqués. Jamais exposé
## tel quel à l'UI.
var catalogue_titres: Dictionary = {}

## Ids des titres débloqués, dans l'ordre d'obtention. Permanent : à
## sauvegarder tel quel, jamais vidé (y compris à la mort).
var titres_debloques: Array[String] = []

## Progression des conditions de type "compteur", clé = id du titre
## (et non l'action seule, car deux titres peuvent suivre la même action
## avec des filtres différents, ex: "sans magie").
var progression_titres: Dictionary = {}


func _ready() -> void:
	_enregistrer_titres()


func _ajouter_titre(definition: Dictionary) -> void:
	catalogue_titres[definition["id"]] = definition


# ----------------------------------------------------------
#  SUIVI DE PROGRESSION — TYPE "compteur"
# ----------------------------------------------------------
## Point d'entrée générique à appeler depuis N'IMPORTE QUEL système quand
## une action pertinente se produit, ex :
##   Titres.incrementer_progression("tuer", "loup", ["etre_vivant", "sauvage"])
##   Titres.incrementer_progression("miner")
##   Titres.incrementer_progression("forger_reussite")
##   Titres.incrementer_progression("vaincre", "ennemi", [], {"sans_magie": true})
##
## - action    : le type d'évènement (voir la liste des "action" utilisées
##               dans _enregistrer_titres ci-dessous).
## - cible     : id précis concerné (ex: id du mob), optionnel.
## - categories: tags applicables à cet évènement (ex: ["monstre","boss"]),
##               pour les conditions qui visent une catégorie plutôt qu'un
##               id précis.
## - contexte  : infos additionnelles utilisées par les conditions qui ont
##               un filtre (ex: {"sans_magie": true}, {"seul": true},
##               {"element": "feu"}).
func incrementer_progression(action: String, cible: String = "", categories: Array = [], contexte: Dictionary = {}, quantite: int = 1) -> void:
	for id_titre in catalogue_titres.keys():
		if id_titre in titres_debloques:
			continue

		var definition: Dictionary = catalogue_titres[id_titre]
		var condition: Dictionary = definition.get("condition", {})

		if condition.get("type", "") != "compteur":
			continue
		if condition.get("action", "") != action:
			continue

		var cible_condition: String = condition.get("cible", "")
		if cible_condition != "" and cible_condition != cible and not (cible_condition in categories):
			continue

		var contexte_requis: Dictionary = condition.get("contexte_requis", {})
		var contexte_ok := true
		for cle in contexte_requis.keys():
			if contexte.get(cle) != contexte_requis[cle]:
				contexte_ok = false
				break
		if not contexte_ok:
			continue

		progression_titres[id_titre] = progression_titres.get(id_titre, 0) + quantite
		if progression_titres[id_titre] >= condition.get("quantite", 0):
			debloquer_titre(id_titre)


## Compteur actuel d'un titre de type "compteur" (utile pour un affichage
## "87 / 100" dans l'onglet Titre une fois le titre découvert).
func obtenir_progression(id_titre: String) -> int:
	return progression_titres.get(id_titre, 0)


# ----------------------------------------------------------
#  SUIVI — TYPE "seuil"
# ----------------------------------------------------------
## À appeler quand une valeur qui peut monter ET descendre change (ex: or
## possédé), pour les titres du type "Posséder simultanément X" :
##   Titres.verifier_seuil("or_possede", Inventaire.or_actuel)
func verifier_seuil(action: String, valeur_actuelle: float) -> void:
	for id_titre in catalogue_titres.keys():
		if id_titre in titres_debloques:
			continue
		var definition: Dictionary = catalogue_titres[id_titre]
		var condition: Dictionary = definition.get("condition", {})
		if condition.get("type", "") == "seuil" and condition.get("action", "") == action:
			if valeur_actuelle >= condition.get("quantite", 0):
				debloquer_titre(id_titre)


# ----------------------------------------------------------
#  DÉBLOCAGE
# ----------------------------------------------------------
## Débloque définitivement un titre et applique ses effets au joueur.
## C'est aussi le point d'entrée pour tous les titres "manuel" : le
## système qui constate la condition remplie appelle directement
## Titres.debloquer_titre("pacifiste") par exemple.
func debloquer_titre(id_titre: String) -> void:
	if id_titre in titres_debloques or not catalogue_titres.has(id_titre):
		return

	titres_debloques.append(id_titre)
	var definition: Dictionary = catalogue_titres[id_titre]

	var joueur := get_tree().get_first_node_in_group("joueur")
	if joueur != null:
		joueur.debloquer_titre(definition)
	else:
		push_warning("Titre '%s' débloqué mais aucun joueur trouvé (groupe 'joueur') pour appliquer ses effets." % id_titre)

	titre_debloque.emit(id_titre)


func est_debloque(id_titre: String) -> bool:
	return id_titre in titres_debloques


# ----------------------------------------------------------
#  AFFICHAGE (respecte le secret des titres non débloqués)
# ----------------------------------------------------------
func obtenir_titres_pour_affichage() -> Array[Dictionary]:
	var resultat: Array[Dictionary] = []

	for id_titre in catalogue_titres.keys():
		var est_deb: bool = id_titre in titres_debloques

		if est_deb:
			var definition: Dictionary = catalogue_titres[id_titre]
			resultat.append({
				"id": id_titre,
				"nom": definition["nom"],
				"description": definition["description"],
				"debloque": true,
			})
		else:
			resultat.append({
				"id": id_titre,
				"nom": "???",
				"description": "Titre non découvert.",
				"debloque": false,
			})

	return resultat


# ----------------------------------------------------------
#  CATALOGUE
# ----------------------------------------------------------
## IMPORTANT — titres marqués condition.type == "manuel" : aucun suivi
## automatique n'est possible sans connaître le détail des systèmes
## concernés (combat, cycle jour/nuit, streaks, etc.). Le bon endroit pour
## appeler Titres.debloquer_titre(id) est noté dans chaque description.
func _enregistrer_titres() -> void:
	_ajouter_titre({
		"id": "tueur_de_loups",
		"nom": "Tueur de Loups",
		"description": "Tuer 100 Loups.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "loup", "quantite": 100},
		"effets": [
			{"type": "degats_pourcent_contre_cible", "cible": "loup", "valeur": 5.0},
		],
	})

	_ajouter_titre({
		"id": "pacifiste",
		"nom": "Pacifiste",
		"description": "Terminer les 100 étages sans infliger de dégâts ni tuer. Aucun bonus direct : débloque certaines interactions pacifistes.",
		"condition": {"type": "manuel"},  # à appeler depuis le script de fin de Tour si le run entier est sans dégât/kill
		"effets": [{"type": "comportemental"}],
	})

	_ajouter_titre({
		"id": "monstre",
		"nom": "Monstre",
		"description": "Éliminer 1000 créatures vivantes. +20% dégâts contre les êtres vivants.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "etre_vivant", "quantite": 1000},
		"effets": [{"type": "degats_pourcent_contre_cible", "cible": "etre_vivant", "valeur": 20.0}],
	})

	_ajouter_titre({
		"id": "tueur_de_monstres",
		"nom": "Tueur de Monstres",
		"description": "Éliminer 100 monstres. +5% dégâts contre les monstres.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "monstre", "quantite": 100},
		"effets": [{"type": "degats_pourcent_contre_cible", "cible": "monstre", "valeur": 5.0}],
	})

	_ajouter_titre({
		"id": "boucher",
		"nom": "Boucher",
		"description": "Éliminer 500 créatures sans utiliser de magie. +15% dégâts contre les ennemis ayant plus de 50% de leurs PV.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "etre_vivant", "quantite": 500, "contexte_requis": {"sans_magie": true}},
		# "degats_pourcent_contre_pv_haut" est conditionnel (PV cible > 50%) : à consulter via
		# Player.obtenir_bonus("degats_pourcent_contre_pv_haut") depuis le calcul de dégâts du combat.
		"effets": [{"type": "degats_pourcent_contre_pv_haut", "valeur": 15.0}],
	})

	_ajouter_titre({
		"id": "massacreur",
		"nom": "Massacreur",
		"description": "Réaliser une série de 100 éliminations. +1% dégâts par ennemi tué consécutivement (max +20%), remis à zéro en quittant la zone.",
		# Streak avec reset : nécessite un compteur dédié côté combat (pas
		# un simple cumul) -> le système de combat gère lui-même le streak
		# et appelle Titres.debloquer_titre("massacreur") en atteignant 100,
		# puis applique son propre bonus progressif (indépendant de ce système).
		"condition": {"type": "manuel"},
		"effets": [{"type": "comportemental"}],  # le bonus de streak est géré en direct par le combat, pas par bonus_generique
	})

	_ajouter_titre({
		"id": "ennemi_naturel_des_dieux",
		"nom": "Ennemi Naturel des Dieux",
		"description": "Vaincre une entité divine cachée sans utiliser de compétence divine. +50% dégâts contre les entités divines et -20% dégâts reçus de celles-ci.",
		"condition": {"type": "manuel"},  # combat de boss caché spécifique -> debloquer_titre() appelé par ce combat
		"effets": [
			{"type": "degats_pourcent_contre_cible", "cible": "divin", "valeur": 50.0},
			{"type": "reduction_degats_recus_pourcent_contre_cible", "cible": "divin", "valeur": 20.0},
		],
	})

	_ajouter_titre({
		"id": "duelliste",
		"nom": "Duelliste",
		"description": "Vaincre 100 ennemis sans qu'aucun autre ennemi ne participe au combat. +15% dégâts en combat 1 contre 1.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "ennemi", "quantite": 100, "contexte_requis": {"seul": true}},
		"effets": [{"type": "degats_pourcent_duel", "valeur": 15.0}],  # conditionnel : à appliquer par le combat seulement si 1v1
	})

	_ajouter_titre({
		"id": "dernier_survivant",
		"nom": "Dernier Survivant",
		"description": "Survivre à 10 combats de groupe où tous les alliés sont tombés. +20% défense quand il ne reste qu'un seul membre vivant dans le groupe.",
		"condition": {"type": "compteur", "action": "survivre_combat_groupe", "quantite": 10, "contexte_requis": {"seul_survivant": true}},
		"effets": [{"type": "defense_pourcent_dernier_survivant", "valeur": 20.0}],
	})

	_ajouter_titre({
		"id": "chasseur",
		"nom": "Chasseur",
		"description": "Chasser 250 créatures sauvages. +10% dégâts contre les créatures sauvages.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "sauvage", "quantite": 250},
		"effets": [{"type": "degats_pourcent_contre_cible", "cible": "sauvage", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "mage",
		"nom": "Mage",
		"description": "Utiliser de la magie pour vaincre 500 ennemis. +10% dégâts magiques.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "ennemi", "quantite": 500, "contexte_requis": {"avec_magie": true}},
		"effets": [{"type": "degats_magiques_pourcent", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "pyromancien",
		"nom": "Pyromancien",
		"description": "Vaincre 100 ennemis uniquement avec des dégâts de feu. +15% dégâts de feu.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "ennemi", "quantite": 100, "contexte_requis": {"element": "feu"}},
		"effets": [{"type": "degats_feu_pourcent", "valeur": 15.0}],
	})

	_ajouter_titre({
		"id": "cryomancien",
		"nom": "Cryomancien",
		"description": "Appliquer un effet de froid 500 fois. Les effets de ralentissement appliqués par le joueur durent +25%.",
		"condition": {"type": "compteur", "action": "appliquer_effet_froid", "quantite": 500},
		"effets": [{"type": "duree_ralentissement_pourcent", "valeur": 25.0}],
	})

	_ajouter_titre({
		"id": "forgeron",
		"nom": "Forgeron",
		"description": "Réussir 100 créations à la forge. +5% chance de réussite à la forge.",
		"condition": {"type": "compteur", "action": "forger_reussite", "quantite": 100},
		"effets": [{"type": "chance_forge_pourcent", "valeur": 5.0}],
	})

	_ajouter_titre({
		"id": "maitre_artisan",
		"nom": "Maître artisan",
		"description": "Fabriquer 50 objets de qualité maximale. +10% chance de réussite à la forge et au craft avancé.",
		"condition": {"type": "compteur", "action": "craft_qualite_max", "quantite": 50},
		"effets": [
			{"type": "chance_forge_pourcent", "valeur": 10.0},
			{"type": "chance_craft_avance_pourcent", "valeur": 10.0},
		],
	})

	_ajouter_titre({
		"id": "marchand",
		"nom": "Marchand",
		"description": "Acheter et vendre pour une valeur totale de 100 000 pièces. Prix d'achat -5%, prix de vente +5%.",
		"condition": {"type": "compteur", "action": "valeur_commerce", "quantite": 100000},
		"effets": [
			{"type": "prix_achat_pourcent", "valeur": -5.0},
			{"type": "prix_vente_pourcent", "valeur": 5.0},
		],
	})

	_ajouter_titre({
		"id": "millionnaire",
		"nom": "Millionnaire",
		"description": "Posséder simultanément une importante somme d'or. +5% d'or obtenu.",
		"condition": {"type": "seuil", "action": "or_possede", "quantite": 100000},  # seuil à ajuster selon l'équilibrage
		"effets": [{"type": "or_obtenu_pourcent", "valeur": 5.0}],
	})

	_ajouter_titre({
		"id": "mineur",
		"nom": "Mineur",
		"description": "Extraire 1000 minerais. +10% de ressources obtenues lors de l'extraction de minerais.",
		"condition": {"type": "compteur", "action": "miner", "quantite": 1000},
		"effets": [{"type": "ressources_minerai_pourcent", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "bucheron",
		"nom": "Bûcheron",
		"description": "Abattre 500 arbres. +10% de bois obtenu sur les arbres.",
		"condition": {"type": "compteur", "action": "abattre_arbre", "quantite": 500},
		"effets": [{"type": "bois_obtenu_pourcent", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "explorateur",
		"nom": "Explorateur",
		"description": "Découvrir 50 lieux différents. +10% vitesse hors combat.",
		"condition": {"type": "compteur", "action": "decouvrir_lieu", "quantite": 50},
		"effets": [{"type": "vitesse_hors_combat_pourcent", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "cartographe",
		"nom": "Cartographe",
		"description": "Explorer une grande partie du monde extérieur. Les lieux secrets proches sont légèrement plus faciles à détecter.",
		"condition": {"type": "manuel"},  # % de carte explorée -> à appeler par le système de monde ouvert quand le seuil est atteint
		"effets": [{"type": "comportemental"}],
	})

	_ajouter_titre({
		"id": "architecte",
		"nom": "Architecte",
		"description": "Construire une base remplissant plusieurs critères précis. Les blocs de construction placés peuvent être récupérés plus facilement.",
		"condition": {"type": "manuel"},  # critères multiples -> à vérifier par le système de construction
		"effets": [{"type": "comportemental"}],
	})

	_ajouter_titre({
		"id": "sedentaire",
		"nom": "Sédentaire",
		"description": "Dormir dans sa propre base 50 fois. Bonus de régénération lorsque le joueur se trouve dans sa base.",
		"condition": {"type": "compteur", "action": "dormir_base", "quantite": 50},
		"effets": [{"type": "regeneration_pourcent_dans_base", "valeur": 0.0}],  # valeur à définir selon l'équilibrage
	})

	_ajouter_titre({
		"id": "vagabond",
		"nom": "Vagabond",
		"description": "Parcourir une très grande distance sans dormir. +10% vitesse tant que le joueur n'a pas dormi depuis un certain temps.",
		"condition": {"type": "manuel"},  # distance cumulée sans sommeil -> à suivre par le système de déplacement/sommeil
		"effets": [{"type": "vitesse_pourcent_sans_sommeil", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "enfant_de_la_nuit",
		"nom": "Enfant de la Nuit",
		"description": "Survivre à une nuit complète dans le monde extérieur sans dormir. +15% efficacité pendant la nuit.",
		"condition": {"type": "manuel"},  # -> appelé par le cycle jour/nuit au lever du soleil si la nuit a été passée sans dormir
		"effets": [{"type": "efficacite_nuit_pourcent", "valeur": 15.0}],
	})

	_ajouter_titre({
		"id": "enfant_du_soleil",
		"nom": "Enfant du Soleil",
		"description": "Vaincre 100 ennemis uniquement pendant la journée. +10% dégâts pendant le jour.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "ennemi", "quantite": 100, "contexte_requis": {"moment": "jour"}},
		"effets": [{"type": "degats_pourcent_jour", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "observateur",
		"nom": "Observateur",
		"description": "Compléter une série importante d'entrées du bestiaire. Les créatures déjà étudiées affichent davantage d'informations.",
		"condition": {"type": "compteur", "action": "bestiaire_entree", "quantite": 30},  # quantité à ajuster selon la taille du bestiaire
		"effets": [{"type": "comportemental"}],
	})

	_ajouter_titre({
		"id": "erudit",
		"nom": "Érudit",
		"description": "Découvrir un grand nombre de livres et secrets. +5% efficacité des compétences.",
		"condition": {"type": "compteur", "action": "decouvrir_livre_ou_secret", "quantite": 50},
		"effets": [{"type": "efficacite_competences_pourcent", "valeur": 5.0}],
	})

	_ajouter_titre({
		"id": "alchimiste",
		"nom": "Alchimiste",
		"description": "Fabriquer 100 potions différentes. Les potions fabriquées durent +15%.",
		"condition": {"type": "compteur", "action": "fabriquer_potion_differente", "quantite": 100},
		"effets": [{"type": "duree_potions_pourcent", "valeur": 15.0}],
	})

	_ajouter_titre({
		"id": "medecin_de_guerre",
		"nom": "Médecin de guerre",
		"description": "Soigner une quantité cumulée importante de PV. Les soins reçus sont +10% efficaces.",
		"condition": {"type": "compteur", "action": "soin_cumule", "quantite": 10000},  # en PV cumulés, à ajuster
		"effets": [{"type": "soins_recus_pourcent", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "survivant",
		"nom": "Survivant",
		"description": "Survivre à 50 situations où les PV passent sous 10%. +5% défense lorsque les PV sont inférieurs à 25%.",
		"condition": {"type": "compteur", "action": "survivre_pv_critique", "quantite": 50},
		"effets": [{"type": "defense_pourcent_pv_bas", "valeur": 5.0}],
	})

	_ajouter_titre({
		"id": "rescape",
		"nom": "Rescapé",
		"description": "Revenir vivant de 25 situations extrêmement dangereuses. +10% vitesse lorsque les PV sont inférieurs à 20%.",
		"condition": {"type": "compteur", "action": "survivre_situation_extreme", "quantite": 25},
		"effets": [{"type": "vitesse_pourcent_pv_bas", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "fuyard",
		"nom": "Fuyard",
		"description": "Fuir volontairement 100 combats sans mourir. +20% vitesse pendant quelques secondes après avoir quitté un combat.",
		"condition": {"type": "compteur", "action": "fuir_combat", "quantite": 100},
		"effets": [{"type": "vitesse_pourcent_apres_fuite", "valeur": 20.0}],  # temporaire : à appliquer par le combat pendant X secondes
	})

	_ajouter_titre({
		"id": "patient",
		"nom": "Patient",
		"description": "Vaincre un boss sans se déplacer pendant certaines phases du combat. +10% défense tant que le joueur reste immobile.",
		"condition": {"type": "manuel"},  # -> appelé par le combat de boss concerné
		"effets": [{"type": "defense_pourcent_immobile", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "poing_dacier",
		"nom": "Poing d'acier",
		"description": "Vaincre 100 ennemis uniquement à mains nues. +25% dégâts des attaques sans arme.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "ennemi", "quantite": 100, "contexte_requis": {"arme": "aucune"}},
		"effets": [{"type": "degats_pourcent_sans_arme", "valeur": 25.0}],
	})

	_ajouter_titre({
		"id": "lame_parfaite",
		"nom": "Lame parfaite",
		"description": "Réussir 100 attaques critiques consécutives sans subir de dégâts. +10% dégâts avec les armes de mêlée.",
		"condition": {"type": "manuel"},  # streak sans dégât reçu -> géré par le combat, comme Massacreur
		"effets": [{"type": "degats_pourcent_melee", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "conquerant",
		"nom": "Conquérant",
		"description": "Atteindre plusieurs fois un étage élevé de la Tour. +5% dégâts dans la Tour.",
		"condition": {"type": "manuel"},  # "plusieurs fois" + "élevé" sont flous -> à trancher côté système de Tour puis debloquer_titre()
		"effets": [{"type": "degats_pourcent_dans_tour", "valeur": 5.0}],
	})

	_ajouter_titre({
		"id": "aventurier_de_la_tour",
		"nom": "Aventurier de la Tour",
		"description": "Découvrir 25 salles secrètes de la Tour. +5% résistance aux pièges dans la Tour.",
		"condition": {"type": "compteur", "action": "salle_secrete_tour", "quantite": 25},
		"effets": [{"type": "resistance_pieges_pourcent_dans_tour", "valeur": 5.0}],
	})

	_ajouter_titre({
		"id": "tueur_de_boss",
		"nom": "Tueur de Boss",
		"description": "Vaincre 10 boss. +10% dégâts contre les boss.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "boss", "quantite": 10},
		"effets": [{"type": "degats_pourcent_contre_cible", "cible": "boss", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "briseur_de_boss",
		"nom": "Briseur de Boss",
		"description": "Vaincre plusieurs boss ayant moins de 25% de leurs PV lors du coup final. +20% dégâts contre un boss sous ce seuil.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "boss", "quantite": 5, "contexte_requis": {"pv_bas": true}},
		"effets": [{"type": "degats_pourcent_contre_boss_pv_bas", "valeur": 20.0}],
	})

	_ajouter_titre({
		"id": "maudit",
		"nom": "Maudit",
		"description": "Découvrir et accepter une malédiction secrète. +10% dégâts, mais -5% défense.",
		"condition": {"type": "manuel"},  # choix ponctuel du joueur -> debloquer_titre() appelé au moment de l'acceptation
		"effets": [
			{"type": "degats_pourcent", "valeur": 10.0},
			{"type": "defense_pourcent", "valeur": -5.0},
		],
	})

	_ajouter_titre({
		"id": "chanceux",
		"nom": "Chanceux",
		"description": "Obtenir plusieurs objets extrêmement rares. +5% taux de drop.",
		"condition": {"type": "compteur", "action": "obtenir_objet_rare", "quantite": 5},
		"effets": [{"type": "taux_drop_pourcent", "valeur": 5.0}],
	})

	_ajouter_titre({
		"id": "miracule",
		"nom": "Miraculé",
		"description": "Survivre à une situation où une attaque aurait normalement tué le joueur. Petite chance d'éviter une attaque létale une fois par période.",
		"condition": {"type": "manuel"},  # -> le combat détecte le coup fatal évité et appelle debloquer_titre() directement
		"effets": [{"type": "comportemental"}],  # la chance d'esquive létale elle-même doit être gérée en direct par le combat, pas via bonus_generique
	})

	_ajouter_titre({
		"id": "stratege",
		"nom": "Stratège",
		"description": "Vaincre 100 ennemis après avoir découvert leurs informations dans le bestiaire. +10% efficacité contre les ennemis dont les résistances sont connues.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "ennemi", "quantite": 100, "contexte_requis": {"bestiaire_connu": true}},
		"effets": [{"type": "degats_pourcent_contre_ennemi_connu", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "chercheur_de_secrets",
		"nom": "Chercheur de secrets",
		"description": "Découvrir 20 secrets cachés. Les objets secrets émettent un indice sonore très discret à proximité.",
		"condition": {"type": "compteur", "action": "decouvrir_secret", "quantite": 20},
		"effets": [{"type": "comportemental"}],
	})

	_ajouter_titre({
		"id": "idiot",
		"nom": "Idiot",
		"description": "Réaliser une série d'actions volontairement absurdes. Aucun bonus. Certains PNJ réagissent différemment au joueur.",
		"condition": {"type": "manuel"},
		"effets": [{"type": "comportemental"}],
	})

	_ajouter_titre({
		"id": "rat_de_donjon",
		"nom": "Rat de donjon",
		"description": "Passer un nombre important d'heures cumulées dans les donjons. +15% ressources trouvées dans les donjons.",
		"condition": {"type": "compteur", "action": "heure_en_donjon", "quantite": 100},
		"effets": [{"type": "ressources_donjon_pourcent", "valeur": 15.0}],
	})

	_ajouter_titre({
		"id": "collectionneur",
		"nom": "Collectionneur",
		"description": "Obtenir un grand nombre d'objets différents. +5% chance de trouver des objets inhabituels.",
		"condition": {"type": "compteur", "action": "obtenir_objet_different", "quantite": 100},
		"effets": [{"type": "chance_objet_inhabituel_pourcent", "valeur": 5.0}],
	})

	_ajouter_titre({
		"id": "mort_vivant",
		"nom": "Mort-vivant",
		"description": "Découvrir une zone secrète liée aux morts. Certains effets de soin fonctionnent différemment.",
		"condition": {"type": "manuel"},
		"effets": [{"type": "comportemental"}],
	})

```


============================================================
## FICHIER : `titres_ui.gd`
============================================================

```gdscript
extends Control

# ==========================================================
#  OBSIDIAN HORIZON — UI de l'onglet Titres
#  Affiche les titres débloqués + les ??? pour les secrets.
# ==========================================================

var conteneur: VBoxContainer
var scroll: ScrollContainer


func _ready() -> void:
	_construire()
	# On se connecte au signal pour rafraîchir automatiquement
	if Titres:
		Titres.titre_debloque.connect(_on_titre_debloque)


func _construire() -> void:
	scroll = ScrollContainer.new()
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(scroll)

	conteneur = VBoxContainer.new()
	conteneur.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(conteneur)

	rafraichir()


func rafraichir() -> void:
	# Nettoyer
	for enfant in conteneur.get_children():
		enfant.queue_free()

	if not Titres:
		var label := Label.new()
		label.text = "Système de titres non chargé."
		conteneur.add_child(label)
		return

	var titres: Array = Titres.obtenir_titres_pour_affichage()

	# Tri : débloqués en premier
	titres.sort_custom(func(a, b): return a["debloque"] and not b["debloque"])

	for t in titres:
		var ligne := HBoxContainer.new()
		conteneur.add_child(ligne)

		var nom := Label.new()
		nom.text = t["nom"]
		nom.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		if t["debloque"]:
			nom.add_theme_color_override("font_color", Color(0.9, 0.75, 0.2))  # doré
		else:
			nom.add_theme_color_override("font_color", Color(0.5, 0.5, 0.5))
		ligne.add_child(nom)

		var desc := Label.new()
		desc.text = t["description"]
		desc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		if not t["debloque"]:
			desc.add_theme_color_override("font_color", Color(0.4, 0.4, 0.4))
		ligne.add_child(desc)

		# Progression si compteur et déjà découvert
		if t["debloque"] and Titres.catalogue_titres.has(t["id"]):
			var cond: Dictionary = Titres.catalogue_titres[t["id"]].get("condition", {})
			if cond.get("type") == "compteur":
				var prog := Titres.obtenir_progression(t["id"])
				var maxi: int = cond.get("quantite", 0)
				var label_prog := Label.new()
				label_prog.text = "(%d / %d)" % [prog, maxi]
				ligne.add_child(label_prog)


func _on_titre_debloque(_id: String) -> void:
	rafraichir()

```


============================================================
## FICHIER : `competences.gd`
============================================================

```gdscript
extends Node

# ==========================================================
#  OBSIDIAN HORIZON — Autoload Compétences
#  À déclarer en Autoload sous le nom "Competences".
#
#  Gère le catalogue des compétences (actives + passives),
#  le déblocage, et l'application des effets passifs.
# ==========================================================

signal competence_debloquee(id: String)
signal slots_modifies

## Catalogue complet
var catalogue: Dictionary = {}

## Ids débloqués (permanents une fois obtenus)
var competences_debloquees: Array[String] = []


func _ready() -> void:
	_enregistrer_competences()


func _ajouter(def: Dictionary) -> void:
	catalogue[def["id"]] = def


# ----------------------------------------------------------
#  DÉBLOCAGE
# ----------------------------------------------------------
func debloquer(id: String) -> void:
	if id in competences_debloquees or not catalogue.has(id):
		return
	competences_debloquees.append(id)
	competence_debloquee.emit(id)
	print("Compétence débloquée : %s" % catalogue[id]["nom"])


func est_debloquee(id: String) -> bool:
	return id in competences_debloquees


func obtenir_definition(id: String) -> Dictionary:
	return catalogue.get(id, {})


# ----------------------------------------------------------
#  APPLICATION DES PASSIFS (appelé depuis Player)
# ----------------------------------------------------------
## Parcourt les compétences passives équipées du joueur et
## ajoute leurs effets dans bonus_generique / etc.
## Appelé automatiquement par Player.calculer_stats_finales()
## si on branche le lien.
func appliquer_passifs_au_joueur(joueur: Node) -> void:
	if joueur == null:
		return

	for competence in joueur.competences_passives:
		var id: String = ""
		if competence is String:
			id = competence
		elif competence is Dictionary:
			id = competence.get("id", "")
		else:
			continue

		var def: Dictionary = catalogue.get(id, {})
		if def.is_empty():
			continue

		for effet in def.get("effets", []):
			var type_effet: String = effet.get("type", "")
			var valeur: float = effet.get("valeur", 0.0)

			# Boost Gnome uniquement sur les effets positifs
			if joueur.est_gnome and valeur > 0.0:
				valeur *= 1.5

			match type_effet:
				"degats_pourcent_contre_cible":
					var cible: String = effet.get("cible", "")
					joueur.bonus_degats_contre[cible] = joueur.bonus_degats_contre.get(cible, 0.0) + valeur
				"reduction_degats_recus_pourcent_contre_cible":
					var cible2: String = effet.get("cible", "")
					joueur.bonus_reduction_degats_recus_de[cible2] = joueur.bonus_reduction_degats_recus_de.get(cible2, 0.0) + valeur
				_:
					joueur.bonus_generique[type_effet] = joueur.bonus_generique.get(type_effet, 0.0) + valeur


# ----------------------------------------------------------
#  CATALOGUE — COMPÉTENCES PASSIVES
# ----------------------------------------------------------
func _enregistrer_competences() -> void:
	# --- Passifs de base ---
	_ajouter({
		"id": "peau_de_metal",
		"nom": "Peau de métal",
		"type": "passive",
		"description": "Augmente l'efficacité du bouclier.",
		"effets": [{"type": "bouclier_pourcent", "valeur": 15.0}],
		"source": "livre"  # drop / livre
	})

	_ajouter({
		"id": "peau_de_pierre",
		"nom": "Peau de pierre",
		"type": "passive",
		"description": "Réduit légèrement les dégâts reçus.",
		"effets": [{"type": "defense_pourcent", "valeur": 8.0}],
		"source": "livre"
	})

	_ajouter({
		"id": "peau_de_diamant",
		"nom": "Peau de diamant",
		"type": "passive",
		"description": "Forte réduction des dégâts reçus, mais malus de vitesse.",
		"effets": [
			{"type": "defense_pourcent", "valeur": 20.0},
			{"type": "vitesse_pourcent", "valeur": -10.0}
		],
		"source": "livre"
	})

	_ajouter({
		"id": "medecin",
		"nom": "Médecin",
		"type": "passive",
		"description": "Régénération naturelle des PV.",
		"effets": [{"type": "regeneration_pv_par_minute", "valeur": 2.0}],
		"source": "livre"
	})

	_ajouter({
		"id": "resistant",
		"nom": "Résistant",
		"type": "passive",
		"description": "Plus de PV, mais moins de vitesse.",
		"effets": [
			{"type": "pv_max_pourcent", "valeur": 15.0},
			{"type": "vitesse_pourcent", "valeur": -8.0}
		],
		"source": "livre"
	})

	_ajouter({
		"id": "monstre",
		"nom": "Monstre",
		"type": "passive",
		"description": "+ dégâts contre les êtres vivants.",
		"effets": [{"type": "degats_pourcent_contre_cible", "cible": "etre_vivant", "valeur": 15.0}],
		"source": "livre"
	})

	_ajouter({
		"id": "cannibale",
		"nom": "Cannibale",
		"type": "passive",
		"description": "Permet de manger des membres de sa propre espèce pour récupérer PV/PM.",
		"effets": [{"type": "comportemental"}],  # géré par le système d'items
		"source": "secret"
	})

	_ajouter({
		"id": "omnivore",
		"nom": "Omnivore",
		"type": "passive",
		"description": "Permet de manger des morceaux de monstres pour récupérer PV/PM.",
		"effets": [{"type": "comportemental"}],
		"source": "livre"
	})

	_ajouter({
		"id": "nictalope",
		"nom": "Nictalope",
		"type": "passive",
		"description": "Permet de voir dans le noir.",
		"effets": [{"type": "vision_nocturne", "valeur": 1.0}],
		"source": "livre"
	})

	# --- Forgeron ---
	_ajouter({
		"id": "forgeron_apprenti",
		"nom": "Forgeron apprenti",
		"type": "passive",
		"description": "+ chance de réussite à la forge.",
		"effets": [{"type": "chance_forge_pourcent", "valeur": 10.0}],
		"source": "craft"
	})

	_ajouter({
		"id": "forgeron_chevronne",
		"nom": "Forgeron chevronné",
		"type": "passive",
		"description": "Meilleure chance de réussite + qualité.",
		"effets": [
			{"type": "chance_forge_pourcent", "valeur": 20.0},
			{"type": "qualite_forge_pourcent", "valeur": 10.0}
		],
		"source": "craft"
	})

	_ajouter({
		"id": "forgeron_maitre",
		"nom": "Forgeron maître",
		"type": "passive",
		"description": "Maîtrise totale de la forge.",
		"effets": [
			{"type": "chance_forge_pourcent", "valeur": 35.0},
			{"type": "qualite_forge_pourcent", "valeur": 25.0}
		],
		"source": "craft"
	})

	# --- Compétences spéciales / Easter Eggs (conditions manuelles) ---
	_ajouter({
		"id": "route_du_sacrifice",
		"nom": "Route du Sacrifice",
		"type": "passive",
		"description": "Ignore les malus liés à la mort.",
		"effets": [{"type": "ignore_malus_mort", "valeur": 1.0}],
		"source": "secret",  # poupée vaudou étage 5 + sacrifice étage 100
		"condition_secrete": true
	})

	_ajouter({
		"id": "dernier_rempart",
		"nom": "Dernier Rempart",
		"type": "passive",
		"description": "À 1 PV : +1000 % dégâts pendant 10 s et régénère 20 % des PV.",
		"effets": [{"type": "comportemental"}],  # géré en combat
		"source": "secret",  # No Hit Perfect 100 étages
		"condition_secrete": true
	})

	_ajouter({
		"id": "zombie",
		"nom": "Zombie",
		"type": "passive",
		"description": "Survie temporaire à 1 PV pendant 10 s une fois par période.",
		"effets": [{"type": "comportemental"}],
		"source": "secret",  # 1 PV plus de 100 fois sans mourir
		"condition_secrete": true
	})

	_ajouter({
		"id": "berserker",
		"nom": "Berserker",
		"type": "passive",
		"description": "Chaque élimination donne +1 % PV/PM max.",
		"effets": [{"type": "comportemental"}],
		"source": "secret",  # titre Monstre + 100 fioles de sang avant étage 50
		"condition_secrete": true
	})

	_ajouter({
		"id": "archimage",
		"nom": "Archimage",
		"type": "passive",
		"description": "+30 % dégâts magiques, -10 % consommation de mana.",
		"effets": [
			{"type": "degats_magiques_pourcent", "valeur": 30.0},
			{"type": "consommation_mana_pourcent", "valeur": -10.0}
		],
		"source": "secret",  # toutes les compétences magiques
		"condition_secrete": true
	})

	_ajouter({
		"id": "doppelganger",
		"nom": "Doppelgänger",
		"type": "passive",
		"description": "40 % de chance de doubler une attaque sans coût de mana.",
		"effets": [{"type": "chance_double_attaque", "valeur": 40.0}],
		"source": "secret",  # étage caché + noyau
		"condition_secrete": true
	})

	# --- Quelques actives de base (exemples) ---
	_ajouter({
		"id": "boule_de_feu",
		"nom": "Boule de feu",
		"type": "active",
		"description": "Lance une boule de feu.",
		"cout_mana": 15,
		"degats_base": 25,
		"element": "feu",
		"source": "livre"
	})

	_ajouter({
		"id": "soin",
		"nom": "Soin",
		"type": "active",
		"description": "Restaure des PV.",
		"cout_mana": 20,
		"soin_base": 40,
		"source": "livre"
	})

	_ajouter({
		"id": "dash",
		"nom": "Dash",
		"type": "active",
		"description": "Esquive rapide vers l'avant.",
		"cout_mana": 8,
		"source": "livre"
	})

	_ajouter({
		"id": "cri_de_guerre",
		"nom": "Cri de guerre",
		"type": "active",
		"description": "Augmente temporairement les dégâts.",
		"cout_mana": 12,
		"duree": 8.0,
		"effets": [{"type": "degats_pourcent", "valeur": 20.0}],
		"source": "livre"
	})

```


============================================================
## FICHIER : `inventaire.gd`
============================================================

```gdscript
extends Node

# ==========================================================
#  OBSIDIAN HORIZON — Autoload Inventaire
#  À déclarer en Autoload sous le nom exact "Inventaire".
# ==========================================================

signal inventaire_modifie
signal barre_rapide_modifiee
signal equipement_modifie
signal or_modifie
signal etat_ouverture_change(est_ouvert: bool)

# ----------------------------------------------------------
#  CONFIGURATION
# ----------------------------------------------------------
const NB_COLONNES: int = 8
const NB_LIGNES: int = 5
const TAILLE_TOTALE: int = NB_COLONNES * NB_LIGNES          # 40
const TAILLE_BARRE_RAPIDE: int = 9

## Slots d'équipement (ordre logique pour l'UI)
const SLOTS_EQUIPEMENT: Array[String] = [
	"casque", "collier",
	"anneau_1", "anneau_2", "anneau_3", "anneau_4",
	"plastron", "bouclier", "jambieres", "bottes",
	"arme_principale", "arme_secondaire"
]

# ----------------------------------------------------------
#  DONNÉES
# ----------------------------------------------------------
## Chaque case = null ou { "objet": Dictionary, "quantite": int }
var slots: Array = []
var barre_rapide: Array = []
var equipement: Dictionary = {}

var or_actuel: int = 0
var est_ouvert: bool = false

## Équipement de base conservé à la mort (ids d'objets)
var ids_equipement_base: Array[String] = [
	"epee_rouillee",
	"chemise_basique",
	"pantalon_basique",
	"bottes_basiques"
]


func _ready() -> void:
	_initialiser()


func _initialiser() -> void:
	slots.resize(TAILLE_TOTALE)
	slots.fill(null)

	barre_rapide.resize(TAILLE_BARRE_RAPIDE)
	barre_rapide.fill(null)

	for slot in SLOTS_EQUIPEMENT:
		equipement[slot] = null


# ----------------------------------------------------------
#  OUVERTURE / FERMETURE
# ----------------------------------------------------------
func ouvrir() -> void:
	est_ouvert = true
	etat_ouverture_change.emit(true)


func fermer() -> void:
	est_ouvert = false
	etat_ouverture_change.emit(false)


func basculer() -> void:
	if est_ouvert:
		fermer()
	else:
		ouvrir()


# ----------------------------------------------------------
#  OR
# ----------------------------------------------------------
func ajouter_or(montant: int) -> void:
	if montant <= 0:
		return
	or_actuel += montant
	or_modifie.emit()
	# Titre Millionnaire (seuil)
	if Titres:
		Titres.verifier_seuil("or_possede", float(or_actuel))


func retirer_or(montant: int) -> bool:
	if montant <= 0:
		return true
	if or_actuel < montant:
		return false
	or_actuel -= montant
	or_modifie.emit()
	return true


# ----------------------------------------------------------
#  AJOUT D'OBJETS
# ----------------------------------------------------------
## Ajoute un objet dans la première case libre (ou empile si stackable).
## Retourne true si l'ajout a réussi.
func ajouter_objet(objet: Dictionary, quantite: int = 1) -> bool:
	if quantite <= 0 or objet.is_empty():
		return false

	var id_objet: String = objet.get("id", "")
	var max_stack: int = objet.get("max_stack", 1)

	# 1. Essayer d'empiler sur des stacks existants
	if max_stack > 1:
		for i in range(TAILLE_TOTALE):
			var case = slots[i]
			if case != null and case["objet"].get("id") == id_objet:
				var place_libre: int = max_stack - case["quantite"]
				if place_libre > 0:
					var a_ajouter: int = mini(quantite, place_libre)
					case["quantite"] += a_ajouter
					quantite -= a_ajouter
					if quantite <= 0:
						inventaire_modifie.emit()
						return true

	# 2. Cases vides
	for i in range(TAILLE_TOTALE):
		if slots[i] == null:
			var a_ajouter: int = mini(quantite, max_stack)
			slots[i] = {
				"objet": objet.duplicate(true),
				"quantite": a_ajouter
			}
			quantite -= a_ajouter
			if quantite <= 0:
				inventaire_modifie.emit()
				return true

	inventaire_modifie.emit()
	return quantite <= 0


## Version pratique pour les drops / craft
func ajouter_par_id(id: String, quantite: int = 1) -> bool:
	var objet := _creer_objet_depuis_id(id)
	if objet.is_empty():
		push_warning("Inventaire : objet inconnu '%s'" % id)
		return false
	return ajouter_objet(objet, quantite)


# ----------------------------------------------------------
#  RETRAIT
# ----------------------------------------------------------
func retirer_objet(index: int, quantite: int = 1) -> bool:
	if index < 0 or index >= TAILLE_TOTALE:
		return false
	var case = slots[index]
	if case == null:
		return false

	case["quantite"] -= quantite
	if case["quantite"] <= 0:
		slots[index] = null

	inventaire_modifie.emit()
	return true


func retirer_par_id(id: String, quantite: int = 1) -> bool:
	var reste := quantite
	for i in range(TAILLE_TOTALE):
		var case = slots[i]
		if case != null and case["objet"].get("id") == id:
			var a_retirer: int = mini(reste, case["quantite"])
			case["quantite"] -= a_retirer
			reste -= a_retirer
			if case["quantite"] <= 0:
				slots[i] = null
			if reste <= 0:
				inventaire_modifie.emit()
				return true
	inventaire_modifie.emit()
	return reste <= 0


# ----------------------------------------------------------
#  ÉQUIPEMENT
# ----------------------------------------------------------
func equiper(objet: Dictionary, slot: String) -> bool:
	if not equipement.has(slot):
		return false
	# Si un objet est déjà équipé, on le range dans l'inventaire
	if equipement[slot] != null:
		ajouter_objet(equipement[slot], 1)
	equipement[slot] = objet.duplicate(true)
	equipement_modifie.emit()
	return true


func desequiper(slot: String) -> bool:
	if not equipement.has(slot) or equipement[slot] == null:
		return false
	var objet = equipement[slot]
	if ajouter_objet(objet, 1):
		equipement[slot] = null
		equipement_modifie.emit()
		return true
	return false


# ----------------------------------------------------------
#  BARRE RAPIDE
# ----------------------------------------------------------
func assigner_barre_rapide(index_barre: int, index_inventaire: int) -> void:
	if index_barre < 0 or index_barre >= TAILLE_BARRE_RAPIDE:
		return
	if index_inventaire < 0 or index_inventaire >= TAILLE_TOTALE:
		return
	barre_rapide[index_barre] = slots[index_inventaire]
	barre_rapide_modifiee.emit()


func utiliser_barre_rapide(index: int) -> void:
	if index < 0 or index >= TAILLE_BARRE_RAPIDE:
		return
	var case = barre_rapide[index]
	if case == null:
		return
	# Point d'entrée pour consommer / activer l'objet
	# (à brancher plus tard sur le système de combat / items)
	print("Utilisation barre rapide %d : %s" % [index, case["objet"].get("nom", "?")])


# ----------------------------------------------------------
#  MORT — CONSERVATION DE L'ÉQUIPEMENT DE BASE
# ----------------------------------------------------------
## Appelé par Player.mourir().
## On vide tout sauf les objets dont l'id est dans ids_equipement_base
## (et on les rééquipe si possible).
func vider_sauf_equipement_base() -> void:
	# 1. Sauvegarder l'équipement de base actuellement porté
	var a_garder: Array[Dictionary] = []
	for slot in equipement.keys():
		var obj = equipement[slot]
		if obj != null and obj.get("id", "") in ids_equipement_base:
			a_garder.append(obj.duplicate(true))
		equipement[slot] = null

	# 2. Vider inventaire + barre rapide
	slots.fill(null)
	barre_rapide.fill(null)

	# 3. Remettre l'équipement de base
	for obj in a_garder:
		var slot_cible := _trouver_slot_pour_objet(obj)
		if slot_cible != "":
			equipement[slot_cible] = obj

	inventaire_modifie.emit()
	barre_rapide_modifiee.emit()
	equipement_modifie.emit()


func _trouver_slot_pour_objet(objet: Dictionary) -> String:
	var type: String = objet.get("type_equipement", "")
	match type:
		"casque": return "casque"
		"collier": return "collier"
		"anneau":
			for s in ["anneau_1", "anneau_2", "anneau_3", "anneau_4"]:
				if equipement[s] == null:
					return s
			return "anneau_1"
		"plastron": return "plastron"
		"bouclier": return "bouclier"
		"jambieres": return "jambieres"
		"bottes": return "bottes"
		"arme": return "arme_principale"
		_: return ""


# ----------------------------------------------------------
#  UTILITAIRES
# ----------------------------------------------------------
func compter_objet(id: String) -> int:
	var total := 0
	for case in slots:
		if case != null and case["objet"].get("id") == id:
			total += case["quantite"]
	return total


func a_de_la_place() -> bool:
	for case in slots:
		if case == null:
			return true
	return false


## Catalogue minimal d'objets de base (à enrichir plus tard)
func _creer_objet_depuis_id(id: String) -> Dictionary:
	match id:
		"epee_rouillee":
			return {
				"id": "epee_rouillee",
				"nom": "Épée rouillée",
				"type": "arme",
				"type_equipement": "arme",
				"degats": 5,
				"max_stack": 1
			}
		"chemise_basique":
			return {
				"id": "chemise_basique",
				"nom": "Chemise basique",
				"type": "armure",
				"type_equipement": "plastron",
				"defense": 1,
				"max_stack": 1
			}
		"pantalon_basique":
			return {
				"id": "pantalon_basique",
				"nom": "Pantalon basique",
				"type": "armure",
				"type_equipement": "jambieres",
				"defense": 1,
				"max_stack": 1
			}
		"bottes_basiques":
			return {
				"id": "bottes_basiques",
				"nom": "Bottes basiques",
				"type": "armure",
				"type_equipement": "bottes",
				"defense": 1,
				"max_stack": 1
			}
		"bois":
			return { "id": "bois", "nom": "Bois", "type": "ressource", "max_stack": 99 }
		"minerai_fer":
			return { "id": "minerai_fer", "nom": "Minerai de fer", "type": "ressource", "max_stack": 99 }
		"potion_vie":
			return { "id": "potion_vie", "nom": "Potion de vie", "type": "consommable", "max_stack": 20, "soin": 30 }
		"potion_mana":
			return { "id": "potion_mana", "nom": "Potion de mana", "type": "consommable", "max_stack": 20, "mana": 25 }
		"fiole_sang_monstre":
			return { "id": "fiole_sang_monstre", "nom": "Fiole de sang de monstre", "type": "consommable", "max_stack": 50 }
		"poupee_vaudou":
		"peau_loup":
			return { "id": "peau_loup", "nom": "Peau de loup", "type": "ressource", "max_stack": 50 }
		"viande_cru":
			return { "id": "viande_cru", "nom": "Viande crue", "type": "consommable", "max_stack": 30, "soin": 5 }
		"poupee_vaudou":
			return {
				"id": "poupee_vaudou",
				"nom": "Poupée vaudou",
				"type": "special",
				"description": "Une poupée étrange... Sa description est vague.",
				"max_stack": 1
			}

		"minerai_cuivre":
			return { "id": "minerai_cuivre", "nom": "Minerai de cuivre", "type": "ressource", "max_stack": 99 }
		"minerai_argent":
			return { "id": "minerai_argent", "nom": "Minerai d'argent", "type": "ressource", "max_stack": 99 }
		"minerai_or":
			return { "id": "minerai_or", "nom": "Minerai d'or", "type": "ressource", "max_stack": 99 }
		"minerai_mithril":
			return { "id": "minerai_mithril", "nom": "Minerai de mithril", "type": "ressource", "max_stack": 99 }
		"minerai_obsidienne":
			return { "id": "minerai_obsidienne", "nom": "Minerai d'obsidienne", "type": "ressource", "max_stack": 99 }
		"minerai_etherium":
			return { "id": "minerai_etherium", "nom": "Minerai d'éthérium", "type": "ressource", "max_stack": 99 }
		"oeil_bestial":
			return { "id": "oeil_bestial", "nom": "Œil bestial", "type": "composant", "max_stack": 50 }
		"os_renforces":
			return { "id": "os_renforces", "nom": "Os renforcés", "type": "composant", "max_stack": 50 }
		"ecaille_reptile":
			return { "id": "ecaille_reptile", "nom": "Écaille de reptile", "type": "composant", "max_stack": 50 }
		"aile_membraneuse":
			return { "id": "aile_membraneuse", "nom": "Aile membraneuse", "type": "composant", "max_stack": 30 }
		"croc_alpha":
			return { "id": "croc_alpha", "nom": "Croc d'alpha", "type": "composant", "max_stack": 30 }
		"noyau_elementaire_feu":
			return { "id": "noyau_elementaire_feu", "nom": "Noyau élémentaire de feu", "type": "composant", "max_stack": 20 }
		"noyau_elementaire_glace":
			return { "id": "noyau_elementaire_glace", "nom": "Noyau élémentaire de glace", "type": "composant", "max_stack": 20 }
		"fragment_ombre":
			return { "id": "fragment_ombre", "nom": "Fragment d'ombre", "type": "composant", "max_stack": 20 }
		"glande_venin":
			return { "id": "glande_venin", "nom": "Glande à venin", "type": "composant", "max_stack": 30 }


		"minerai_diamant":
			return { "id": "minerai_diamant", "nom": "Minerai de diamant", "type": "ressource", "max_stack": 99 }
		"minerai_adamantium":
			return { "id": "minerai_adamantium", "nom": "Minerai d'adamantium", "type": "ressource", "max_stack": 99 }
		"minerai_cristal":
			return { "id": "minerai_cristal", "nom": "Minerai de cristal", "type": "ressource", "max_stack": 99 }
		"minerai_orichalque":
			return { "id": "minerai_orichalque", "nom": "Minerai d'orichalque", "type": "ressource", "max_stack": 99 }
		"minerai_ebonite":
			return { "id": "minerai_ebonite", "nom": "Minerai d'ébonite", "type": "ressource", "max_stack": 99 }
		"minerai_metal_celeste":
			return { "id": "minerai_metal_celeste", "nom": "Métal céleste", "type": "ressource", "max_stack": 99 }

		_:
			return {}

```


============================================================
## FICHIER : `inventaire_ui.gd`
============================================================

```gdscript
extends Control

# ==========================================================
#  OBSIDIAN HORIZON — Interface visuelle de l'inventaire
#  À attacher à un nœud Control racine (ex: InventaireUI.tscn).
#  Reproduit la structure de la maquette :
#    - Onglets en haut (Principal / Compétences / Titre / Bestiaire)
#    - Grille d'inventaire (8x5) à gauche
#    - Panneau personnage + slots d'équipement à droite
#    - Barre rapide (9 cases) en bas, liée au HUD
#    - Compteur d'or en bas à droite
#  Toute la mise en page est faite en code (pas de scène à designer à la
#  main) pour que tu puisses avancer sans DA finale ; à remplacer plus
#  tard par de vrais thèmes/textures.
# ==========================================================

const TAILLE_CASE: int = 64
const TAILLE_CASE_EQUIPEMENT: int = 56

## Ordre d'affichage des slots d'équipement, aligné sur la silhouette
## de la maquette (casque en haut, anneaux autour du torse, bottes en bas).
const ORDRE_SLOTS_EQUIPEMENT: Array[String] = [
	"casque", "collier",
	"anneau_1", "anneau_2", "anneau_3", "anneau_4",
	"plastron", "bouclier", "jambieres", "bottes",
]

var onglet_actif: String = "principal"

# Références aux nœuds construits dynamiquement
var conteneur_onglets: HBoxContainer
var panneau_principal: Control
var panneau_titres: Control  # instance de titres_ui.gd (voir Titres.tscn/.gd)
var grid_container: GridContainer
var boutons_slots: Array[Button] = []
var conteneur_barre_rapide: HBoxContainer
var boutons_barre_rapide: Array[Button] = []
var boutons_equipement: Dictionary = {}
var label_or: Label


func _ready() -> void:
	visible = false

	_construire_onglets()
	_construire_panneau_principal()
	_construire_panneau_titres()
	_construire_barre_rapide()
	_construire_affichage_or()

	Inventaire.etat_ouverture_change.connect(_on_etat_ouverture_change)
	Inventaire.inventaire_modifie.connect(_rafraichir_grille)
	Inventaire.barre_rapide_modifiee.connect(_rafraichir_barre_rapide)
	Inventaire.equipement_modifie.connect(_rafraichir_equipement)
	Inventaire.or_modifie.connect(_rafraichir_or)


# ----------------------------------------------------------
#  ONGLETS (Principal / Compétences / Titre / Bestiaire)
# ----------------------------------------------------------
## Seul l'onglet Principal est construit ici. Les trois autres affichent
## un panneau vide en attendant les systèmes correspondants (compétences,
## titres, bestiaire) : branche leurs propres UI sur _afficher_onglet().
func _construire_onglets() -> void:
	conteneur_onglets = HBoxContainer.new()
	add_child(conteneur_onglets)

	for nom_onglet in ["principal", "competences", "titre", "bestiaire"]:
		var bouton := Button.new()
		bouton.text = nom_onglet.capitalize()
		bouton.pressed.connect(_afficher_onglet.bind(nom_onglet))
		conteneur_onglets.add_child(bouton)


func _afficher_onglet(nom_onglet: String) -> void:
	onglet_actif = nom_onglet
	panneau_principal.visible = (nom_onglet == "principal")
	panneau_titres.visible = (nom_onglet == "titre")
	if nom_onglet == "titre":
		panneau_titres.rafraichir()
	# TODO : afficher/masquer les panneaux Compétences / Bestiaire une fois
	# ces systèmes créés (même logique que panneau_principal/panneau_titres).


## Instancie le panneau de l'onglet Titre (titres_ui.gd). Adapte le chemin
## ci-dessous à l'emplacement réel du script dans ton projet, ou glisse
## directement une scène TitresUI.tscn préconfigurée si tu préfères.
func _construire_panneau_titres() -> void:
	# Adapte le chemin selon l'emplacement réel dans ton projet
	var script_titres = load("res://scripts/titres_ui.gd")
	if script_titres == null:
		script_titres = load("res://titres_ui.gd")
	panneau_titres = Control.new()
	if script_titres:
		panneau_titres.set_script(script_titres)
	panneau_titres.visible = false
	add_child(panneau_titres)


# ----------------------------------------------------------
#  PANNEAU PRINCIPAL (grille + équipement)
# ----------------------------------------------------------
func _construire_panneau_principal() -> void:
	panneau_principal = HBoxContainer.new()
	add_child(panneau_principal)

	# --- Grille d'inventaire (8 colonnes x 5 lignes) ---
	grid_container = GridContainer.new()
	grid_container.columns = Inventaire.NB_COLONNES
	panneau_principal.add_child(grid_container)

	for i in range(Inventaire.TAILLE_TOTALE):
		var bouton := Button.new()
		bouton.custom_minimum_size = Vector2(TAILLE_CASE, TAILLE_CASE)
		bouton.pressed.connect(_on_slot_grille_presse.bind(i))
		grid_container.add_child(bouton)
		boutons_slots.append(bouton)

	# --- Panneau équipement (silhouette du personnage) ---
	var conteneur_equipement := GridContainer.new()
	conteneur_equipement.columns = 2
	panneau_principal.add_child(conteneur_equipement)

	for slot in ORDRE_SLOTS_EQUIPEMENT:
		var bouton := Button.new()
		bouton.custom_minimum_size = Vector2(TAILLE_CASE_EQUIPEMENT, TAILLE_CASE_EQUIPEMENT)
		bouton.text = slot.capitalize()
		bouton.pressed.connect(_on_slot_equipement_presse.bind(slot))
		conteneur_equipement.add_child(bouton)
		boutons_equipement[slot] = bouton


# ----------------------------------------------------------
#  BARRE RAPIDE (séparée de la grille, sous le panneau principal)
# ----------------------------------------------------------
func _construire_barre_rapide() -> void:
	conteneur_barre_rapide = HBoxContainer.new()
	add_child(conteneur_barre_rapide)

	for i in range(Inventaire.TAILLE_BARRE_RAPIDE):
		var bouton := Button.new()
		bouton.custom_minimum_size = Vector2(TAILLE_CASE, TAILLE_CASE)
		bouton.text = str(i + 1)  # numéros 1 à 9 visibles sur la maquette
		bouton.pressed.connect(_on_slot_barre_rapide_presse.bind(i))
		conteneur_barre_rapide.add_child(bouton)
		boutons_barre_rapide.append(bouton)


# ----------------------------------------------------------
#  OR
# ----------------------------------------------------------
func _construire_affichage_or() -> void:
	label_or = Label.new()
	add_child(label_or)
	_rafraichir_or()


# ----------------------------------------------------------
#  RAFRAÎCHISSEMENT DE L'AFFICHAGE
# ----------------------------------------------------------
func _rafraichir_grille() -> void:
	for i in range(Inventaire.TAILLE_TOTALE):
		_rafraichir_bouton_case(boutons_slots[i], Inventaire.slots[i])


func _rafraichir_barre_rapide() -> void:
	for i in range(Inventaire.TAILLE_BARRE_RAPIDE):
		var case_actuelle = Inventaire.barre_rapide[i]
		if case_actuelle == null:
			boutons_barre_rapide[i].text = str(i + 1)
		else:
			var objet: Dictionary = case_actuelle["objet"]
			boutons_barre_rapide[i].text = "%s\nx%d" % [objet.get("nom", "?"), case_actuelle["quantite"]]


func _rafraichir_equipement() -> void:
	for slot in ORDRE_SLOTS_EQUIPEMENT:
		var objet = Inventaire.equipement[slot]
		var bouton: Button = boutons_equipement[slot]
		bouton.text = objet.get("nom", "?") if objet != null else slot.capitalize()


func _rafraichir_or() -> void:
	label_or.text = "Or : %d" % Inventaire.or_actuel


func _rafraichir_bouton_case(bouton: Button, case_actuelle) -> void:
	if case_actuelle == null:
		bouton.text = ""
		bouton.tooltip_text = ""
	else:
		var objet: Dictionary = case_actuelle["objet"]
		bouton.text = "%s\nx%d" % [objet.get("nom", "?"), case_actuelle["quantite"]]
		bouton.tooltip_text = objet.get("nom", "?")


# ----------------------------------------------------------
#  OUVERTURE / FERMETURE
# ----------------------------------------------------------
func _on_etat_ouverture_change(est_ouvert: bool) -> void:
	visible = est_ouvert
	if est_ouvert:
		_rafraichir_grille()
		_rafraichir_barre_rapide()
		_rafraichir_equipement()
		_rafraichir_or()


# ----------------------------------------------------------
#  INTERACTIONS (points d'entrée à étoffer : drag & drop, clic droit, etc.)
# ----------------------------------------------------------
func _on_slot_grille_presse(index: int) -> void:
	var case_actuelle = Inventaire.slots[index]
	if case_actuelle != null:
		print("Case grille cliquée %d : %s" % [index, case_actuelle["objet"].get("nom", "?")])


func _on_slot_barre_rapide_presse(index: int) -> void:
	var case_actuelle = Inventaire.barre_rapide[index]
	if case_actuelle != null:
		print("Case barre rapide cliquée %d : %s" % [index, case_actuelle["objet"].get("nom", "?")])


func _on_slot_equipement_presse(slot: String) -> void:
	var objet = Inventaire.equipement[slot]
	if objet != null:
		print("Slot équipement '%s' cliqué : %s" % [slot, objet.get("nom", "?")])

```


============================================================
## FICHIER : `forge.gd`
============================================================

```gdscript
extends Node

# ==========================================================
#  OBSIDIAN HORIZON — Système de Forge
#  Pas de minijeu "tape-tape" : choix guidés + matériaux + RNG.
#
#  Flux :
#    1. Catégorie   → arme / armure / bonus
#    2. Type pièce  → épée, lance, plastron, anneau…
#    3. Matériau principal (minerai) → base stats + tier
#    4. Matériau secondaire (drop mob) → direction des effets + teinte
#    5. RNG → variance (une épée de fer peut sortir exceptionnelle)
#
#  Autoload recommandé sous le nom "Forge".
# ==========================================================

signal forge_reussie(objet: Dictionary)
signal forge_echouee(raison: String)

# ----------------------------------------------------------
#  CATÉGORIES & TYPES DE PIÈCES
# ----------------------------------------------------------
const CATEGORIES := {
	"arme": {
		"nom": "Arme",
		"types": {
			"epee": {"nom": "Épée", "slot": "arme_principale", "stat_principale": "degats"},
			"lance": {"nom": "Lance", "slot": "arme_principale", "stat_principale": "degats"},
			"arc": {"nom": "Arc", "slot": "arme_principale", "stat_principale": "degats"},
			"hache": {"nom": "Hache", "slot": "arme_principale", "stat_principale": "degats"},
			"baton_mage": {"nom": "Bâton de mage", "slot": "arme_principale", "stat_principale": "degats_magiques"},
		}
	},
	"armure": {
		"nom": "Armure",
		"types": {
			"casque": {"nom": "Casque", "slot": "casque", "stat_principale": "defense"},
			"plastron": {"nom": "Plastron", "slot": "plastron", "stat_principale": "defense"},
			"jambieres": {"nom": "Jambières", "slot": "jambieres", "stat_principale": "defense"},
			"bottes": {"nom": "Bottes", "slot": "bottes", "stat_principale": "defense"},
		}
	},
	"bonus": {
		"nom": "Bonus",
		"types": {
			"anneau": {"nom": "Anneau", "slot": "anneau", "stat_principale": "special"},
			"amulette": {"nom": "Amulette", "slot": "collier", "stat_principale": "special"},
		}
	}
}

# ----------------------------------------------------------
#  MATÉRIAUX PRINCIPAUX (minerais)
#  - effet_garanti : toujours appliqué (sauf Fer = aucun)
#  - nb_effets_rng  : nombre d'effets aléatoires EN PLUS
#    de l'effet de base et de ceux du secondaire
# ----------------------------------------------------------
const MATERIAUX_PRINCIPAUX := {
	"fer": {
		"nom": "Fer",
		"tier": 1,
		"couleur": Color(0.55, 0.55, 0.58),
		"mult_stat": 1.0,
		"id_item": "minerai_fer",
		"quantite": 5,
		"effet_garanti": null,           # Aucun
		"nb_effets_rng": 0,
	},
	"argent": {
		"nom": "Argent",
		"tier": 2,
		"couleur": Color(0.78, 0.80, 0.85),
		"mult_stat": 1.15,
		"id_item": "minerai_argent",
		"quantite": 4,
		# Bonus contre les morts-vivants
		"effet_garanti": {
			"type": "degats_pourcent_contre_cible",
			"cible": "mort_vivant",
			"min": 8.0, "max": 15.0,
		},
		"nb_effets_rng": 1,
	},
	"or": {
		"nom": "Or",
		"tier": 2,
		"couleur": Color(0.85, 0.72, 0.2),
		"mult_stat": 1.2,
		"id_item": "minerai_or",
		"quantite": 4,
		# Bonus de résistance
		"effet_garanti": {
			"type": "defense_pourcent",
			"min": 4.0, "max": 10.0,
		},
		"nb_effets_rng": 1,
	},
	"diamant": {
		"nom": "Diamant",
		"tier": 3,
		"couleur": Color(0.7, 0.85, 0.95),
		"mult_stat": 1.4,
		"id_item": "minerai_diamant",
		"quantite": 3,
		# Résistance + orientation aléatoire (résistance à un élément tiré)
		"effet_garanti": {
			"type": "resistance_orientee",  # résolu à la forge
			"min": 8.0, "max": 18.0,
		},
		"nb_effets_rng": 2,
	},
	"adamantium": {
		"nom": "Adamantium",
		"tier": 3,
		"couleur": Color(0.45, 0.48, 0.55),
		"mult_stat": 1.55,
		"id_item": "minerai_adamantium",
		"quantite": 3,
		# Bonus de dégâts physiques
		"effet_garanti": {
			"type": "degats_physiques_pourcent",
			"min": 8.0, "max": 16.0,
		},
		"nb_effets_rng": 2,
	},
	"mithril": {
		"nom": "Mithril",
		"tier": 3,
		"couleur": Color(0.55, 0.72, 0.88),
		"mult_stat": 1.5,
		"id_item": "minerai_mithril",
		"quantite": 3,
		# Bonus magique
		"effet_garanti": {
			"type": "degats_magiques_pourcent",
			"min": 8.0, "max": 16.0,
		},
		"nb_effets_rng": 2,
	},
	"obsidienne": {
		"nom": "Obsidienne",
		"tier": 4,
		"couleur": Color(0.12, 0.08, 0.16),
		"mult_stat": 1.65,
		"id_item": "minerai_obsidienne",
		"quantite": 3,
		# Résistance élémentaire (élément tiré)
		"effet_garanti": {
			"type": "resistance_elementaire",
			"min": 10.0, "max": 22.0,
		},
		"nb_effets_rng": 3,
	},
	"cristal": {
		"nom": "Cristal",
		"tier": 4,
		"couleur": Color(0.75, 0.55, 0.95),
		"mult_stat": 1.45,
		"id_item": "minerai_cristal",
		"quantite": 3,
		# Amplification du matériau secondaire (mult sur ses effets)
		"effet_garanti": {
			"type": "amplification_secondaire",
			"min": 1.25, "max": 1.6,  # multiplicateur
		},
		"nb_effets_rng": 3,
	},
	"orichalque": {
		"nom": "Orichalque",
		"tier": 4,
		"couleur": Color(0.7, 0.55, 0.25),
		"mult_stat": 1.7,
		"id_item": "minerai_orichalque",
		"quantite": 2,
		# Bonus polyvalent (dégâts + défense légers)
		"effet_garanti": {
			"type": "bonus_polyvalent",
			"min": 4.0, "max": 9.0,
		},
		"nb_effets_rng": 3,
	},
	"ebonite": {
		"nom": "Ébonite",
		"tier": 5,
		"couleur": Color(0.08, 0.06, 0.1),
		"mult_stat": 1.85,
		"id_item": "minerai_ebonite",
		"quantite": 2,
		# Affinité avec les ténèbres
		"effet_garanti": {
			"type": "degats_ombre_pourcent",
			"min": 12.0, "max": 24.0,
		},
		"nb_effets_rng": 4,
	},
	"metal_celeste": {
		"nom": "Métal céleste",
		"tier": 5,
		"couleur": Color(0.95, 0.92, 0.7),
		"mult_stat": 2.0,
		"id_item": "minerai_metal_celeste",
		"quantite": 2,
		# Bonus contre les créatures divines
		"effet_garanti": {
			"type": "degats_pourcent_contre_cible",
			"cible": "divin",
			"min": 15.0, "max": 30.0,
		},
		"nb_effets_rng": 4,
	},
}

# ----------------------------------------------------------
#  POOLS RNG — effets tirés selon nb_effets_rng du minerai
#  "poids" : proba relative dans le tirage
#  "rare"  : true → pool rare (faible proba globale)
#  element_aleatoire : un seul type qui choisit feu/glace/etc. à la résolution
# ----------------------------------------------------------
const ELEMENTS_DEGATS := ["feu", "glace", "electricite", "lumiere", "tenebres", "metal"]

## Pool commune (référencée par catégorie avec des poids adaptés)
const POOL_RNG_OFFENSIF := [
	{"type": "degats_pourcent", "min": 2.0, "max": 12.0, "poids": 12, "cat": "offensif"},
	{"type": "tranchant_pourcent", "min": 3.0, "max": 12.0, "poids": 8, "cat": "offensif"},
	{"type": "perforation_pourcent", "min": 3.0, "max": 14.0, "poids": 8, "cat": "offensif"},
	{"type": "brutalite_pourcent", "min": 4.0, "max": 14.0, "poids": 6, "cat": "offensif"},  # vs PV hauts
	{"type": "degats_critique_pourcent", "min": 5.0, "max": 20.0, "poids": 8, "cat": "offensif"},
	{"type": "vitesse_attaque_pourcent", "min": 2.0, "max": 10.0, "poids": 8, "cat": "offensif"},
	{"type": "vol_de_vie_pourcent", "min": 1.0, "max": 8.0, "poids": 7, "cat": "offensif"},
	{"type": "absorption_pm_pourcent", "min": 1.0, "max": 7.0, "poids": 5, "cat": "offensif"},
	{"type": "execution_pourcent", "min": 4.0, "max": 16.0, "poids": 5, "cat": "offensif"},  # vs PV bas
	# Un seul effet "élément" : l'élément est tiré à la résolution
	{"type": "degats_elementaires", "min": 4.0, "max": 16.0, "poids": 10, "cat": "elementaire", "element_aleatoire": true},
]

const POOL_RNG_DEFENSIF := [
	{"type": "pv_max_pourcent", "min": 2.0, "max": 12.0, "poids": 10, "cat": "defensif"},
	{"type": "resistance_pourcent", "min": 2.0, "max": 10.0, "poids": 10, "cat": "defensif"},
	{"type": "resistance_physique_pourcent", "min": 3.0, "max": 14.0, "poids": 8, "cat": "defensif"},
	{"type": "resistance_magique_pourcent", "min": 3.0, "max": 14.0, "poids": 8, "cat": "defensif"},
	{"type": "resistance_elementaire_pourcent", "min": 3.0, "max": 12.0, "poids": 7, "cat": "defensif"},
	{"type": "resistance_element_aleatoire", "min": 5.0, "max": 18.0, "poids": 8, "cat": "defensif", "element_aleatoire": true},
	{"type": "reduction_degats_recus_pourcent", "min": 2.0, "max": 10.0, "poids": 6, "cat": "defensif"},
	{"type": "reduction_degats_critiques_recus_pourcent", "min": 4.0, "max": 15.0, "poids": 5, "cat": "defensif"},
]

const POOL_RNG_REGEN := [
	{"type": "regeneration_pv_restants_par_seconde", "min": 1.0, "max": 9.0, "poids": 6, "cat": "regen"},  # % des PV restants / s
	{"type": "regeneration_pm_pourcent", "min": 1.0, "max": 6.0, "poids": 6, "cat": "regen"},
	{"type": "regeneration_apres_degat_pourcent", "min": 3.0, "max": 12.0, "poids": 4, "cat": "regen"},
	{"type": "recuperation_pv_sur_attaque", "min": 1.0, "max": 5.0, "poids": 5, "cat": "regen"},
	{"type": "recuperation_pm_sur_attaque", "min": 1.0, "max": 5.0, "poids": 4, "cat": "regen"},
]

const POOL_RNG_SPECIAL := [
	{"type": "reduction_cout_pm_pourcent", "min": 3.0, "max": 12.0, "poids": 5, "cat": "special"},
	{"type": "vitesse_pourcent", "min": 2.0, "max": 10.0, "poids": 7, "cat": "special"},
	{"type": "resistance_effets_negatifs_pourcent", "min": 5.0, "max": 18.0, "poids": 4, "cat": "special"},
	{"type": "resistance_alterations_elementaires_pourcent", "min": 5.0, "max": 18.0, "poids": 4, "cat": "special"},
	{"type": "durabilite_pourcent", "min": 10.0, "max": 40.0, "poids": 5, "cat": "special"},
	{"type": "puissance_forge_secondaire_pourcent", "min": 5.0, "max": 20.0, "poids": 3, "cat": "special"},
	{"type": "affinite_categorie", "min": 1.0, "max": 1.0, "poids": 2, "cat": "special"},  # flag comportemental
]

const POOL_RNG_CIBLE := [
	{"type": "degats_pourcent_contre_cible", "cible": "mort_vivant", "min": 5.0, "max": 18.0, "poids": 4, "cat": "cible"},
	{"type": "degats_pourcent_contre_cible", "cible": "monstre", "min": 4.0, "max": 14.0, "poids": 5, "cat": "cible"},
	{"type": "degats_pourcent_contre_cible", "cible": "humain", "min": 4.0, "max": 14.0, "poids": 3, "cat": "cible"},
	{"type": "degats_pourcent_contre_cible", "cible": "magique", "min": 4.0, "max": 14.0, "poids": 4, "cat": "cible"},
	{"type": "degats_pourcent_contre_cible", "cible": "boss", "min": 5.0, "max": 16.0, "poids": 3, "cat": "cible"},
	{"type": "degats_pourcent_contre_cible", "cible": "divin", "min": 6.0, "max": 20.0, "poids": 2, "cat": "cible"},
]

## Très rares — proba globale faible (poids petits + filtre séparé)
const POOL_RNG_RARE := [
	{"type": "dernier_souffle", "min": 1.0, "max": 1.0, "poids": 1, "cat": "rare", "rare": true},
	{"type": "second_souffle", "min": 1.0, "max": 1.0, "poids": 1, "cat": "rare", "rare": true},
	{"type": "reflexion_degats_pourcent", "min": 3.0, "max": 12.0, "poids": 1, "cat": "rare", "rare": true},
	{"type": "double_impact_chance", "min": 3.0, "max": 12.0, "poids": 1, "cat": "rare", "rare": true},
	{"type": "drain_pourcent", "min": 2.0, "max": 8.0, "poids": 1, "cat": "rare", "rare": true},  # vol vie + abs PM
	{"type": "amplification_effets_pourcent", "min": 5.0, "max": 15.0, "poids": 1, "cat": "rare", "rare": true},
]

## Chance (0–1) qu'un effet RNG tiré vienne de la pool rare
const CHANCE_EFFET_RARE := 0.04

# ----------------------------------------------------------
#  MATÉRIAUX SECONDAIRES (drops de mobs) — direction d'effet + teinte
#  Pas les livres / équipements : organes, fluides, fragments…
# ----------------------------------------------------------
const MATERIAUX_SECONDAIRES := {
	# --- Offensifs / armes ---
	"fiole_sang_monstre": {
		"nom": "Fiole de sang de monstre",
		"teinte": Color(0.7, 0.1, 0.12),
		"tags": ["sang", "vie", "sauvage"],
		"effets_arme": [
			{"type": "vol_de_vie_pourcent", "min": 2.0, "max": 8.0},
			{"type": "degats_pourcent", "min": 3.0, "max": 10.0},
		],
		"effets_armure": [
			{"type": "regeneration_pv_par_minute", "min": 0.5, "max": 2.0},
		],
		"effets_bonus": [
			{"type": "vol_de_vie_pourcent", "min": 1.0, "max": 5.0},
		],
	},
	"oeil_bestial": {
		"nom": "Œil bestial",
		"teinte": Color(0.9, 0.2, 0.15),
		"tags": ["precision", "critique", "vision"],
		"effets_arme": [
			{"type": "chance_critique_pourcent", "min": 3.0, "max": 12.0},
			{"type": "degats_critique_pourcent", "min": 5.0, "max": 20.0},
		],
		"effets_armure": [
			{"type": "detection_ennemis_pourcent", "min": 5.0, "max": 15.0},
		],
		"effets_bonus": [
			{"type": "chance_critique_pourcent", "min": 2.0, "max": 8.0},
		],
	},
	"os_renforces": {
		"nom": "Os renforcés",
		"teinte": Color(0.9, 0.88, 0.8),
		"tags": ["robustesse", "percant"],
		"effets_arme": [
			{"type": "penetration_armure_pourcent", "min": 4.0, "max": 14.0},
			{"type": "degats_pourcent", "min": 2.0, "max": 7.0},
		],
		"effets_armure": [
			{"type": "defense_pourcent", "min": 3.0, "max": 10.0},
			{"type": "resistance_physique_pourcent", "min": 4.0, "max": 12.0},
		],
		"effets_bonus": [
			{"type": "pv_max_pourcent", "min": 2.0, "max": 8.0},
		],
	},
	"ecaille_reptile": {
		"nom": "Écaille de reptile",
		"teinte": Color(0.25, 0.55, 0.3),
		"tags": ["ecaille", "resistance", "poison"],
		"effets_arme": [
			{"type": "chance_poison_pourcent", "min": 5.0, "max": 18.0},
			{"type": "degats_poison_pourcent", "min": 4.0, "max": 12.0},
		],
		"effets_armure": [
			{"type": "resistance_poison_pourcent", "min": 8.0, "max": 25.0},
			{"type": "defense_pourcent", "min": 2.0, "max": 6.0},
		],
		"effets_bonus": [
			{"type": "resistance_poison_pourcent", "min": 5.0, "max": 15.0},
		],
	},
	"aile_membraneuse": {
		"nom": "Aile membraneuse",
		"teinte": Color(0.45, 0.35, 0.55),
		"tags": ["legerete", "vitesse", "air"],
		"effets_arme": [
			{"type": "vitesse_attaque_pourcent", "min": 4.0, "max": 14.0},
		],
		"effets_armure": [
			{"type": "vitesse_pourcent", "min": 3.0, "max": 10.0},
			{"type": "reduction_poids_armure_pourcent", "min": 5.0, "max": 15.0},
		],
		"effets_bonus": [
			{"type": "vitesse_pourcent", "min": 2.0, "max": 8.0},
		],
	},
	"croc_alpha": {
		"nom": "Croc d'alpha",
		"teinte": Color(0.85, 0.85, 0.9),
		"tags": ["sauvage", "degats", "fear"],
		"effets_arme": [
			{"type": "degats_pourcent", "min": 6.0, "max": 16.0},
			{"type": "degats_pourcent_contre_cible", "cible": "sauvage", "min": 5.0, "max": 15.0},
		],
		"effets_armure": [
			{"type": "reduction_degats_recus_pourcent_contre_cible", "cible": "sauvage", "min": 5.0, "max": 12.0},
		],
		"effets_bonus": [
			{"type": "degats_pourcent", "min": 3.0, "max": 9.0},
		],
	},
	"noyau_elementaire_feu": {
		"nom": "Noyau élémentaire de feu",
		"teinte": Color(1.0, 0.4, 0.1),
		"tags": ["feu", "elementaire"],
		"effets_arme": [
			{"type": "degats_feu_pourcent", "min": 8.0, "max": 22.0},
			{"type": "chance_brulure_pourcent", "min": 5.0, "max": 15.0},
		],
		"effets_armure": [
			{"type": "resistance_feu_pourcent", "min": 10.0, "max": 30.0},
		],
		"effets_bonus": [
			{"type": "degats_feu_pourcent", "min": 4.0, "max": 12.0},
		],
	},
	"noyau_elementaire_glace": {
		"nom": "Noyau élémentaire de glace",
		"teinte": Color(0.5, 0.75, 1.0),
		"tags": ["glace", "elementaire", "ralentissement"],
		"effets_arme": [
			{"type": "degats_glace_pourcent", "min": 8.0, "max": 22.0},
			{"type": "chance_ralentissement_pourcent", "min": 5.0, "max": 15.0},
		],
		"effets_armure": [
			{"type": "resistance_glace_pourcent", "min": 10.0, "max": 30.0},
		],
		"effets_bonus": [
			{"type": "degats_glace_pourcent", "min": 4.0, "max": 12.0},
		],
	},
	"fragment_ombre": {
		"nom": "Fragment d'ombre",
		"teinte": Color(0.2, 0.15, 0.3),
		"tags": ["ombre", "critique", "furtif"],
		"effets_arme": [
			{"type": "degats_ombre_pourcent", "min": 7.0, "max": 18.0},
			{"type": "chance_critique_pourcent", "min": 2.0, "max": 8.0},
		],
		"effets_armure": [
			{"type": "resistance_ombre_pourcent", "min": 8.0, "max": 22.0},
			{"type": "furtivite_pourcent", "min": 5.0, "max": 15.0},
		],
		"effets_bonus": [
			{"type": "furtivite_pourcent", "min": 4.0, "max": 12.0},
		],
	},
	"glande_venin": {
		"nom": "Glande à venin",
		"teinte": Color(0.4, 0.8, 0.2),
		"tags": ["poison", "dot"],
		"effets_arme": [
			{"type": "chance_poison_pourcent", "min": 8.0, "max": 25.0},
			{"type": "degats_poison_pourcent", "min": 6.0, "max": 18.0},
		],
		"effets_armure": [
			{"type": "resistance_poison_pourcent", "min": 12.0, "max": 35.0},
		],
		"effets_bonus": [
			{"type": "chance_poison_pourcent", "min": 4.0, "max": 12.0},
		],
	},
}

# Stats de base par type d'arme / armure (avant matériau & RNG)
const STATS_BASE_ARME := {
	"epee": 12.0,
	"lance": 11.0,
	"arc": 10.0,
	"hache": 15.0,
	"baton_mage": 9.0,
}

const STATS_BASE_ARMURE := {
	"casque": 4.0,
	"plastron": 10.0,
	"jambieres": 6.0,
	"bottes": 3.0,
}

# Multiplicateurs RNG de qualité
# Une forge "normale" peut sortir médiocre… ou exceptionnelle.
const PALIERS_QUALITE := [
	{"id": "mediocre", "nom": "Médiocre", "poids": 15, "mult": 0.75, "couleur_nom": "#888888"},
	{"id": "correct", "nom": "Correct", "poids": 35, "mult": 1.0, "couleur_nom": "#cccccc"},
	{"id": "bon", "nom": "Bon", "poids": 25, "mult": 1.2, "couleur_nom": "#55dd9e"},
	{"id": "excellent", "nom": "Excellent", "poids": 15, "mult": 1.45, "couleur_nom": "#4a9eff"},
	{"id": "exceptionnel", "nom": "Exceptionnel", "poids": 7, "mult": 1.8, "couleur_nom": "#b44aff"},
	{"id": "legendaire", "nom": "Légendaire", "poids": 3, "mult": 2.3, "couleur_nom": "#ffaa00"},
]


# ----------------------------------------------------------
#  API PUBLIQUE
# ----------------------------------------------------------

## Retourne les catégories disponibles
func obtenir_categories() -> Array[String]:
	return CATEGORIES.keys()


## Types de pièce pour une catégorie
func obtenir_types(categorie: String) -> Array[String]:
	if not CATEGORIES.has(categorie):
		return []
	return CATEGORIES[categorie]["types"].keys()


## Matériaux principaux disponibles (ceux dont le joueur a assez)
func obtenir_materiaux_principaux_disponibles() -> Array[Dictionary]:
	var resultat: Array[Dictionary] = []
	for id in MATERIAUX_PRINCIPAUX.keys():
		var mat: Dictionary = MATERIAUX_PRINCIPAUX[id]
		var qte_requise: int = mat.get("quantite", 1)
		var possede := 0
		if Inventaire:
			possede = Inventaire.compter_objet(mat.get("id_item", id))
		var effet_g = mat.get("effet_garanti", null)
		var desc_garanti := "Aucun"
		if effet_g != null:
			desc_garanti = str(effet_g.get("type", "?"))
		resultat.append({
			"id": id,
			"nom": mat["nom"],
			"tier": mat["tier"],
			"quantite_requise": qte_requise,
			"quantite_possedee": possede,
			"disponible": possede >= qte_requise,
			"couleur": mat["couleur"],
			"effet_garanti_desc": desc_garanti,
			"nb_effets_rng": int(mat.get("nb_effets_rng", 0)),
		})
	return resultat


## Matériaux secondaires disponibles
func obtenir_materiaux_secondaires_disponibles() -> Array[Dictionary]:
	var resultat: Array[Dictionary] = []
	for id in MATERIAUX_SECONDAIRES.keys():
		var mat: Dictionary = MATERIAUX_SECONDAIRES[id]
		var possede := 0
		if Inventaire:
			possede = Inventaire.compter_objet(id)
		resultat.append({
			"id": id,
			"nom": mat["nom"],
			"quantite_requise": 1,
			"quantite_possedee": possede,
			"disponible": possede >= 1,
			"teinte": mat["teinte"],
			"tags": mat.get("tags", []),
		})
	return resultat


## Chance de réussite brute (avant titres / compétences)
## Les titres Forgeron / Maître artisan modifient ça via le joueur.
func calculer_chance_reussite(joueur: Node, materiau_principal_id: String) -> float:
	var base := 70.0
	var tier: int = MATERIAUX_PRINCIPAUX.get(materiau_principal_id, {}).get("tier", 1)
	# Plus le tier est haut, plus c'est risqué sans maîtrise
	base -= float(tier - 1) * 8.0

	if joueur and joueur.has_method("obtenir_bonus"):
		base += joueur.obtenir_bonus("chance_forge_pourcent")

	return clampf(base, 5.0, 98.0)


## Point d'entrée principal de la forge.
## Retourne l'objet créé (Dictionary) ou {} en cas d'échec / matériaux manquants.
func forger(
	categorie: String,
	type_piece: String,
	materiau_principal_id: String,
	materiau_secondaire_id: String,
	joueur: Node = null
) -> Dictionary:
	# --- Validation ---
	if not CATEGORIES.has(categorie):
		forge_echouee.emit("Catégorie invalide.")
		return {}
	if not CATEGORIES[categorie]["types"].has(type_piece):
		forge_echouee.emit("Type de pièce invalide.")
		return {}
	if not MATERIAUX_PRINCIPAUX.has(materiau_principal_id):
		forge_echouee.emit("Matériau principal inconnu.")
		return {}
	if not MATERIAUX_SECONDAIRES.has(materiau_secondaire_id):
		forge_echouee.emit("Matériau secondaire inconnu.")
		return {}

	var mat_p: Dictionary = MATERIAUX_PRINCIPAUX[materiau_principal_id]
	var mat_s: Dictionary = MATERIAUX_SECONDAIRES[materiau_secondaire_id]
	var def_type: Dictionary = CATEGORIES[categorie]["types"][type_piece]

	# --- Vérif inventaire ---
	if Inventaire:
		var id_p: String = mat_p.get("id_item", materiau_principal_id)
		var qte_p: int = mat_p.get("quantite", 1)
		if Inventaire.compter_objet(id_p) < qte_p:
			forge_echouee.emit("Pas assez de %s." % mat_p["nom"])
			return {}
		if Inventaire.compter_objet(materiau_secondaire_id) < 1:
			forge_echouee.emit("Pas de %s." % mat_s["nom"])
			return {}

	# --- Jet de réussite ---
	var chance := calculer_chance_reussite(joueur, materiau_principal_id)
	if randf() * 100.0 > chance:
		# Échec : on consomme quand même une partie des matériaux (choix design)
		_consommer_materiaux(mat_p, materiau_secondaire_id, true)
		if Titres:
			# Pas de progression "réussite" mais on pourrait tracker les échecs plus tard
			pass
		forge_echouee.emit("La forge a échoué… (%d%% de chance)" % int(chance))
		return {}

	# --- Consommation matériaux ---
	_consommer_materiaux(mat_p, materiau_secondaire_id, false)

	# --- Qualité RNG ---
	var qualite := _tirer_qualite(joueur)
	var mult_qualite: float = qualite["mult"]

	# Bonus compétence qualité forge
	if joueur and joueur.has_method("obtenir_bonus"):
		mult_qualite *= (1.0 + joueur.obtenir_bonus("qualite_forge_pourcent") / 100.0)

	# --- Construction de l'objet ---
	var objet := _construire_objet(
		categorie, type_piece, def_type,
		materiau_principal_id, mat_p,
		materiau_secondaire_id, mat_s,
		qualite, mult_qualite
	)

	# --- Ajout inventaire ---
	if Inventaire:
		Inventaire.ajouter_objet(objet, 1)

	# --- Progression titres ---
	if Titres:
		Titres.incrementer_progression("forger_reussite")
		# Qualité max éventuelle
		if qualite["id"] in ["exceptionnel", "legendaire"]:
			Titres.incrementer_progression("craft_qualite_max")

	forge_reussie.emit(objet)
	return objet


# ----------------------------------------------------------
#  INTERNE
# ----------------------------------------------------------
func _consommer_materiaux(mat_p: Dictionary, id_secondaire: String, echec: bool) -> void:
	if not Inventaire:
		return
	var id_p: String = mat_p.get("id_item", "")
	var qte: int = mat_p.get("quantite", 1)
	if echec:
		# En cas d'échec : moitié du principal (arrondi sup), secondaire perdu
		qte = maxi(1, ceili(float(qte) / 2.0))
	Inventaire.retirer_par_id(id_p, qte)
	Inventaire.retirer_par_id(id_secondaire, 1)


func _tirer_qualite(joueur: Node) -> Dictionary:
	var poids_total := 0
	var table: Array = []
	for p in PALIERS_QUALITE:
		var w: int = p["poids"]
		# Les titres / compétences peuvent légèrement biaiser vers le haut
		if joueur and joueur.has_method("obtenir_bonus"):
			var bias: float = joueur.obtenir_bonus("chance_forge_pourcent") * 0.15
			if p["mult"] >= 1.2:
				w = int(w * (1.0 + bias / 100.0))
		table.append({"def": p, "w": w})
		poids_total += w

	var jet := randi() % maxi(poids_total, 1)
	var cumul := 0
	for entry in table:
		cumul += entry["w"]
		if jet < cumul:
			return entry["def"]
	return PALIERS_QUALITE[1]  # fallback "correct"


func _construire_objet(
	categorie: String,
	type_piece: String,
	def_type: Dictionary,
	id_principal: String,
	mat_p: Dictionary,
	id_secondaire: String,
	mat_s: Dictionary,
	qualite: Dictionary,
	mult_qualite: float
) -> Dictionary:
	var nom_piece: String = def_type["nom"]
	var nom_mat: String = mat_p["nom"]
	var nom_qualite: String = qualite["nom"]

	# Nom : "Épée de Fer [Sang] — Excellent"
	var suffixe_sec: String = mat_s["nom"].split(" ")[0]  # court
	var nom := "%s de %s (%s) — %s" % [nom_piece, nom_mat, suffixe_sec, nom_qualite]

	# Couleur finale = lerp matériau principal ↔ teinte secondaire
	var couleur: Color = mat_p["couleur"].lerp(mat_s["teinte"], 0.45)

	var objet := {
		"id": "forge_%s_%s_%s_%d" % [type_piece, id_principal, id_secondaire, randi() % 100000],
		"nom": nom,
		"type": categorie,
		"type_equipement": _resoudre_slot(def_type.get("slot", "")),
		"categorie_forge": categorie,
		"type_piece": type_piece,
		"materiau_principal": id_principal,
		"materiau_secondaire": id_secondaire,
		"qualite": qualite["id"],
		"qualite_nom": nom_qualite,
		"tier": mat_p["tier"],
		"couleur": couleur,
		"max_stack": 1,
		"effets": [],
		"description": "",
	}

	# --- Stat principale ---
	var mult_mat: float = mat_p.get("mult_stat", 1.0)
	var stat_base := 0.0
	match categorie:
		"arme":
			stat_base = STATS_BASE_ARME.get(type_piece, 10.0)
			var degats := stat_base * mult_mat * mult_qualite
			# Petite variance RNG supplémentaire (±8 %)
			degats *= randf_range(0.92, 1.08)
			objet["degats"] = snappedf(degats, 0.1)
			if type_piece == "baton_mage":
				objet["degats_magiques"] = objet["degats"]
				objet["degats"] = snappedf(objet["degats"] * 0.4, 0.1)
		"armure":
			stat_base = STATS_BASE_ARMURE.get(type_piece, 5.0)
			var defense := stat_base * mult_mat * mult_qualite
			defense *= randf_range(0.92, 1.08)
			objet["defense"] = snappedf(defense, 0.1)
		"bonus":
			# Les bonus n'ont pas de grosse stat plate : tout passe par les effets
			pass

	# =====================================================
	#  EFFETS : 1) garanti minerai  2) secondaire  3) RNG minerai
	# =====================================================
	var effets_choisis: Array = []
	var amplif_secondaire: float = 1.0  # Cristal augmente les effets du secondaire

	# --- 1. Effet garanti du minerai principal ---
	var effet_garanti = mat_p.get("effet_garanti", null)
	if effet_garanti != null:
		var resolus := _resoudre_effet_garanti(effet_garanti, categorie, mult_qualite)
		for e in resolus:
			if e.get("type", "") == "amplification_secondaire":
				amplif_secondaire = e.get("valeur", 1.25)
			else:
				effets_choisis.append(e)

	# --- 2. Effets du matériau secondaire (direction + teinte) ---
	var pool_key := "effets_arme"
	match categorie:
		"armure":
			pool_key = "effets_armure"
		"bonus":
			pool_key = "effets_bonus"

	var pool_sec: Array = mat_s.get(pool_key, [])
	var nb_sec := 1
	if qualite["mult"] >= 1.45 and pool_sec.size() >= 2:
		nb_sec = 2
	if qualite["mult"] >= 2.0:
		nb_sec = mini(2, pool_sec.size())

	var pool_sec_mix := pool_sec.duplicate()
	pool_sec_mix.shuffle()
	for i in range(mini(nb_sec, pool_sec_mix.size())):
		var modele: Dictionary = pool_sec_mix[i]
		var valeur: float = randf_range(modele.get("min", 1.0), modele.get("max", 5.0))
		valeur *= mult_qualite * 0.85 * amplif_secondaire
		valeur = snappedf(valeur, 0.1)
		var effet := {"type": modele["type"], "valeur": valeur}
		if modele.has("cible"):
			effet["cible"] = modele["cible"]
		effets_choisis.append(effet)

	# --- 3. Effets RNG supplémentaires selon le minerai (nb_effets_rng) ---
	var nb_rng: int = int(mat_p.get("nb_effets_rng", 0))
	if nb_rng > 0:
		var types_deja: Array[String] = []
		for e in effets_choisis:
			types_deja.append(e.get("type", ""))
		for _i in range(nb_rng):
			var modele := _tirer_effet_rng(categorie, types_deja)
			if modele.is_empty():
				break
			var effet_resolu := _resoudre_effet_rng(modele, mult_qualite)
			effets_choisis.append(effet_resolu)
			# Enregistre type résolu + éventuelle clé modèle pour éviter doublons
			types_deja.append(effet_resolu.get("type", ""))
			if modele.has("cible"):
				types_deja.append("%s:%s" % [modele["type"], modele["cible"]])
			if modele.get("element_aleatoire", false):
				types_deja.append(modele["type"])  # bloque un 2e élément aléatoire

	objet["effets"] = effets_choisis
	if amplif_secondaire > 1.0:
		objet["amplification_secondaire"] = amplif_secondaire

	# Description lisible
	var lignes: PackedStringArray = []
	lignes.append("%s · %s" % [nom_qualite, nom_mat])
	if objet.has("degats"):
		lignes.append("Dégâts : %.1f" % objet["degats"])
	if objet.has("degats_magiques"):
		lignes.append("Dégâts magiques : %.1f" % objet["degats_magiques"])
	if objet.has("defense"):
		lignes.append("Défense : %.1f" % objet["defense"])
	if amplif_secondaire > 1.0:
		lignes.append("Amplification secondaire : ×%.2f" % amplif_secondaire)
	for e in effets_choisis:
		var txt := _format_effet(e)
		if txt != "":
			lignes.append(txt)
	objet["description"] = "\n".join(lignes)

	return objet


## Résout les effets garantis spéciaux (diamant, obsidienne, cristal, orichalque…)
func _resoudre_effet_garanti(modele: Dictionary, categorie: String, mult_qualite: float) -> Array:
	var resultat: Array = []
	var type_g: String = modele.get("type", "")
	var vmin: float = modele.get("min", 1.0)
	var vmax: float = modele.get("max", 5.0)
	var valeur: float = randf_range(vmin, vmax) * mult_qualite * 0.9
	valeur = snappedf(valeur, 0.1)

	match type_g:
		"resistance_orientee", "resistance_elementaire":
			# Tire un élément au hasard
			var elements := ["feu", "glace", "poison", "ombre", "foudre"]
			var elem: String = elements[randi() % elements.size()]
			resultat.append({
				"type": "resistance_%s_pourcent" % elem,
				"valeur": valeur,
			})
		"amplification_secondaire":
			# Pas un effet affiché sur le joueur : multiplicateur interne
			resultat.append({
				"type": "amplification_secondaire",
				"valeur": snappedf(randf_range(vmin, vmax), 0.01),
			})
		"bonus_polyvalent":
			# Petit bonus dégâts + défense
			resultat.append({"type": "degats_pourcent", "valeur": valeur})
			resultat.append({"type": "defense_pourcent", "valeur": snappedf(valeur * 0.8, 0.1)})
		"degats_pourcent_contre_cible":
			var effet := {
				"type": "degats_pourcent_contre_cible",
				"cible": modele.get("cible", ""),
				"valeur": valeur,
			}
			resultat.append(effet)
		_:
			var effet := {"type": type_g, "valeur": valeur}
			if modele.has("cible"):
				effet["cible"] = modele["cible"]
			resultat.append(effet)

	return resultat


func _resoudre_slot(slot: String) -> String:
	if slot == "anneau":
		return "anneau"
	return slot


## Construit la pool pondérée selon la catégorie d'équipement
func _pool_rng_pour_categorie(categorie: String) -> Array:
	var pool: Array = []
	match categorie:
		"arme":
			pool.append_array(POOL_RNG_OFFENSIF)
			pool.append_array(POOL_RNG_CIBLE)
			pool.append_array(POOL_RNG_SPECIAL)
			# Un peu de regen offensive
			for e in POOL_RNG_REGEN:
				if e["type"] in ["recuperation_pv_sur_attaque", "recuperation_pm_sur_attaque", "absorption_pm_pourcent"]:
					pool.append(e)
		"armure":
			pool.append_array(POOL_RNG_DEFENSIF)
			pool.append_array(POOL_RNG_REGEN)
			pool.append_array(POOL_RNG_SPECIAL)
		"bonus":
			pool.append_array(POOL_RNG_OFFENSIF)
			pool.append_array(POOL_RNG_DEFENSIF)
			pool.append_array(POOL_RNG_REGEN)
			pool.append_array(POOL_RNG_SPECIAL)
			pool.append_array(POOL_RNG_CIBLE)
		_:
			pool.append_array(POOL_RNG_OFFENSIF)
			pool.append_array(POOL_RNG_DEFENSIF)
	return pool


## Tire un modèle d'effet RNG (avec chance rare + poids)
func _tirer_effet_rng(categorie: String, types_deja: Array[String]) -> Dictionary:
	# Chance de tirer dans la pool rare
	if randf() < CHANCE_EFFET_RARE:
		var rares_dispo: Array = []
		for e in POOL_RNG_RARE:
			var cle := e["type"]
			if cle not in types_deja:
				rares_dispo.append(e)
		if rares_dispo.size() > 0:
			return _tirer_pondere(rares_dispo)

	var pool := _pool_rng_pour_categorie(categorie)
	var dispo: Array = []
	for e in pool:
		# Clé unique : type ou type:cible pour les bonus spécialisés
		var cle: String = e["type"]
		if e.has("cible"):
			cle = "%s:%s" % [e["type"], e["cible"]]
		# Les éléments se distinguent après résolution — on autorise un seul "degats_elementaires"
		if cle in types_deja:
			continue
		if e.get("element_aleatoire", false) and e["type"] in types_deja:
			continue
		# Même type sans cible = doublon (sauf contre_cible déjà géré)
		if not e.has("cible") and e["type"] in types_deja:
			continue
		dispo.append(e)

	if dispo.is_empty():
		return {}
	return _tirer_pondere(dispo)


func _tirer_pondere(pool: Array) -> Dictionary:
	var total := 0
	for e in pool:
		total += int(e.get("poids", 1))
	if total <= 0:
		return pool[randi() % pool.size()]
	var jet := randi() % total
	var cumul := 0
	for e in pool:
		cumul += int(e.get("poids", 1))
		if jet < cumul:
			return e
	return pool[pool.size() - 1]


## Résout un modèle en effet concret (élément aléatoire, valeur, etc.)
func _resoudre_effet_rng(modele: Dictionary, mult_qualite: float) -> Dictionary:
	var valeur: float = randf_range(modele.get("min", 1.0), modele.get("max", 5.0))
	valeur *= mult_qualite * 0.8
	valeur = snappedf(valeur, 0.1)

	var type_final: String = modele["type"]
	var effet := {"type": type_final, "valeur": valeur}

	# Élément aléatoire pour dégâts ou résistance
	if modele.get("element_aleatoire", false):
		var elem: String = ELEMENTS_DEGATS[randi() % ELEMENTS_DEGATS.size()]
		if type_final == "degats_elementaires":
			effet["type"] = "degats_%s_pourcent" % elem
		elif type_final == "resistance_element_aleatoire":
			effet["type"] = "resistance_%s_pourcent" % elem
		effet["element"] = elem

	if modele.has("cible"):
		effet["cible"] = modele["cible"]

	# Flags purement comportementaux (valeur symbolique)
	if type_final in ["dernier_souffle", "second_souffle", "affinite_categorie"]:
		effet["valeur"] = 1.0
		effet["comportemental"] = true

	return effet


func _format_effet(effet: Dictionary) -> String:
	var t: String = effet.get("type", "")
	var v: float = effet.get("valeur", 0.0)
	var cible: String = effet.get("cible", "")
	var elem: String = effet.get("element", "")

	match t:
		"degats_pourcent":
			return "+%.1f %% dégâts" % v
		"tranchant_pourcent":
			return "+%.1f %% dégâts tranchants" % v
		"perforation_pourcent":
			return "+%.1f %% perforation" % v
		"brutalite_pourcent":
			return "+%.1f %% brutalité (vs PV hauts)" % v
		"execution_pourcent":
			return "+%.1f %% exécution (vs PV bas)" % v
		"degats_critique_pourcent":
			return "+%.1f %% dégâts critiques" % v
		"chance_critique_pourcent":
			return "+%.1f %% chance critique" % v
		"vitesse_attaque_pourcent":
			return "+%.1f %% vitesse d'attaque" % v
		"vol_de_vie_pourcent":
			return "+%.1f %% vol de vie" % v
		"absorption_pm_pourcent":
			return "+%.1f %% absorption de PM" % v
		"degats_feu_pourcent":
			return "+%.1f %% dégâts de feu" % v
		"degats_glace_pourcent":
			return "+%.1f %% dégâts de glace" % v
		"degats_electricite_pourcent":
			return "+%.1f %% dégâts électriques" % v
		"degats_lumiere_pourcent":
			return "+%.1f %% dégâts de lumière" % v
		"degats_tenebres_pourcent":
			return "+%.1f %% dégâts de ténèbres" % v
		"degats_metal_pourcent":
			return "+%.1f %% dégâts métalliques" % v
		"degats_ombre_pourcent":
			return "+%.1f %% dégâts d'ombre" % v
		"pv_max_pourcent":
			return "+%.1f %% PV max" % v
		"resistance_pourcent", "defense_pourcent":
			return "+%.1f %% résistance" % v
		"resistance_physique_pourcent":
			return "+%.1f %% rés. physique" % v
		"resistance_magique_pourcent":
			return "+%.1f %% rés. magique" % v
		"resistance_elementaire_pourcent":
			return "+%.1f %% rés. élémentaire" % v
		"resistance_feu_pourcent":
			return "+%.1f %% rés. feu" % v
		"resistance_glace_pourcent":
			return "+%.1f %% rés. glace" % v
		"resistance_electricite_pourcent":
			return "+%.1f %% rés. électrique" % v
		"resistance_lumiere_pourcent":
			return "+%.1f %% rés. lumière" % v
		"resistance_tenebres_pourcent":
			return "+%.1f %% rés. ténèbres" % v
		"resistance_metal_pourcent":
			return "+%.1f %% rés. métal" % v
		"reduction_degats_recus_pourcent":
			return "-%.1f %% dégâts reçus" % v
		"reduction_degats_critiques_recus_pourcent":
			return "-%.1f %% dégâts critiques reçus" % v
		"regeneration_pv_restants_par_seconde":
			return "Régén. %.1f %% PV restants / s" % v
		"regeneration_pm_pourcent":
			return "+%.1f %% régén. PM" % v
		"regeneration_apres_degat_pourcent":
			return "+%.1f %% régén. après dégât" % v
		"recuperation_pv_sur_attaque":
			return "+%.1f PV récupérés par attaque" % v
		"recuperation_pm_sur_attaque":
			return "+%.1f PM récupérés par attaque" % v
		"reduction_cout_pm_pourcent":
			return "-%.1f %% coût en PM" % v
		"vitesse_pourcent":
			return "+%.1f %% vitesse" % v
		"resistance_effets_negatifs_pourcent":
			return "+%.1f %% rés. effets négatifs" % v
		"resistance_alterations_elementaires_pourcent":
			return "+%.1f %% rés. altérations élémentaires" % v
		"durabilite_pourcent":
			return "+%.1f %% durabilité" % v
		"puissance_forge_secondaire_pourcent":
			return "+%.1f %% puissance du secondaire" % v
		"degats_pourcent_contre_cible":
			return "+%.1f %% dégâts vs %s" % [v, cible]
		"dernier_souffle":
			return "Dernier souffle (bonus à PV bas)"
		"second_souffle":
			return "Second souffle (récup. après PV critiques)"
		"reflexion_degats_pourcent":
			return "+%.1f %% réflexion des dégâts" % v
		"double_impact_chance":
			return "+%.1f %% chance de double impact" % v
		"drain_pourcent":
			return "+%.1f %% drain (vie + PM)" % v
		"amplification_effets_pourcent":
			return "+%.1f %% amplification des autres effets" % v
		"affinite_categorie":
			return "Affinité (biaise les prochains RNG)"
		_:
			if elem != "":
				return "+%.1f %% %s (%s)" % [v, t.replace("_", " "), elem]
			return "+%.1f %% %s" % [v, t.replace("_", " ")]

```


============================================================
## FICHIER : `forge_ui.gd`
============================================================

```gdscript
extends Control

# ==========================================================
#  OBSIDIAN HORIZON — Interface de Forge (choix guidés)
#  Étapes : Catégorie → Type → Principal → Secondaire → Forger
# ==========================================================

signal fermer_demande

var etape: int = 0  # 0 cat, 1 type, 2 principal, 3 secondaire, 4 résumé

var categorie_choisie: String = ""
var type_choisi: String = ""
var principal_choisi: String = ""
var secondaire_choisi: String = ""

var conteneur: VBoxContainer
var label_titre: Label
var label_chance: Label
var conteneur_choix: VBoxContainer
var bouton_retour: Button
var bouton_forger: Button
var label_resultat: Label

var joueur: Node = null


func _ready() -> void:
	visible = false
	_construire()
	joueur = get_tree().get_first_node_in_group("joueur")


func ouvrir() -> void:
	visible = true
	etape = 0
	categorie_choisie = ""
	type_choisi = ""
	principal_choisi = ""
	secondaire_choisi = ""
	label_resultat.text = ""
	_rafraichir()


func fermer() -> void:
	visible = false
	fermer_demande.emit()


func _construire() -> void:
	set_anchors_preset(Control.PRESET_CENTER)
	custom_minimum_size = Vector2(480, 520)

	var fond := Panel.new()
	fond.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(fond)

	conteneur = VBoxContainer.new()
	conteneur.set_anchors_preset(Control.PRESET_FULL_RECT)
	conteneur.add_theme_constant_override("separation", 8)
	add_child(conteneur)

	label_titre = Label.new()
	label_titre.text = "Forge"
	label_titre.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label_titre.add_theme_font_size_override("font_size", 22)
	conteneur.add_child(label_titre)

	label_chance = Label.new()
	label_chance.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	conteneur.add_child(label_chance)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.custom_minimum_size = Vector2(0, 280)
	conteneur.add_child(scroll)

	conteneur_choix = VBoxContainer.new()
	conteneur_choix.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(conteneur_choix)

	label_resultat = Label.new()
	label_resultat.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label_resultat.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	conteneur.add_child(label_resultat)

	var ligne_boutons := HBoxContainer.new()
	conteneur.add_child(ligne_boutons)

	bouton_retour = Button.new()
	bouton_retour.text = "Retour"
	bouton_retour.pressed.connect(_on_retour)
	ligne_boutons.add_child(bouton_retour)

	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ligne_boutons.add_child(spacer)

	bouton_forger = Button.new()
	bouton_forger.text = "Forger"
	bouton_forger.pressed.connect(_on_forger)
	ligne_boutons.add_child(bouton_forger)

	var bouton_fermer := Button.new()
	bouton_fermer.text = "Fermer"
	bouton_fermer.pressed.connect(fermer)
	ligne_boutons.add_child(bouton_fermer)


func _rafraichir() -> void:
	for c in conteneur_choix.get_children():
		c.queue_free()

	bouton_forger.disabled = true
	label_chance.text = ""

	match etape:
		0:
			label_titre.text = "Forge — Choisir une catégorie"
			for cat in Forge.obtenir_categories():
				var def = Forge.CATEGORIES[cat]
				_ajouter_bouton_choix(def["nom"], _choisir_categorie.bind(cat))
		1:
			label_titre.text = "Forge — Type de pièce (%s)" % Forge.CATEGORIES[categorie_choisie]["nom"]
			for t in Forge.obtenir_types(categorie_choisie):
				var def = Forge.CATEGORIES[categorie_choisie]["types"][t]
				_ajouter_bouton_choix(def["nom"], _choisir_type.bind(t))
		2:
			label_titre.text = "Forge — Matériau principal"
			for mat in Forge.obtenir_materiaux_principaux_disponibles():
				var txt := "%s (×%d) · T%d · +%d RNG" % [
					mat["nom"], mat["quantite_requise"], mat["tier"], mat.get("nb_effets_rng", 0)
				]
				var eg: String = str(mat.get("effet_garanti_desc", "Aucun"))
				if eg != "Aucun":
					txt += " | Garanti : %s" % eg
				if not mat["disponible"]:
					txt += "  [manque]"
				var btn := _ajouter_bouton_choix(txt, _choisir_principal.bind(mat["id"]))
				btn.disabled = not mat["disponible"]
		3:
			label_titre.text = "Forge — Matériau secondaire (drop)"
			for mat in Forge.obtenir_materiaux_secondaires_disponibles():
				var tags: String = ", ".join(mat.get("tags", []))
				var txt := "%s  [%s]" % [mat["nom"], tags]
				if not mat["disponible"]:
					txt += "  [manque]"
				var btn := _ajouter_bouton_choix(txt, _choisir_secondaire.bind(mat["id"]))
				btn.disabled = not mat["disponible"]
		4:
			label_titre.text = "Forge — Confirmer"
			var resume := "Catégorie : %s\nPièce : %s\nPrincipal : %s\nSecondaire : %s" % [
				categorie_choisie, type_choisi, principal_choisi, secondaire_choisi
			]
			var lbl := Label.new()
			lbl.text = resume
			lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
			conteneur_choix.add_child(lbl)

			if joueur == null:
				joueur = get_tree().get_first_node_in_group("joueur")
			var chance := Forge.calculer_chance_reussite(joueur, principal_choisi)
			label_chance.text = "Chance de réussite : %d %%" % int(chance)
			bouton_forger.disabled = false


func _ajouter_bouton_choix(texte: String, callable: Callable) -> Button:
	var btn := Button.new()
	btn.text = texte
	btn.pressed.connect(callable)
	conteneur_choix.add_child(btn)
	return btn


func _choisir_categorie(cat: String) -> void:
	categorie_choisie = cat
	etape = 1
	_rafraichir()


func _choisir_type(t: String) -> void:
	type_choisi = t
	etape = 2
	_rafraichir()


func _choisir_principal(id: String) -> void:
	principal_choisi = id
	etape = 3
	_rafraichir()


func _choisir_secondaire(id: String) -> void:
	secondaire_choisi = id
	etape = 4
	_rafraichir()


func _on_retour() -> void:
	if etape <= 0:
		fermer()
		return
	etape -= 1
	label_resultat.text = ""
	_rafraichir()


func _on_forger() -> void:
	if joueur == null:
		joueur = get_tree().get_first_node_in_group("joueur")

	var objet := Forge.forger(
		categorie_choisie,
		type_choisi,
		principal_choisi,
		secondaire_choisi,
		joueur
	)

	if objet.is_empty():
		label_resultat.text = "Échec de la forge…"
		label_resultat.modulate = Color(1.0, 0.4, 0.4)
	else:
		label_resultat.text = "Succès !\n%s\n%s" % [objet.get("nom", "?"), objet.get("description", "")]
		label_resultat.modulate = Color(0.5, 1.0, 0.5)
		# Reset pour enchaîner
		etape = 0
		categorie_choisie = ""
		type_choisi = ""
		principal_choisi = ""
		secondaire_choisi = ""
		_rafraichir()

```


============================================================
## FICHIER : `ennemi.gd`
============================================================

```gdscript
extends CharacterBody3D
class_name Ennemi

# ==========================================================
#  OBSIDIAN HORIZON — Ennemi basique (loup, monstre…)
#  Low-poly, IA simple, drops + progression titres.
# ==========================================================

@export var id_mob: String = "loup"
@export var categories: Array[String] = ["etre_vivant", "sauvage", "monstre"]
@export var nom: String = "Loup"

@export var PV_max: float = 40.0
var PV_actuels: float = 40.0

@export var degats: float = 8.0
@export var vitesse: float = 3.5
@export var distance_detection: float = 18.0
@export var distance_attaque: float = 2.2
@export var cooldown_attaque: float = 1.1
@export var experience_drop: int = 0  # non utilisé (pas de niveaux)

@export var drops: Array[Dictionary] = [
	{"id": "peau_loup", "chance": 0.55, "quantite": 1},
	{"id": "viande_cru", "chance": 0.4, "quantite": 1},
	{"id": "os_renforces", "chance": 0.25, "quantite": 1},
	{"id": "fiole_sang_monstre", "chance": 0.15, "quantite": 1},
	{"id": "croc_alpha", "chance": 0.05, "quantite": 1},
]

var joueur: Node3D = null
var _timer_attaque: float = 0.0
var _est_mort: bool = false
var mesh_instance: MeshInstance3D


func _ready() -> void:
	PV_actuels = PV_max
	add_to_group("ennemis")
	_creer_apparence_lowpoly()
	# Collision simple
	if not has_node("CollisionShape3D"):
		var col := CollisionShape3D.new()
		var shape := CapsuleShape3D.new()
		shape.radius = 0.4
		shape.height = 1.0
		col.shape = shape
		col.position.y = 0.6
		add_child(col)


func _creer_apparence_lowpoly() -> void:
	mesh_instance = MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = Vector3(0.7, 0.9, 1.1)
	mesh_instance.mesh = box
	mesh_instance.position.y = 0.5

	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.45, 0.38, 0.32)
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_PER_VERTEX
	mesh_instance.material_override = mat
	add_child(mesh_instance)

	# "Tête"
	var tete := MeshInstance3D.new()
	var sphere := SphereMesh.new()
	sphere.radius = 0.28
	sphere.height = 0.5
	tete.mesh = sphere
	tete.position = Vector3(0, 1.0, 0.35)
	var mat2 := mat.duplicate()
	mat2.albedo_color = Color(0.4, 0.33, 0.28)
	tete.material_override = mat2
	add_child(tete)


func _physics_process(delta: float) -> void:
	if _est_mort:
		return

	if _timer_attaque > 0.0:
		_timer_attaque -= delta

	if joueur == null:
		joueur = get_tree().get_first_node_in_group("joueur")
		return

	var dist := global_position.distance_to(joueur.global_position)

	if dist > distance_detection:
		velocity = velocity.move_toward(Vector3.ZERO, 8.0 * delta)
		move_and_slide()
		return

	# Poursuite
	var dir := (joueur.global_position - global_position)
	dir.y = 0
	dir = dir.normalized()

	if dist > distance_attaque:
		velocity.x = dir.x * vitesse
		velocity.z = dir.z * vitesse
		# Orientation
		if dir.length() > 0.01:
			look_at(global_position + dir, Vector3.UP)
	else:
		velocity.x = 0
		velocity.z = 0
		if _timer_attaque <= 0.0:
			_attaquer()

	# Gravité simple
	if not is_on_floor():
		velocity.y -= 18.0 * delta
	else:
		velocity.y = 0

	move_and_slide()


func _attaquer() -> void:
	_timer_attaque = cooldown_attaque
	if joueur and joueur.has_method("recevoir_degats"):
		joueur.recevoir_degats(degats, self)


func recevoir_degats(montant: float, source: Node = null) -> void:
	if _est_mort:
		return
	PV_actuels -= montant
	# Flash blanc rapide
	if mesh_instance and mesh_instance.material_override:
		var mat: StandardMaterial3D = mesh_instance.material_override
		mat.albedo_color = Color.WHITE
		get_tree().create_timer(0.08).timeout.connect(func():
			if is_instance_valid(mat):
				mat.albedo_color = Color(0.45, 0.38, 0.32)
		)

	if PV_actuels <= 0.0:
		_mourir(source)


func _mourir(source: Node = null) -> void:
	_est_mort = true
	PV_actuels = 0.0

	# Progression titres
	if Titres and source and source.is_in_group("joueur"):
		var contexte := {}
		# Le combat pourra enrichir le contexte (sans_magie, seul, element…)
		Titres.incrementer_progression("tuer", id_mob, categories, contexte)

	# Drops
	_donner_drops(source)

	# Disparition
	var tween := create_tween()
	tween.tween_property(self, "scale", Vector3.ZERO, 0.35)
	tween.tween_callback(queue_free)


func _donner_drops(source: Node) -> void:
	if source == null or not source.is_in_group("joueur"):
		return
	var mult_drop: float = 1.0
	if "taux_drop_final" in source:
		mult_drop = source.taux_drop_final

	for drop in drops:
		var chance: float = drop.get("chance", 0.0) * mult_drop
		if randf() <= chance:
			if Inventaire:
				Inventaire.ajouter_par_id(drop.get("id", ""), drop.get("quantite", 1))

```


============================================================
## FICHIER : `ressource_node.gd`
============================================================

```gdscript
extends StaticBody3D
class_name RessourceNode

# ==========================================================
#  OBSIDIAN HORIZON — Nœud de ressource (arbre, filon…)
#  Interaction E → récolte progressive.
# ==========================================================

enum TypeRessource { ARBRE, MINERAI, PLANTE }

@export var type: TypeRessource = TypeRessource.ARBRE
@export var id_drop: String = "bois"
@export var quantite_par_coup: int = 1
@export var coups_necessaires: int = 4
@export var nom_affichage: String = "Arbre"

var coups_restants: int = 4
var mesh_instance: MeshInstance3D


func _ready() -> void:
	coups_restants = coups_necessaires
	_creer_apparence()
	# Collision
	if not has_node("CollisionShape3D"):
		var col := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		match type:
			TypeRessource.ARBRE:
				shape.size = Vector3(0.6, 2.5, 0.6)
				col.position.y = 1.25
			TypeRessource.MINERAI:
				shape.size = Vector3(1.2, 0.8, 1.0)
				col.position.y = 0.4
			_:
				shape.size = Vector3(0.5, 0.5, 0.5)
				col.position.y = 0.25
		col.shape = shape
		add_child(col)


func _creer_apparence() -> void:
	mesh_instance = MeshInstance3D.new()
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_PER_VERTEX

	match type:
		TypeRessource.ARBRE:
			# Tronc
			var tronc := CylinderMesh.new()
			tronc.top_radius = 0.18
			tronc.bottom_radius = 0.25
			tronc.height = 2.2
			mesh_instance.mesh = tronc
			mesh_instance.position.y = 1.1
			mat.albedo_color = Color(0.4, 0.28, 0.15)
			mesh_instance.material_override = mat
			add_child(mesh_instance)

			# Feuillage low-poly
			var feuilles := MeshInstance3D.new()
			var sphere := SphereMesh.new()
			sphere.radius = 0.9
			sphere.height = 1.6
			feuilles.mesh = sphere
			feuilles.position.y = 2.6
			var mat_f := mat.duplicate()
			mat_f.albedo_color = Color(0.25, 0.5, 0.2)
			feuilles.material_override = mat_f
			add_child(feuilles)

		TypeRessource.MINERAI:
			var box := BoxMesh.new()
			box.size = Vector3(1.1, 0.7, 0.9)
			mesh_instance.mesh = box
			mesh_instance.position.y = 0.35
			mat.albedo_color = Color(0.5, 0.48, 0.45)
			mesh_instance.material_override = mat
			add_child(mesh_instance)

			# Cristaux
			var cristal := MeshInstance3D.new()
			var cmesh := BoxMesh.new()
			cmesh.size = Vector3(0.25, 0.5, 0.25)
			cristal.mesh = cmesh
			cristal.position = Vector3(0.2, 0.7, 0.1)
			cristal.rotation_degrees = Vector3(15, 30, 10)
			var mat_c := mat.duplicate()
			mat_c.albedo_color = Color(0.55, 0.6, 0.7)
			cristal.material_override = mat_c
			add_child(cristal)

		_:
			var box := BoxMesh.new()
			box.size = Vector3(0.4, 0.4, 0.4)
			mesh_instance.mesh = box
			mesh_instance.position.y = 0.2
			mat.albedo_color = Color(0.3, 0.6, 0.25)
			mesh_instance.material_override = mat
			add_child(mesh_instance)


func interagir(joueur: Node) -> void:
	if coups_restants <= 0:
		return

	coups_restants -= 1

	# Feedback scale
	var tween := create_tween()
	tween.tween_property(self, "scale", Vector3(0.92, 1.05, 0.92), 0.06)
	tween.tween_property(self, "scale", Vector3.ONE, 0.08)

	if Inventaire:
		Inventaire.ajouter_par_id(id_drop, quantite_par_coup)

	# Progression titres
	if Titres:
		match type:
			TypeRessource.ARBRE:
				Titres.incrementer_progression("abattre_arbre")
			TypeRessource.MINERAI:
				Titres.incrementer_progression("miner")

	if coups_restants <= 0:
		_detruire()


func _detruire() -> void:
	var tween := create_tween()
	tween.tween_property(self, "scale", Vector3.ZERO, 0.3)
	tween.tween_callback(queue_free)

```


============================================================
## FICHIER : `chunk.gd`
============================================================

```gdscript
extends Node3D
class_name Chunk

# ==========================================================
#  OBSIDIAN HORIZON — Un chunk de terrain low-poly
#  Généré procéduralement, style Tunic (facettes visibles).
# ==========================================================

var coord: Vector2i = Vector2i.ZERO
var chunk_size: float = 64.0
var resolution: int = 16
var amplitude: float = 12.0
var bruit: FastNoiseLite
var world_size_chunks: int = 32

var couleur_herbe: Color = Color(0.35, 0.55, 0.25)
var couleur_roche: Color = Color(0.45, 0.42, 0.38)
var couleur_sable: Color = Color(0.75, 0.68, 0.45)

var mesh_instance: MeshInstance3D
var collision: StaticBody3D
var col_shape: CollisionShape3D


func generer() -> void:
	_creer_mesh()
	_creer_collision()
	_peupler()


func _creer_mesh() -> void:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)

	var step: float = chunk_size / float(resolution)
	# Origine logique du chunk (pour le bruit, on utilise les coords wrappées)
	var origin_x: float = coord.x * chunk_size
	var origin_z: float = coord.y * chunk_size

	# Grille de hauteurs
	var hauteurs: Array = []
	hauteurs.resize(resolution + 1)
	for i in range(resolution + 1):
		hauteurs[i] = []
		hauteurs[i].resize(resolution + 1)
		for j in range(resolution + 1):
			var wx: float = origin_x + i * step
			var wz: float = origin_z + j * step
			# Bruit avec wrap (monde torique)
			var taille_monde: float = world_size_chunks * chunk_size
			var nx: float = fposmod(wx, taille_monde)
			var nz: float = fposmod(wz, taille_monde)
			hauteurs[i][j] = bruit.get_noise_2d(nx, nz) * amplitude

	# Construction des triangles (low-poly = normals non interpolés)
	for i in range(resolution):
		for j in range(resolution):
			var p00 := Vector3(i * step, hauteurs[i][j], j * step)
			var p10 := Vector3((i + 1) * step, hauteurs[i + 1][j], j * step)
			var p01 := Vector3(i * step, hauteurs[i][j + 1], (j + 1) * step)
			var p11 := Vector3((i + 1) * step, hauteurs[i + 1][j + 1], (j + 1) * step)

			# Deux triangles par quad
			_ajouter_triangle(st, p00, p10, p11)
			_ajouter_triangle(st, p00, p11, p01)

	st.generate_normals()
	# Pas de generate_tangents → look low-poly plus franc

	var mesh := st.commit()
	mesh_instance = MeshInstance3D.new()
	mesh_instance.mesh = mesh

	# Matériau simple unlit / low-poly
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 0.9
	mat.metallic = 0.0
	# Shading un peu plat
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_PER_VERTEX
	mesh_instance.material_override = mat

	add_child(mesh_instance)


func _ajouter_triangle(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3) -> void:
	# Couleur selon la hauteur moyenne (herbe / roche / sable)
	var h_moy: float = (a.y + b.y + c.y) / 3.0
	var col: Color
	if h_moy < -2.0:
		col = couleur_sable
	elif h_moy > 6.0:
		col = couleur_roche.lerp(Color(0.7, 0.7, 0.75), clampf((h_moy - 6.0) / 8.0, 0.0, 1.0))
	else:
		col = couleur_herbe.lerp(couleur_roche, clampf(h_moy / 8.0, 0.0, 0.4))

	# Variation légère pour casser la uniformité
	col = col.lightened(randf_range(-0.04, 0.04))

	st.set_color(col)
	st.add_vertex(a)
	st.set_color(col)
	st.add_vertex(b)
	st.set_color(col)
	st.add_vertex(c)


func _creer_collision() -> void:
	# Collision simplifiée : on utilise le même mesh (concave)
	if mesh_instance == null or mesh_instance.mesh == null:
		return

	collision = StaticBody3D.new()
	col_shape = CollisionShape3D.new()

	# Shape concave à partir du mesh (ok pour terrain statique)
	var shape := ConcavePolygonShape3D.new()
	# On extrait les faces
	var faces: PackedVector3Array = mesh_instance.mesh.get_faces()
	shape.set_faces(faces)
	col_shape.shape = shape

	collision.add_child(col_shape)
	add_child(collision)


func _peupler() -> void:
	# Seed déterministe par chunk pour un monde reproductible
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(coord) + 1337

	var origin_x: float = coord.x * chunk_size
	var origin_z: float = coord.y * chunk_size
	var taille_monde: float = world_size_chunks * chunk_size

	# Arbres
	var nb_arbres := rng.randi_range(2, 7)
	for i in range(nb_arbres):
		var lx := rng.randf() * chunk_size
		var lz := rng.randf() * chunk_size
		var wx := fposmod(origin_x + lx, taille_monde)
		var wz := fposmod(origin_z + lz, taille_monde)
		var h := bruit.get_noise_2d(wx, wz) * amplitude
		# Pas d'arbres trop bas (plage) ni trop haut (roche)
		if h < -1.5 or h > 7.0:
			continue
		var arbre := RessourceNode.new()
		arbre.type = RessourceNode.TypeRessource.ARBRE
		arbre.id_drop = "bois"
		arbre.quantite_par_coup = 1
		arbre.coups_necessaires = 4
		arbre.nom_affichage = "Arbre"
		arbre.position = Vector3(lx, h, lz)
		add_child(arbre)

	# Minerais (plus rares, zones rocheuses)
	var nb_minerais := rng.randi_range(0, 2)
	for i in range(nb_minerais):
		var lx := rng.randf() * chunk_size
		var lz := rng.randf() * chunk_size
		var wx := fposmod(origin_x + lx, taille_monde)
		var wz := fposmod(origin_z + lz, taille_monde)
		var h := bruit.get_noise_2d(wx, wz) * amplitude
		if h < 3.0:
			continue
		var filon := RessourceNode.new()
		filon.type = RessourceNode.TypeRessource.MINERAI
		filon.id_drop = "minerai_fer"
		filon.quantite_par_coup = 1
		filon.coups_necessaires = 5
		filon.nom_affichage = "Filon de fer"
		filon.position = Vector3(lx, h, lz)
		add_child(filon)

	# Ennemis occasionnels (loups)
	if rng.randf() < 0.35:
		var lx := rng.randf() * chunk_size
		var lz := rng.randf() * chunk_size
		var wx := fposmod(origin_x + lx, taille_monde)
		var wz := fposmod(origin_z + lz, taille_monde)
		var h := bruit.get_noise_2d(wx, wz) * amplitude
		if h > -1.0 and h < 8.0:
			var loup := Ennemi.new()
			loup.id_mob = "loup"
			loup.categories = ["etre_vivant", "sauvage", "monstre"]
			loup.nom = "Loup"
			loup.PV_max = 35.0
			loup.degats = 7.0
			loup.position = Vector3(lx, h + 0.5, lz)
			add_child(loup)

```


============================================================
## FICHIER : `world_manager.gd`
============================================================

```gdscript
extends Node3D
class_name WorldManager

# ==========================================================
#  OBSIDIAN HORIZON — Gestionnaire de monde sans barrières
#  Style low-poly (Tunic-like) + streaming de chunks
#  + wrap-around (nord↔sud, est↔ouest).
#
#  Principe :
#  - Le monde a une taille fixe en chunks (WORLD_SIZE_CHUNKS).
#  - Les coordonnées sont modulaires → le monde se referme sur lui-même.
#  - On ne charge que les chunks proches du joueur (VIEW_RADIUS).
#  - Quand le joueur s'approche d'un bord, les chunks de l'autre
#    côté sont pré-chargés comme s'ils étaient contigus.
# ==========================================================

signal chunk_charge(coord: Vector2i)
signal chunk_decharge(coord: Vector2i)

# ----------------------------------------------------------
#  CONFIGURATION
# ----------------------------------------------------------
@export_group("Monde")
## Taille d'un chunk en unités monde (mètres)
@export var CHUNK_SIZE: float = 64.0
## Nombre de chunks sur un côté du monde (ex: 32 → 32×32 chunks)
@export var WORLD_SIZE_CHUNKS: int = 32
## Rayon de chargement autour du joueur (en chunks)
@export var VIEW_RADIUS: int = 3
## Rayon de pré-chargement (légèrement plus large)
@export var PRELOAD_RADIUS: int = 4

@export_group("Terrain low-poly")
@export var amplitude_relief: float = 12.0
@export var echelle_bruit: float = 0.03
@export var resolution_mesh: int = 16          # subdivisions par chunk (low-poly)
@export var couleur_herbe: Color = Color(0.35, 0.55, 0.25)
@export var couleur_roche: Color = Color(0.45, 0.42, 0.38)
@export var couleur_sable: Color = Color(0.75, 0.68, 0.45)

# ----------------------------------------------------------
#  ÉTAT
# ----------------------------------------------------------
var chunks_charges: Dictionary = {}           # Vector2i → Chunk
var joueur: Node3D = null
var dernier_chunk_joueur: Vector2i = Vector2i(9999, 9999)

var bruit: FastNoiseLite


func _ready() -> void:
	bruit = FastNoiseLite.new()
	bruit.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	bruit.seed = 42                           # change pour un autre monde
	bruit.frequency = echelle_bruit
	bruit.fractal_octaves = 4

	# Cherche le joueur
	await get_tree().process_frame
	_trouver_joueur()


func _trouver_joueur() -> void:
	joueur = get_tree().get_first_node_in_group("joueur")
	if joueur == null:
		# Fallback : cherche un CharacterBody3D
		for n in get_tree().get_nodes_in_group("joueur"):
			joueur = n
			break
	if joueur == null:
		push_warning("WorldManager : aucun joueur trouvé (groupe 'joueur').")


func _process(_delta: float) -> void:
	if joueur == null:
		_trouver_joueur()
		return

	var chunk_actuel := _position_vers_chunk(joueur.global_position)
	if chunk_actuel != dernier_chunk_joueur:
		dernier_chunk_joueur = chunk_actuel
		_mettre_a_jour_chunks(chunk_actuel)


# ----------------------------------------------------------
#  COORDONNÉES & WRAP
# ----------------------------------------------------------
## Convertit une position monde en coordonnée de chunk (avec wrap)
func _position_vers_chunk(pos: Vector3) -> Vector2i:
	var cx := int(floor(pos.x / CHUNK_SIZE))
	var cz := int(floor(pos.z / CHUNK_SIZE))
	return _wrap_chunk(Vector2i(cx, cz))


## Applique le modulo pour le wrap-around
func _wrap_chunk(coord: Vector2i) -> Vector2i:
	var x := posmod(coord.x, WORLD_SIZE_CHUNKS)
	var z := posmod(coord.y, WORLD_SIZE_CHUNKS)
	return Vector2i(x, z)


## Distance toroïdale entre deux chunks (prend le chemin le plus court)
func _distance_toroidale(a: Vector2i, b: Vector2i) -> float:
	var dx := abs(a.x - b.x)
	var dz := abs(a.y - b.y)
	dx = mini(dx, WORLD_SIZE_CHUNKS - dx)
	dz = mini(dz, WORLD_SIZE_CHUNKS - dz)
	return sqrt(float(dx * dx + dz * dz))


## Position monde "dépliée" d'un chunk par rapport au joueur
## (pour que le rendu soit contigu même au bord)
func _position_rendu_chunk(coord: Vector2i, centre: Vector2i) -> Vector3:
	# On choisit le représentant le plus proche du centre (joueur)
	var dx := coord.x - centre.x
	var dz := coord.y - centre.y

	if dx > WORLD_SIZE_CHUNKS / 2:
		dx -= WORLD_SIZE_CHUNKS
	elif dx < -WORLD_SIZE_CHUNKS / 2:
		dx += WORLD_SIZE_CHUNKS

	if dz > WORLD_SIZE_CHUNKS / 2:
		dz -= WORLD_SIZE_CHUNKS
	elif dz < -WORLD_SIZE_CHUNKS / 2:
		dz += WORLD_SIZE_CHUNKS

	return Vector3(
		(centre.x + dx) * CHUNK_SIZE,
		0.0,
		(centre.y + dz) * CHUNK_SIZE
	)


# ----------------------------------------------------------
#  STREAMING
# ----------------------------------------------------------
func _mettre_a_jour_chunks(centre: Vector2i) -> void:
	var a_garder: Dictionary = {}

	# 1. Déterminer les chunks à charger (cercle + wrap)
	for dx in range(-PRELOAD_RADIUS, PRELOAD_RADIUS + 1):
		for dz in range(-PRELOAD_RADIUS, PRELOAD_RADIUS + 1):
			var dist := sqrt(float(dx * dx + dz * dz))
			if dist > PRELOAD_RADIUS + 0.5:
				continue

			var coord := _wrap_chunk(Vector2i(centre.x + dx, centre.y + dz))
			a_garder[coord] = true

			if not chunks_charges.has(coord):
				_charger_chunk(coord, centre)
			else:
				# Repositionne si nécessaire (wrap visuel)
				var chunk: Node3D = chunks_charges[coord]
				chunk.position = _position_rendu_chunk(coord, centre)

	# 2. Décharger les chunks trop loin
	var a_supprimer: Array[Vector2i] = []
	for coord in chunks_charges.keys():
		if not a_garder.has(coord):
			a_supprimer.append(coord)

	for coord in a_supprimer:
		_decharger_chunk(coord)


func _charger_chunk(coord: Vector2i, centre: Vector2i) -> void:
	var chunk := Chunk.new()
	chunk.coord = coord
	chunk.chunk_size = CHUNK_SIZE
	chunk.resolution = resolution_mesh
	chunk.amplitude = amplitude_relief
	chunk.bruit = bruit
	chunk.couleur_herbe = couleur_herbe
	chunk.couleur_roche = couleur_roche
	chunk.couleur_sable = couleur_sable
	chunk.world_size_chunks = WORLD_SIZE_CHUNKS

	chunk.position = _position_rendu_chunk(coord, centre)
	add_child(chunk)
	chunk.generer()

	chunks_charges[coord] = chunk
	chunk_charge.emit(coord)


func _decharger_chunk(coord: Vector2i) -> void:
	if not chunks_charges.has(coord):
		return
	var chunk: Node3D = chunks_charges[coord]
	chunk.queue_free()
	chunks_charges.erase(coord)
	chunk_decharge.emit(coord)


# ----------------------------------------------------------
#  UTILITAIRES PUBLICS
# ----------------------------------------------------------
## Hauteur du terrain à une position monde (avec wrap)
func hauteur_a(pos: Vector3) -> float:
	# On utilise les coordonnées "logiques" wrappées pour le bruit
	var wx := fposmod(pos.x, WORLD_SIZE_CHUNKS * CHUNK_SIZE)
	var wz := fposmod(pos.z, WORLD_SIZE_CHUNKS * CHUNK_SIZE)
	return bruit.get_noise_2d(wx, wz) * amplitude_relief


## Téléporte le joueur de l'autre côté si il sort trop loin
## (sécurité, normalement le wrap visuel suffit)
func _wrap_joueur_si_besoin() -> void:
	if joueur == null:
		return
	var taille_monde: float = WORLD_SIZE_CHUNKS * CHUNK_SIZE
	var pos := joueur.global_position
	var change := false

	if pos.x < 0:
		pos.x += taille_monde
		change = true
	elif pos.x >= taille_monde:
		pos.x -= taille_monde
		change = true

	if pos.z < 0:
		pos.z += taille_monde
		change = true
	elif pos.z >= taille_monde:
		pos.z -= taille_monde
		change = true

	if change:
		joueur.global_position = pos

```


============================================================
## FICHIER : `world_streamer.gd`
============================================================

```gdscript
extends Node
class_name WorldStreamer

# ==========================================================
#  OBSIDIAN HORIZON — Helper de wrap du joueur
#  À placer comme enfant du WorldManager ou en Autoload léger.
#  Garde le joueur dans les bornes logiques du monde tout en
#  conservant l'illusion d'un espace infini / sans barrière.
# ==========================================================

@export var world_manager_path: NodePath
var world_manager: WorldManager


func _ready() -> void:
	if world_manager_path:
		world_manager = get_node_or_null(world_manager_path)
	if world_manager == null:
		world_manager = get_tree().get_first_node_in_group("world_manager") as WorldManager


func _physics_process(_delta: float) -> void:
	if world_manager == null or world_manager.joueur == null:
		return

	var taille: float = world_manager.WORLD_SIZE_CHUNKS * world_manager.CHUNK_SIZE
	var joueur: Node3D = world_manager.joueur
	var pos := joueur.global_position
	var new_pos := pos
	var wrapped := false

	# Wrap X
	if pos.x < 0.0:
		new_pos.x += taille
		wrapped = true
	elif pos.x >= taille:
		new_pos.x -= taille
		wrapped = true

	# Wrap Z
	if pos.z < 0.0:
		new_pos.z += taille
		wrapped = true
	elif pos.z >= taille:
		new_pos.z -= taille
		wrapped = true

	if wrapped:
		# Téléportation instantanée (invisible grâce au streaming wrap)
		joueur.global_position = new_pos
		# Force une mise à jour immédiate des chunks
		world_manager.dernier_chunk_joueur = Vector2i(9999, 9999)

```


============================================================
## FICHIER : `hud.gd`
============================================================

```gdscript
extends CanvasLayer

# ==========================================================
#  OBSIDIAN HORIZON — HUD minimal (PV / PM / or / info)
#  Style discret, ne surcharge pas l'écran.
# ==========================================================

var barre_pv: ProgressBar
var barre_pm: ProgressBar
var label_or: Label
var label_info: Label
var joueur: Node = null


func _ready() -> void:
	layer = 10
	_construire()
	await get_tree().process_frame
	joueur = get_tree().get_first_node_in_group("joueur")


func _construire() -> void:
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	# --- Barres bas-gauche ---
	var conteneur := VBoxContainer.new()
	conteneur.position = Vector2(24, 24)
	conteneur.custom_minimum_size = Vector2(220, 0)
	root.add_child(conteneur)

	barre_pv = ProgressBar.new()
	barre_pv.custom_minimum_size = Vector2(220, 18)
	barre_pv.max_value = 100
	barre_pv.value = 100
	barre_pv.show_percentage = false
	barre_pv.modulate = Color(0.9, 0.25, 0.25)
	conteneur.add_child(barre_pv)

	var label_pv := Label.new()
	label_pv.name = "LabelPV"
	label_pv.text = "PV"
	label_pv.add_theme_font_size_override("font_size", 12)
	conteneur.add_child(label_pv)

	barre_pm = ProgressBar.new()
	barre_pm.custom_minimum_size = Vector2(220, 14)
	barre_pm.max_value = 50
	barre_pm.value = 50
	barre_pm.show_percentage = false
	barre_pm.modulate = Color(0.3, 0.5, 0.95)
	conteneur.add_child(barre_pm)

	# --- Or bas-droite ---
	label_or = Label.new()
	label_or.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	label_or.position = Vector2(-180, -48)
	label_or.text = "Or : 0"
	label_or.add_theme_font_size_override("font_size", 18)
	root.add_child(label_or)

	# --- Info centre-bas (interaction) ---
	label_info = Label.new()
	label_info.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	label_info.position = Vector2(-100, -80)
	label_info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label_info.text = ""
	label_info.add_theme_font_size_override("font_size", 14)
	root.add_child(label_info)


func _process(_delta: float) -> void:
	if joueur == null:
		joueur = get_tree().get_first_node_in_group("joueur")
		return

	if "PV_actuels" in joueur:
		barre_pv.max_value = joueur.PV_max
		barre_pv.value = joueur.PV_actuels
		var lp := barre_pv.get_parent().get_node_or_null("LabelPV")
		if lp:
			lp.text = "PV  %d / %d" % [int(joueur.PV_actuels), int(joueur.PV_max)]

	if "PM_actuels" in joueur:
		barre_pm.max_value = joueur.PM_max
		barre_pm.value = joueur.PM_actuels

	if Inventaire:
		label_or.text = "Or : %d" % Inventaire.or_actuel

```


============================================================
## FICHIER : `main.gd`
============================================================

```gdscript
extends Node3D

# ==========================================================
#  OBSIDIAN HORIZON — Scène principale de bootstrap
#  Attache ce script à un Node3D racine de ta scène Main.tscn
#  Il crée automatiquement : soleil, monde, joueur, HUD.
# ==========================================================

func _ready() -> void:
	_setup_eclairage()
	_setup_monde()
	_setup_joueur()
	_setup_hud()
	print("=== OBSIDIAN HORIZON prêt ===")
	print("ZQSD/WASD déplacer | Souris regarder | Clic gauche attaquer")
	print("E interagir (arbres/minerais) | Shift courir | Ctrl accroupi | Espace sauter")
	print("Échap libérer la souris")


func _setup_eclairage() -> void:
	var soleil := DirectionalLight3D.new()
	soleil.name = "Soleil"
	soleil.rotation_degrees = Vector3(-45, 30, 0)
	soleil.light_energy = 1.15
	soleil.shadow_enabled = true
	add_child(soleil)

	var env := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_COLOR
	environment.background_color = Color(0.55, 0.72, 0.9)
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.4, 0.45, 0.5)
	environment.ambient_light_energy = 0.35
	environment.tonemap_mode = Environment.TONE_MAPPER_ACES
	env.environment = environment
	add_child(env)


func _setup_monde() -> void:
	var wm := WorldManager.new()
	wm.name = "WorldManager"
	wm.add_to_group("world_manager")
	wm.CHUNK_SIZE = 64.0
	wm.WORLD_SIZE_CHUNKS = 24   # un peu plus petit pour démarrer léger
	wm.VIEW_RADIUS = 2
	wm.PRELOAD_RADIUS = 3
	wm.amplitude_relief = 10.0
	add_child(wm)

	var streamer := WorldStreamer.new()
	streamer.name = "WorldStreamer"
	streamer.world_manager = wm
	add_child(streamer)


func _setup_joueur() -> void:
	var joueur := Player.new()
	joueur.name = "Joueur"
	joueur.position = Vector3(32, 25, 32)  # au-dessus du terrain
	# Collision capsule
	var col := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.35
	shape.height = 1.6
	col.shape = shape
	col.position.y = 0.9
	joueur.add_child(col)
	add_child(joueur)

	# Équipement de départ minimal
	if Inventaire:
		Inventaire.ajouter_par_id("epee_rouillee", 1)
		Inventaire.ajouter_par_id("chemise_basique", 1)
		Inventaire.ajouter_par_id("pantalon_basique", 1)
		Inventaire.ajouter_par_id("bottes_basiques", 1)
		Inventaire.ajouter_or(50)


func _setup_hud() -> void:
	var hud := preload("res://hud.gd").new() if ResourceLoader.exists("res://hud.gd") else null
	if hud == null:
		# Fallback : charge depuis le même dossier de scripts
		hud = CanvasLayer.new()
		hud.set_script(load("res://scripts/hud.gd") if ResourceLoader.exists("res://scripts/hud.gd") else null)
	if hud:
		add_child(hud)
	else:
		# Création directe
		var h := Node.new()
		h.set_script(load("res://hud.gd"))
		if h.get_script():
			add_child(h)
		else:
			push_warning("HUD non trouvé — place hud.gd dans res://")

```
