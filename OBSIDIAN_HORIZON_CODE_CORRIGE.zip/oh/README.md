# OBSIDIAN HORIZON — Backup code

## Structure

```
autoloads/   Inventaire, Titres, Competences, Forge, Sauvegarde, Tour, Bestiaire
joueur/      Player + ControleurDeplacement
monde/       WorldManager, chunks, ennemis, ressources, main
ui/          Inventaire, titres, forge, HUD
docs/        README setup + archive markdown complète
```

## Autoloads (ordre recommandé)

1. Inventaire  → autoloads/inventaire.gd
2. Titres      → autoloads/titres.gd
3. Competences → autoloads/competences.gd
4. Forge       → autoloads/forge.gd
5. Sauvegarde  → autoloads/sauvegarde.gd
6. Tour        → autoloads/tour.gd
7. Bestiaire   → autoloads/bestiaire.gd  (méta, fichier dédié user://bestiaire.json)

## Tour

- 10 sections × 10 étages, DA par section
- TP safe : 5, 15, 25… 95
- Boss : 10, 20… 100
- Génération procédurale déterministe (seed)
- Hubs découverts + seed sérialisés dans Sauvegarde

## Notes

- Rendu 3D des étages : plus tard
- player.gd utilise composition avec controleur_deplacement.gd
- À la mort : -20% or, inventaire perdu, stuff fer basique (Sauvegarde.appliquer_penalites_mort)

## Architecture actuelle

- Le déplacement FPS est géré exclusivement par `joueur/controleur_deplacement.gd`, utilisé en composition par `joueur/player.gd`.
- `joueur/player_controller.gd` est supprimé : ancienne implémentation non utilisée.
- `autoloads/tour.gd` est l'unique source du système de Tour.
- `tour/tour.gd` était une copie identique et a été supprimée pour éviter les divergences.
- La génération 3D des étages reste volontairement à faire plus tard : pour l'instant, la priorité est la logique et les systèmes.
