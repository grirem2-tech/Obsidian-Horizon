extends CharacterBody3D
class_name Player

# ==========================================================
#  OBSIDIAN HORIZON — Joueur
#  Stats / Titres / Compétences / Mort / Résolution du combat.
#
#  Le déplacement FPS (caméra, input, physique, raycasts de visée) vit
#  dans un nœud enfant séparé : controleur_deplacement.gd (composition).
#  Ce script n'a plus AUCUNE logique de mouvement — il expose juste les
#  stats (vitesse_finale, portee_attaque...) que le contrôleur consulte,
#  et reçoit en retour "quelle cible a été visée" pour en résoudre l'effet.
# ==========================================================

# ----------------------------------------------------------
#  STATISTIQUES DE BASE
# ----------------------------------------------------------
@export_group("Statistiques de base")
@export var PV_max: float = 100.0
var PV_actuels: float = 100.0

@export var PM_max: float = 50.0
var PM_actuels: float = 50.0

@export var vitesse_deplacement: float = 5.0
@export var degats_base: float = 10.0
@export var taux_drop: float = 1.0

# ----------------------------------------------------------
#  BUILD
# ----------------------------------------------------------
@export_group("Système de Build")
var titres_debloques: Array[Dictionary] = []
const MAX_SLOTS_ACTIFS: int = 5
var competences_actives: Array = []
const MAX_SLOTS_PASSIFS: int = 5
var competences_passives: Array = []
var reputation_pnj: Dictionary = {
	"prix_multiplicateur": 1.0,
	"taxe_garde": 0.0
}

# ----------------------------------------------------------
#  MODE GNOME
# ----------------------------------------------------------
@export_group("Mode Gnome Caché")
var est_gnome: bool = false
var degats_finaux: float = 0.0
var vitesse_finale: float = 0.0
var taux_drop_final: float = 0.0
var multiplicateur_prix_final: float = 1.0
var bonus_generique: Dictionary = {}
var bonus_degats_contre: Dictionary = {}
var bonus_reduction_degats_recus_de: Dictionary = {}

# ----------------------------------------------------------
#  MORT / TOUR
# ----------------------------------------------------------
@export_group("Mort et Respawn")
var etage_actuel: int = 0
var possede_une_base: bool = false
var en_route_divine: bool = false

# ----------------------------------------------------------
#  COMBAT (stats consultées par ControleurDeplacement pour viser/temporiser,
#  mais dont la résolution reste ici — voir attaquer_cible())
# ----------------------------------------------------------
@export_group("Combat")
@export var portee_attaque: float = 2.8
@export var cooldown_attaque: float = 0.45
@export var degats_sans_arme_mult: float = 0.6

var invulnerable_timer: float = 0.0

## Référence vers le nœud enfant qui gère le déplacement/la caméra/les
## raycasts. Créé automatiquement s'il n'existe pas déjà (voir _ready()).
var controleur: Node


func _ready() -> void:
	add_to_group("joueur")
	PV_actuels = PV_max
	PM_actuels = PM_max
	_assurer_controleur_deplacement()
	calculer_stats_finales()


## Instancie ControleurDeplacement comme enfant s'il n'est pas déjà présent
## dans la scène (utile quand Player est créé via code, ex: main.gd).
func _assurer_controleur_deplacement() -> void:
	if has_node("ControleurDeplacement"):
		controleur = get_node("ControleurDeplacement")
		return

	var script_controleur = load("res://joueur/controleur_deplacement.gd")
	if script_controleur == null:
		script_controleur = load("res://controleur_deplacement.gd")  # fallback si l'arborescence a été aplatie

	controleur = Node.new()
	controleur.name = "ControleurDeplacement"
	if script_controleur:
		controleur.set_script(script_controleur)
	add_child(controleur)


## Seule logique de "process" restante côté Player : la décroissance de
## l'invulnérabilité après un coup reçu (i-frames). Rien à voir avec le
## déplacement, donc ça reste ici plutôt que dans le contrôleur.
func _process(delta: float) -> void:
	if invulnerable_timer > 0.0:
		invulnerable_timer -= delta


# ==========================================================
#  COMBAT — RÉSOLUTION (la visée/le timing viennent de ControleurDeplacement)
# ==========================================================
## Appelée par ControleurDeplacement quand une cible valide a été visée et
## que le cooldown est écoulé. Toute la logique de calcul de dégâts
## (arme/pas d'arme, bonus ciblés, conditionnel PV haut...) reste ici,
## avec le reste des stats.
func attaquer_cible(cible: Node) -> void:
	var degats := degats_finaux if degats_finaux != 0.0 else degats_base

	# Sans arme équipée → malus (titre Poing d'acier peut compenser)
	var a_une_arme := false
	if Inventaire and Inventaire.equipement.get("arme_principale") != null:
		a_une_arme = true
	if not a_une_arme:
		degats *= degats_sans_arme_mult
		degats *= (1.0 + obtenir_bonus("degats_pourcent_sans_arme") / 100.0)

	if cible == null or not cible.has_method("recevoir_degats"):
		return

	# Bonus contre catégorie / id
	var bonus_cible := 0.0
	if "id_mob" in cible:
		bonus_cible += obtenir_bonus_degats_contre(cible.id_mob)
	if "categories" in cible:
		for cat in cible.categories:
			bonus_cible += obtenir_bonus_degats_contre(cat)
	degats *= (1.0 + bonus_cible / 100.0)

	# Conditionnel PV haut (titre Boucher)
	if "PV_actuels" in cible and "PV_max" in cible:
		if cible.PV_actuels / maxf(cible.PV_max, 1.0) > 0.5:
			degats *= (1.0 + obtenir_bonus("degats_pourcent_contre_pv_haut") / 100.0)

	cible.recevoir_degats(degats, self)


func recevoir_degats(montant: float, source: Node = null) -> void:
	if invulnerable_timer > 0.0 or PV_actuels <= 0.0:
		return

	var reduction := 0.0
	if source:
		if "id_mob" in source:
			reduction += obtenir_reduction_degats_recus_de(source.id_mob)
		if "categories" in source:
			for cat in source.categories:
				reduction += obtenir_reduction_degats_recus_de(cat)

	reduction += obtenir_bonus("defense_pourcent")
	# Conditionnel PV bas
	if PV_actuels / maxf(PV_max, 1.0) < 0.25:
		reduction += obtenir_bonus("defense_pourcent_pv_bas")

	var facteur := maxf(0.05, 1.0 - reduction / 100.0)
	var degats_finaux_recus := montant * facteur
	PV_actuels -= degats_finaux_recus
	invulnerable_timer = 0.35  # i-frames courts

	if PV_actuels <= 0.0:
		PV_actuels = 0.0
		mourir()


func soigner(montant: float) -> void:
	var bonus := 1.0 + obtenir_bonus("soins_recus_pourcent") / 100.0
	PV_actuels = minf(PV_max, PV_actuels + montant * bonus)


# ==========================================================
#  MODE GNOME
# ==========================================================
func activer_mode_gnome() -> void:
	if est_gnome:
		push_warning("Le mode Gnome est déjà actif.")
		return
	est_gnome = true
	# Le malus Gnome est appliqué comme un multiplicateur positif très faible.
	# On évite les statistiques négatives qui inverseraient les dégâts/la vitesse.
	# La valeur de design « -1000 % » est donc représentée ici par x0,10.
	degats_base *= 0.10
	vitesse_deplacement *= 0.10
	taux_drop = 0.01
	reputation_pnj["prix_multiplicateur"] *= 1.5
	calculer_stats_finales()


# ==========================================================
#  STATS
# ==========================================================
func calculer_stats_finales() -> void:
	var nouveau_bonus_generique: Dictionary = {}
	var nouveau_bonus_contre: Dictionary = {}
	var nouveau_bonus_reduction_de: Dictionary = {}

	for titre in titres_debloques:
		for effet in titre.get("effets", []):
			var type_effet: String = effet.get("type", "")
			var valeur: float = _appliquer_boost_gnome(effet.get("valeur", 0.0))
			match type_effet:
				"degats_pourcent_contre_cible":
					var c: String = effet.get("cible", "")
					nouveau_bonus_contre[c] = nouveau_bonus_contre.get(c, 0.0) + valeur
				"reduction_degats_recus_pourcent_contre_cible":
					var c2: String = effet.get("cible", "")
					nouveau_bonus_reduction_de[c2] = nouveau_bonus_reduction_de.get(c2, 0.0) + valeur
				"", "aucun_bonus", "comportemental":
					pass
				_:
					nouveau_bonus_generique[type_effet] = nouveau_bonus_generique.get(type_effet, 0.0) + valeur

	bonus_generique = nouveau_bonus_generique
	bonus_degats_contre = nouveau_bonus_contre
	bonus_reduction_degats_recus_de = nouveau_bonus_reduction_de

	if Competences:
		Competences.appliquer_passifs_au_joueur(self)

	degats_finaux = degats_base * (1.0 + obtenir_bonus("degats_pourcent") / 100.0)
	vitesse_finale = vitesse_deplacement * (1.0 + obtenir_bonus("vitesse_pourcent") / 100.0)
	taux_drop_final = taux_drop * (1.0 + obtenir_bonus("taux_drop_pourcent") / 100.0)
	multiplicateur_prix_final = reputation_pnj["prix_multiplicateur"] * (1.0 + obtenir_bonus("prix_pnj_pourcent") / 100.0)


func obtenir_bonus(type_effet: String) -> float:
	return bonus_generique.get(type_effet, 0.0)


func obtenir_bonus_degats_contre(id_cible: String) -> float:
	return bonus_degats_contre.get(id_cible, 0.0)


func obtenir_reduction_degats_recus_de(id_cible: String) -> float:
	return bonus_reduction_degats_recus_de.get(id_cible, 0.0)


func _appliquer_boost_gnome(valeur_effet: float) -> float:
	if est_gnome and valeur_effet > 0.0:
		return valeur_effet * 1.5
	return valeur_effet


# ==========================================================
#  COMPÉTENCES / TITRES
# ==========================================================
func ajouter_competence_active(competence) -> bool:
	if competences_actives.size() >= MAX_SLOTS_ACTIFS:
		return false
	competences_actives.append(competence)
	return true


func ajouter_competence_passive(competence) -> bool:
	if competences_passives.size() >= MAX_SLOTS_PASSIFS:
		return false
	competences_passives.append(competence)
	calculer_stats_finales()
	return true


func debloquer_titre(titre: Dictionary) -> void:
	titres_debloques.append(titre)
	calculer_stats_finales()


# ==========================================================
#  MORT
# ==========================================================
func mourir() -> void:
	if en_route_divine:
		_game_over_definitif()
		return

	etage_actuel = 0
	# Pénalités : -20 % or, inventaire perdu, stuff fer basique sans stats.
	# Titres / compétences intacts (progression permanente).
	if Sauvegarde:
		Sauvegarde.appliquer_penalites_mort()
	elif Inventaire:
		Inventaire.vider_sauf_equipement_base()
	calculer_stats_finales()
	PV_actuels = PV_max
	PM_actuels = PM_max
	teleporter_apres_mort()
	# Pas de save forcée : le quit écrira cet état appauvri.


func teleporter_apres_mort() -> void:
	if possede_une_base:
		print("Respawn : Lit du joueur (Base)")
	else:
		print("Respawn : Lit de la Guilde")
		# Point de respawn par défaut au centre du monde
		global_position = Vector3(16, 20, 16)


func _game_over_definitif() -> void:
	print("GAME OVER — Route Divine : la mort est définitive.")
	set_process(false)
	if controleur:
		controleur.set_physics_process(false)
		controleur.set_process(false)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
