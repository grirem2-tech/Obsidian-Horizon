extends Node
class_name ControleurDeplacement

# ==========================================================
#  OBSIDIAN HORIZON — Contrôleur de déplacement FPS
#  Responsabilité UNIQUE : caméra, input, physique de déplacement,
#  et les deux raycasts (interaction / attaque). Ne connaît RIEN des
#  stats/titres/compétences — il lit juste "corps.vitesse_finale" et
#  délègue la résolution du combat/interaction au parent (Player).
#
#  À utiliser en composition : ce script est un enfant du CharacterBody3D
#  du joueur (nommé "ControleurDeplacement"). Player._ready() le crée
#  automatiquement s'il n'existe pas déjà dans la scène — inutile de le
#  configurer à la main si tu instancies Player via code (voir main.gd).
# ==========================================================

@export_group("Déplacement")
@export var vitesse_course_mult: float = 1.45
@export var vitesse_accroupi_mult: float = 0.45
@export var force_saut: float = 6.5
@export var gravite: float = 18.0
@export var acceleration: float = 14.0
@export var friction: float = 12.0

@export_group("Caméra")
@export var sensibilite_souris: float = 0.12

@export_group("Interaction")
@export var distance_interaction: float = 3.5

## Référence au CharacterBody3D parent (le Player). C'est lui qui porte
## les stats (vitesse_finale, portee_attaque, cooldown_attaque...) et qui
## résout les effets du combat/interaction — ce script ne fait que viser
## et déplacer.
var corps: CharacterBody3D

var head: Node3D
var camera: Camera3D
var ray_interact: RayCast3D
var ray_attaque: RayCast3D

var rotation_x: float = 0.0
var rotation_y: float = 0.0
var est_accroupi: bool = false
var direction_visee: Vector3 = Vector3.FORWARD
var _timer_attaque: float = 0.0


func _ready() -> void:
	corps = get_parent() as CharacterBody3D
	if corps == null:
		push_error("ControleurDeplacement doit être un enfant direct d'un CharacterBody3D (Player).")
		return

	_assurer_structure_camera()
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


## Construit head/caméra/raycasts comme enfants du CORPS (et non de ce
## nœud, qui n'a pas de transform 3D) pour qu'ils suivent la position et
## la collision du joueur.
func _assurer_structure_camera() -> void:
	if not corps.has_node("Head"):
		head = Node3D.new()
		head.name = "Head"
		head.position = Vector3(0, 1.65, 0)
		corps.add_child(head)
	else:
		head = corps.get_node("Head")

	if not head.has_node("Camera3D"):
		camera = Camera3D.new()
		camera.name = "Camera3D"
		camera.current = true
		camera.fov = 75.0
		head.add_child(camera)
	else:
		camera = head.get_node("Camera3D")

	if not camera.has_node("RayInteract"):
		ray_interact = RayCast3D.new()
		ray_interact.name = "RayInteract"
		ray_interact.target_position = Vector3(0, 0, -distance_interaction)
		ray_interact.enabled = true
		ray_interact.collide_with_areas = true
		camera.add_child(ray_interact)
	else:
		ray_interact = camera.get_node("RayInteract")

	if not camera.has_node("RayAttaque"):
		ray_attaque = RayCast3D.new()
		ray_attaque.name = "RayAttaque"
		ray_attaque.target_position = Vector3(0, 0, -corps.portee_attaque)
		ray_attaque.enabled = true
		camera.add_child(ray_attaque)
	else:
		ray_attaque = camera.get_node("RayAttaque")


# ==========================================================
#  INPUT & PHYSIQUE
# ==========================================================
func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		rotation_y -= event.relative.x * sensibilite_souris
		rotation_x -= event.relative.y * sensibilite_souris
		rotation_x = clampf(rotation_x, -89.0, 89.0)
		head.rotation_degrees.x = rotation_x
		corps.rotation_degrees.y = rotation_y

	if event.is_action_pressed("ui_cancel"):
		Input.mouse_mode = (
			Input.MOUSE_MODE_VISIBLE
			if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED
			else Input.MOUSE_MODE_CAPTURED
		)


func _physics_process(delta: float) -> void:
	if _timer_attaque > 0.0:
		_timer_attaque -= delta

	_appliquer_gravite(delta)
	_gerer_saut()
	_gerer_accroupi()
	_deplacer(delta)
	corps.move_and_slide()

	if camera:
		direction_visee = -camera.global_transform.basis.z

	# Attaque clic gauche
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) and _timer_attaque <= 0.0:
		_tenter_attaque()

	# Interaction E
	if Input.is_physical_key_pressed(KEY_E):
		_tenter_interaction()


func _deplacer(delta: float) -> void:
	var input_dir := Vector2.ZERO
	if Input.is_physical_key_pressed(KEY_Z) or Input.is_physical_key_pressed(KEY_W):
		input_dir.y -= 1
	if Input.is_physical_key_pressed(KEY_S):
		input_dir.y += 1
	if Input.is_physical_key_pressed(KEY_Q) or Input.is_physical_key_pressed(KEY_A):
		input_dir.x -= 1
	if Input.is_physical_key_pressed(KEY_D):
		input_dir.x += 1
	input_dir = input_dir.limit_length(1.0)

	var direction := (corps.transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()

	# La vitesse de base vient entièrement du Player (titres/compétences/mode
	# Gnome déjà appliqués dans vitesse_finale) : ce script ne fait
	# qu'appliquer les multiplicateurs propres au déplacement (course/accroupi).
	var vitesse_cible: float = corps.vitesse_finale if corps.vitesse_finale > 0.0 else corps.vitesse_deplacement
	if Input.is_physical_key_pressed(KEY_SHIFT) and not est_accroupi:
		vitesse_cible *= vitesse_course_mult
	elif est_accroupi:
		vitesse_cible *= vitesse_accroupi_mult

	# Bonus conditionnels (ex: vitesse hors combat, PV bas…)
	vitesse_cible *= (1.0 + corps.obtenir_bonus("vitesse_hors_combat_pourcent") / 100.0)

	if direction != Vector3.ZERO:
		corps.velocity.x = lerpf(corps.velocity.x, direction.x * vitesse_cible, acceleration * delta)
		corps.velocity.z = lerpf(corps.velocity.z, direction.z * vitesse_cible, acceleration * delta)
	else:
		corps.velocity.x = lerpf(corps.velocity.x, 0.0, friction * delta)
		corps.velocity.z = lerpf(corps.velocity.z, 0.0, friction * delta)


func _appliquer_gravite(delta: float) -> void:
	if not corps.is_on_floor():
		corps.velocity.y -= gravite * delta
	elif corps.velocity.y < 0.0:
		corps.velocity.y = 0.0


func _gerer_saut() -> void:
	if (Input.is_physical_key_pressed(KEY_SPACE) or Input.is_action_just_pressed("ui_accept")) and corps.is_on_floor() and not est_accroupi:
		corps.velocity.y = force_saut


func _gerer_accroupi() -> void:
	var veut := Input.is_physical_key_pressed(KEY_CTRL)
	if veut != est_accroupi:
		est_accroupi = veut
		if head:
			head.position.y = 1.05 if est_accroupi else 1.65


# ==========================================================
#  VISÉE : ATTAQUE / INTERACTION
#  Ce script détecte QUI est visé ; c'est toujours Player qui décide de
#  l'EFFET (dégâts, ajout d'objet...) — séparation stricte visée/résolution.
# ==========================================================
func _tenter_attaque() -> void:
	_timer_attaque = corps.cooldown_attaque

	if ray_attaque and ray_attaque.is_colliding():
		var cible = ray_attaque.get_collider()
		if cible and cible.has_method("recevoir_degats"):
			corps.attaquer_cible(cible)


func _tenter_interaction() -> void:
	if not ray_interact or not ray_interact.is_colliding():
		return
	var cible = ray_interact.get_collider()
	if cible == null:
		return
	if cible.has_method("interagir"):
		cible.interagir(corps)
	elif cible.get_parent() and cible.get_parent().has_method("interagir"):
		cible.get_parent().interagir(corps)
