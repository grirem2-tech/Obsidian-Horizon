extends Node3D
class_name WorldManager

# ==========================================================
#  OBSIDIAN HORIZON — Gestionnaire de monde sans barrières
#  Style low-poly (Tunic-like) + streaming de chunks
#  + wrap-around (nord↔sud, est↔ouest).
#
#  Principe :
#  - Le monde a une taille fixe en chunks (WORLD_SIZE_CHUNKS).
#  - Les coordonnées sont modulaires → le monde se referme sur lui-même.
#  - On ne charge que les chunks proches du joueur (VIEW_RADIUS).
#  - Quand le joueur s'approche d'un bord, les chunks de l'autre
#    côté sont pré-chargés comme s'ils étaient contigus.
# ==========================================================

signal chunk_charge(coord: Vector2i)
signal chunk_decharge(coord: Vector2i)

# ----------------------------------------------------------
#  CONFIGURATION
# ----------------------------------------------------------
@export_group("Monde")
## Taille d'un chunk en unités monde (mètres)
@export var CHUNK_SIZE: float = 64.0
## Nombre de chunks sur un côté du monde (ex: 32 → 32×32 chunks)
@export var WORLD_SIZE_CHUNKS: int = 32
## Rayon de chargement autour du joueur (en chunks)
@export var VIEW_RADIUS: int = 3
## Rayon de pré-chargement (légèrement plus large)
@export var PRELOAD_RADIUS: int = 4

@export_group("Terrain low-poly")
@export var amplitude_relief: float = 12.0
@export var echelle_bruit: float = 0.03
@export var resolution_mesh: int = 16          # subdivisions par chunk (low-poly)
@export var couleur_herbe: Color = Color(0.35, 0.55, 0.25)
@export var couleur_roche: Color = Color(0.45, 0.42, 0.38)
@export var couleur_sable: Color = Color(0.75, 0.68, 0.45)

# ----------------------------------------------------------
#  ÉTAT
# ----------------------------------------------------------
var chunks_charges: Dictionary = {}           # Vector2i → Chunk
var joueur: Node3D = null
var dernier_chunk_joueur: Vector2i = Vector2i(9999, 9999)

var bruit: FastNoiseLite


func _ready() -> void:
	bruit = FastNoiseLite.new()
	bruit.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	bruit.seed = 42                           # change pour un autre monde
	bruit.frequency = echelle_bruit
	bruit.fractal_octaves = 4

	# Cherche le joueur
	await get_tree().process_frame
	_trouver_joueur()


func _trouver_joueur() -> void:
	joueur = get_tree().get_first_node_in_group("joueur")
	if joueur == null:
		# Fallback : cherche un CharacterBody3D
		for n in get_tree().get_nodes_in_group("joueur"):
			joueur = n
			break
	if joueur == null:
		push_warning("WorldManager : aucun joueur trouvé (groupe 'joueur').")


func _process(_delta: float) -> void:
	if joueur == null:
		_trouver_joueur()
		return

	var chunk_actuel := _position_vers_chunk(joueur.global_position)
	if chunk_actuel != dernier_chunk_joueur:
		dernier_chunk_joueur = chunk_actuel
		_mettre_a_jour_chunks(chunk_actuel)


# ----------------------------------------------------------
#  COORDONNÉES & WRAP
# ----------------------------------------------------------
## Convertit une position monde en coordonnée de chunk (avec wrap)
func _position_vers_chunk(pos: Vector3) -> Vector2i:
	var cx := int(floor(pos.x / CHUNK_SIZE))
	var cz := int(floor(pos.z / CHUNK_SIZE))
	return _wrap_chunk(Vector2i(cx, cz))


## Applique le modulo pour le wrap-around
func _wrap_chunk(coord: Vector2i) -> Vector2i:
	var x := posmod(coord.x, WORLD_SIZE_CHUNKS)
	var z := posmod(coord.y, WORLD_SIZE_CHUNKS)
	return Vector2i(x, z)


## Distance toroïdale entre deux chunks (prend le chemin le plus court)
func _distance_toroidale(a: Vector2i, b: Vector2i) -> float:
	var dx := abs(a.x - b.x)
	var dz := abs(a.y - b.y)
	dx = mini(dx, WORLD_SIZE_CHUNKS - dx)
	dz = mini(dz, WORLD_SIZE_CHUNKS - dz)
	return sqrt(float(dx * dx + dz * dz))


## Position monde "dépliée" d'un chunk par rapport au joueur
## (pour que le rendu soit contigu même au bord)
func _position_rendu_chunk(coord: Vector2i, centre: Vector2i) -> Vector3:
	# On choisit le représentant le plus proche du centre (joueur)
	var dx := coord.x - centre.x
	var dz := coord.y - centre.y

	if dx > WORLD_SIZE_CHUNKS / 2:
		dx -= WORLD_SIZE_CHUNKS
	elif dx < -WORLD_SIZE_CHUNKS / 2:
		dx += WORLD_SIZE_CHUNKS

	if dz > WORLD_SIZE_CHUNKS / 2:
		dz -= WORLD_SIZE_CHUNKS
	elif dz < -WORLD_SIZE_CHUNKS / 2:
		dz += WORLD_SIZE_CHUNKS

	return Vector3(
		(centre.x + dx) * CHUNK_SIZE,
		0.0,
		(centre.y + dz) * CHUNK_SIZE
	)


# ----------------------------------------------------------
#  STREAMING
# ----------------------------------------------------------
func _mettre_a_jour_chunks(centre: Vector2i) -> void:
	var a_garder: Dictionary = {}

	# 0. Force-load (base, tour…) — toujours gardés / chargés
	for coord in chunks_force_load:
		var c := _wrap_chunk(coord)
		a_garder[c] = true
		if not chunks_charges.has(c):
			_charger_chunk(c, centre)
		else:
			chunks_charges[c].position = _position_rendu_chunk(c, centre)

	# 1. Cercle autour du joueur (vue + précharge)
	for dx in range(-PRELOAD_RADIUS, PRELOAD_RADIUS + 1):
		for dz in range(-PRELOAD_RADIUS, PRELOAD_RADIUS + 1):
			var dist := sqrt(float(dx * dx + dz * dz))
			if dist > PRELOAD_RADIUS + 0.5:
				continue

			var coord := _wrap_chunk(Vector2i(centre.x + dx, centre.y + dz))
			a_garder[coord] = true

			if not chunks_charges.has(coord):
				_charger_chunk(coord, centre)
			else:
				chunks_charges[coord].position = _position_rendu_chunk(coord, centre)

	# 2. Décharger hors vue SAUF force-load
	var a_supprimer: Array[Vector2i] = []
	for coord in chunks_charges.keys():
		if not a_garder.has(coord):
			a_supprimer.append(coord)

	for coord in a_supprimer:
		_decharger_chunk(coord)


func _charger_chunk(coord: Vector2i, centre: Vector2i) -> void:
	var chunk := Chunk.new()
	chunk.coord = coord
	chunk.chunk_size = CHUNK_SIZE
	chunk.resolution = resolution_mesh
	chunk.amplitude = amplitude_relief
	chunk.bruit = bruit
	chunk.couleur_herbe = couleur_herbe
	chunk.couleur_roche = couleur_roche
	chunk.couleur_sable = couleur_sable
	chunk.world_size_chunks = WORLD_SIZE_CHUNKS

	chunk.position = _position_rendu_chunk(coord, centre)
	add_child(chunk)
	chunk.generer()

	chunks_charges[coord] = chunk
	chunk_charge.emit(coord)


func _decharger_chunk(coord: Vector2i) -> void:
	if not chunks_charges.has(coord):
		return
	var chunk: Node3D = chunks_charges[coord]
	chunk.queue_free()
	chunks_charges.erase(coord)
	chunk_decharge.emit(coord)


# ----------------------------------------------------------
#  UTILITAIRES PUBLICS
# ----------------------------------------------------------
## Hauteur du terrain à une position monde (avec wrap)
func hauteur_a(pos: Vector3) -> float:
	# On utilise les coordonnées "logiques" wrappées pour le bruit
	var wx := fposmod(pos.x, WORLD_SIZE_CHUNKS * CHUNK_SIZE)
	var wz := fposmod(pos.z, WORLD_SIZE_CHUNKS * CHUNK_SIZE)
	return bruit.get_noise_2d(wx, wz) * amplitude_relief


## Téléporte le joueur de l'autre côté si il sort trop loin
## (sécurité, normalement le wrap visuel suffit)
func _wrap_joueur_si_besoin() -> void:
	if joueur == null:
		return
	var taille_monde: float = WORLD_SIZE_CHUNKS * CHUNK_SIZE
	var pos := joueur.global_position
	var change := false

	if pos.x < 0:
		pos.x += taille_monde
		change = true
	elif pos.x >= taille_monde:
		pos.x -= taille_monde
		change = true

	if pos.z < 0:
		pos.z += taille_monde
		change = true
	elif pos.z >= taille_monde:
		pos.z -= taille_monde
		change = true

	if change:
		joueur.global_position = pos


# ----------------------------------------------------------
#  FORCE-LOAD (base, tour) — jamais déchargés tant que listés
# ----------------------------------------------------------
var chunks_force_load: Array[Vector2i] = []


func definir_chunks_force_load(liste: Array) -> void:
	chunks_force_load.clear()
	for c in liste:
		if c is Vector2i:
			chunks_force_load.append(c)
		elif c is Array and c.size() >= 2:
			chunks_force_load.append(Vector2i(int(c[0]), int(c[1])))


func ajouter_chunk_force_load(coord: Vector2i) -> void:
	var w := _wrap_chunk(coord)
	if w not in chunks_force_load:
		chunks_force_load.append(w)


func recharger_autour_joueur() -> void:
	if joueur == null:
		return
	dernier_chunk_joueur = Vector2i(9999, 9999)
	var centre := _position_vers_chunk(joueur.global_position)
	_mettre_a_jour_chunks(centre)
