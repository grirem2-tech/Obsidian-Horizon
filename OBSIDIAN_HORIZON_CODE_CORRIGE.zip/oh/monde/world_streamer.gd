extends Node
class_name WorldStreamer

# ==========================================================
#  OBSIDIAN HORIZON — Helper de wrap du joueur
#  À placer comme enfant du WorldManager ou en Autoload léger.
#  Garde le joueur dans les bornes logiques du monde tout en
#  conservant l'illusion d'un espace infini / sans barrière.
# ==========================================================

@export var world_manager_path: NodePath
var world_manager: WorldManager


func _ready() -> void:
	if world_manager_path:
		world_manager = get_node_or_null(world_manager_path)
	if world_manager == null:
		world_manager = get_tree().get_first_node_in_group("world_manager") as WorldManager


func _physics_process(_delta: float) -> void:
	if world_manager == null or world_manager.joueur == null:
		return

	var taille: float = world_manager.WORLD_SIZE_CHUNKS * world_manager.CHUNK_SIZE
	var joueur: Node3D = world_manager.joueur
	var pos := joueur.global_position
	var new_pos := pos
	var wrapped := false

	# Wrap X
	if pos.x < 0.0:
		new_pos.x += taille
		wrapped = true
	elif pos.x >= taille:
		new_pos.x -= taille
		wrapped = true

	# Wrap Z
	if pos.z < 0.0:
		new_pos.z += taille
		wrapped = true
	elif pos.z >= taille:
		new_pos.z -= taille
		wrapped = true

	if wrapped:
		# Téléportation instantanée (invisible grâce au streaming wrap)
		joueur.global_position = new_pos
		# Force une mise à jour immédiate des chunks
		world_manager.dernier_chunk_joueur = Vector2i(9999, 9999)
