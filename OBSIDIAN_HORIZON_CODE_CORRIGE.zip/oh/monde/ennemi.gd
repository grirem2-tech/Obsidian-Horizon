extends CharacterBody3D
class_name Ennemi

# ==========================================================
#  OBSIDIAN HORIZON — Ennemi basique (loup, monstre…)
#  Low-poly, IA simple, drops + progression titres.
# ==========================================================

@export var id_mob: String = "loup"
@export var categories: Array[String] = ["etre_vivant", "sauvage", "monstre"]
@export var nom: String = "Loup"

@export var PV_max: float = 40.0
var PV_actuels: float = 40.0

@export var degats: float = 8.0
@export var vitesse: float = 3.5
@export var distance_detection: float = 18.0
@export var distance_attaque: float = 2.2
@export var cooldown_attaque: float = 1.1
@export var experience_drop: int = 0  # non utilisé (pas de niveaux)

@export var drops: Array[Dictionary] = [
	{"id": "peau_loup", "chance": 0.55, "quantite": 1},
	{"id": "viande_cru", "chance": 0.4, "quantite": 1},
	{"id": "os_renforces", "chance": 0.25, "quantite": 1},
	{"id": "fiole_sang_monstre", "chance": 0.15, "quantite": 1},
	{"id": "croc_alpha", "chance": 0.05, "quantite": 1},
]

var joueur: Node3D = null
var _timer_attaque: float = 0.0
var _est_mort: bool = false
var mesh_instance: MeshInstance3D


func _ready() -> void:
	PV_actuels = PV_max
	add_to_group("ennemis")
	_creer_apparence_lowpoly()
	# Collision simple
	if not has_node("CollisionShape3D"):
		var col := CollisionShape3D.new()
		var shape := CapsuleShape3D.new()
		shape.radius = 0.4
		shape.height = 1.0
		col.shape = shape
		col.position.y = 0.6
		add_child(col)


func _creer_apparence_lowpoly() -> void:
	mesh_instance = MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = Vector3(0.7, 0.9, 1.1)
	mesh_instance.mesh = box
	mesh_instance.position.y = 0.5

	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.45, 0.38, 0.32)
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_PER_VERTEX
	mesh_instance.material_override = mat
	add_child(mesh_instance)

	# "Tête"
	var tete := MeshInstance3D.new()
	var sphere := SphereMesh.new()
	sphere.radius = 0.28
	sphere.height = 0.5
	tete.mesh = sphere
	tete.position = Vector3(0, 1.0, 0.35)
	var mat2 := mat.duplicate()
	mat2.albedo_color = Color(0.4, 0.33, 0.28)
	tete.material_override = mat2
	add_child(tete)


func _physics_process(delta: float) -> void:
	if _est_mort:
		return

	if _timer_attaque > 0.0:
		_timer_attaque -= delta

	if joueur == null:
		joueur = get_tree().get_first_node_in_group("joueur")
		return

	var dist := global_position.distance_to(joueur.global_position)

	if dist > distance_detection:
		velocity = velocity.move_toward(Vector3.ZERO, 8.0 * delta)
		move_and_slide()
		return

	# Poursuite
	var dir := (joueur.global_position - global_position)
	dir.y = 0
	dir = dir.normalized()

	if dist > distance_attaque:
		velocity.x = dir.x * vitesse
		velocity.z = dir.z * vitesse
		# Orientation
		if dir.length() > 0.01:
			look_at(global_position + dir, Vector3.UP)
	else:
		velocity.x = 0
		velocity.z = 0
		if _timer_attaque <= 0.0:
			_attaquer()

	# Gravité simple
	if not is_on_floor():
		velocity.y -= 18.0 * delta
	else:
		velocity.y = 0

	move_and_slide()


func _attaquer() -> void:
	_timer_attaque = cooldown_attaque
	if joueur and joueur.has_method("recevoir_degats"):
		joueur.recevoir_degats(degats, self)


func recevoir_degats(montant: float, source: Node = null) -> void:
	if _est_mort:
		return
	PV_actuels -= montant
	# Flash blanc rapide
	if mesh_instance and mesh_instance.material_override:
		var mat: StandardMaterial3D = mesh_instance.material_override
		mat.albedo_color = Color.WHITE
		get_tree().create_timer(0.08).timeout.connect(func():
			if is_instance_valid(mat):
				mat.albedo_color = Color(0.45, 0.38, 0.32)
		)

	if PV_actuels <= 0.0:
		_mourir(source)


func _mourir(source: Node = null) -> void:
	_est_mort = true
	PV_actuels = 0.0

	# Progression titres + bestiaire (méta, hors slots de save)
	if source and source.is_in_group("joueur"):
		var contexte := {}
		if Titres:
			Titres.incrementer_progression("tuer", id_mob, categories, contexte)
		if Bestiaire:
			Bestiaire.enregistrer_kill(id_mob)

	# Drops
	_donner_drops(source)

	# Disparition
	var tween := create_tween()
	tween.tween_property(self, "scale", Vector3.ZERO, 0.35)
	tween.tween_callback(queue_free)


func _donner_drops(source: Node) -> void:
	if source == null or not source.is_in_group("joueur"):
		return
	var mult_drop: float = 1.0
	if "taux_drop_final" in source:
		mult_drop = source.taux_drop_final

	for drop in drops:
		var chance: float = drop.get("chance", 0.0) * mult_drop
		if randf() <= chance:
			if Inventaire:
				Inventaire.ajouter_par_id(drop.get("id", ""), drop.get("quantite", 1))
