extends Node3D
class_name Chunk

# ==========================================================
#  OBSIDIAN HORIZON — Un chunk de terrain low-poly
#  Généré procéduralement, style Tunic (facettes visibles).
# ==========================================================

var coord: Vector2i = Vector2i.ZERO
var chunk_size: float = 64.0
var resolution: int = 16
var amplitude: float = 12.0
var bruit: FastNoiseLite
var world_size_chunks: int = 32

var couleur_herbe: Color = Color(0.35, 0.55, 0.25)
var couleur_roche: Color = Color(0.45, 0.42, 0.38)
var couleur_sable: Color = Color(0.75, 0.68, 0.45)

var mesh_instance: MeshInstance3D
var collision: StaticBody3D
var col_shape: CollisionShape3D


func generer() -> void:
	_creer_mesh()
	_creer_collision()
	_peupler()


func _creer_mesh() -> void:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)

	var step: float = chunk_size / float(resolution)
	# Origine logique du chunk (pour le bruit, on utilise les coords wrappées)
	var origin_x: float = coord.x * chunk_size
	var origin_z: float = coord.y * chunk_size

	# Grille de hauteurs
	var hauteurs: Array = []
	hauteurs.resize(resolution + 1)
	for i in range(resolution + 1):
		hauteurs[i] = []
		hauteurs[i].resize(resolution + 1)
		for j in range(resolution + 1):
			var wx: float = origin_x + i * step
			var wz: float = origin_z + j * step
			# Bruit avec wrap (monde torique)
			var taille_monde: float = world_size_chunks * chunk_size
			var nx: float = fposmod(wx, taille_monde)
			var nz: float = fposmod(wz, taille_monde)
			hauteurs[i][j] = bruit.get_noise_2d(nx, nz) * amplitude

	# Construction des triangles (low-poly = normals non interpolés)
	for i in range(resolution):
		for j in range(resolution):
			var p00 := Vector3(i * step, hauteurs[i][j], j * step)
			var p10 := Vector3((i + 1) * step, hauteurs[i + 1][j], j * step)
			var p01 := Vector3(i * step, hauteurs[i][j + 1], (j + 1) * step)
			var p11 := Vector3((i + 1) * step, hauteurs[i + 1][j + 1], (j + 1) * step)

			# Deux triangles par quad
			_ajouter_triangle(st, p00, p10, p11)
			_ajouter_triangle(st, p00, p11, p01)

	st.generate_normals()
	# Pas de generate_tangents → look low-poly plus franc

	var mesh := st.commit()
	mesh_instance = MeshInstance3D.new()
	mesh_instance.mesh = mesh

	# Matériau simple unlit / low-poly
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 0.9
	mat.metallic = 0.0
	# Shading un peu plat
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_PER_VERTEX
	mesh_instance.material_override = mat

	add_child(mesh_instance)


func _ajouter_triangle(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3) -> void:
	# Couleur selon la hauteur moyenne (herbe / roche / sable)
	var h_moy: float = (a.y + b.y + c.y) / 3.0
	var col: Color
	if h_moy < -2.0:
		col = couleur_sable
	elif h_moy > 6.0:
		col = couleur_roche.lerp(Color(0.7, 0.7, 0.75), clampf((h_moy - 6.0) / 8.0, 0.0, 1.0))
	else:
		col = couleur_herbe.lerp(couleur_roche, clampf(h_moy / 8.0, 0.0, 0.4))

	# Variation légère pour casser la uniformité
	col = col.lightened(randf_range(-0.04, 0.04))

	st.set_color(col)
	st.add_vertex(a)
	st.set_color(col)
	st.add_vertex(b)
	st.set_color(col)
	st.add_vertex(c)


func _creer_collision() -> void:
	# Collision simplifiée : on utilise le même mesh (concave)
	if mesh_instance == null or mesh_instance.mesh == null:
		return

	collision = StaticBody3D.new()
	col_shape = CollisionShape3D.new()

	# Shape concave à partir du mesh (ok pour terrain statique)
	var shape := ConcavePolygonShape3D.new()
	# On extrait les faces
	var faces: PackedVector3Array = mesh_instance.mesh.get_faces()
	shape.set_faces(faces)
	col_shape.shape = shape

	collision.add_child(col_shape)
	add_child(collision)


func _peupler() -> void:
	# Seed déterministe par chunk pour un monde reproductible
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(coord) + 1337

	var origin_x: float = coord.x * chunk_size
	var origin_z: float = coord.y * chunk_size
	var taille_monde: float = world_size_chunks * chunk_size

	# Arbres
	var nb_arbres := rng.randi_range(2, 7)
	for i in range(nb_arbres):
		var lx := rng.randf() * chunk_size
		var lz := rng.randf() * chunk_size
		var wx := fposmod(origin_x + lx, taille_monde)
		var wz := fposmod(origin_z + lz, taille_monde)
		var h := bruit.get_noise_2d(wx, wz) * amplitude
		# Pas d'arbres trop bas (plage) ni trop haut (roche)
		if h < -1.5 or h > 7.0:
			continue
		var arbre := RessourceNode.new()
		arbre.type = RessourceNode.TypeRessource.ARBRE
		arbre.id_drop = "bois"
		arbre.quantite_par_coup = 1
		arbre.coups_necessaires = 4
		arbre.nom_affichage = "Arbre"
		arbre.position = Vector3(lx, h, lz)
		add_child(arbre)

	# Minerais (plus rares, zones rocheuses)
	var nb_minerais := rng.randi_range(0, 2)
	for i in range(nb_minerais):
		var lx := rng.randf() * chunk_size
		var lz := rng.randf() * chunk_size
		var wx := fposmod(origin_x + lx, taille_monde)
		var wz := fposmod(origin_z + lz, taille_monde)
		var h := bruit.get_noise_2d(wx, wz) * amplitude
		if h < 3.0:
			continue
		var filon := RessourceNode.new()
		filon.type = RessourceNode.TypeRessource.MINERAI
		filon.id_drop = "minerai_fer"
		filon.quantite_par_coup = 1
		filon.coups_necessaires = 5
		filon.nom_affichage = "Filon de fer"
		filon.position = Vector3(lx, h, lz)
		add_child(filon)

	# Ennemis occasionnels (loups)
	if rng.randf() < 0.35:
		var lx := rng.randf() * chunk_size
		var lz := rng.randf() * chunk_size
		var wx := fposmod(origin_x + lx, taille_monde)
		var wz := fposmod(origin_z + lz, taille_monde)
		var h := bruit.get_noise_2d(wx, wz) * amplitude
		if h > -1.0 and h < 8.0:
			var loup := Ennemi.new()
			loup.id_mob = "loup"
			loup.categories = ["etre_vivant", "sauvage", "monstre"]
			loup.nom = "Loup"
			loup.PV_max = 35.0
			loup.degats = 7.0
			loup.position = Vector3(lx, h + 0.5, lz)
			add_child(loup)
