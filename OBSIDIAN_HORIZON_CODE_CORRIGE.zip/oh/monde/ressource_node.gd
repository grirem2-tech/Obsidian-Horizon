extends StaticBody3D
class_name RessourceNode

# ==========================================================
#  OBSIDIAN HORIZON — Nœud de ressource (arbre, filon…)
#  Interaction E → récolte progressive.
# ==========================================================

enum TypeRessource { ARBRE, MINERAI, PLANTE }

@export var type: TypeRessource = TypeRessource.ARBRE
@export var id_drop: String = "bois"
@export var quantite_par_coup: int = 1
@export var coups_necessaires: int = 4
@export var nom_affichage: String = "Arbre"

var coups_restants: int = 4
var mesh_instance: MeshInstance3D


func _ready() -> void:
	coups_restants = coups_necessaires
	_creer_apparence()
	# Collision
	if not has_node("CollisionShape3D"):
		var col := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		match type:
			TypeRessource.ARBRE:
				shape.size = Vector3(0.6, 2.5, 0.6)
				col.position.y = 1.25
			TypeRessource.MINERAI:
				shape.size = Vector3(1.2, 0.8, 1.0)
				col.position.y = 0.4
			_:
				shape.size = Vector3(0.5, 0.5, 0.5)
				col.position.y = 0.25
		col.shape = shape
		add_child(col)


func _creer_apparence() -> void:
	mesh_instance = MeshInstance3D.new()
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_PER_VERTEX

	match type:
		TypeRessource.ARBRE:
			# Tronc
			var tronc := CylinderMesh.new()
			tronc.top_radius = 0.18
			tronc.bottom_radius = 0.25
			tronc.height = 2.2
			mesh_instance.mesh = tronc
			mesh_instance.position.y = 1.1
			mat.albedo_color = Color(0.4, 0.28, 0.15)
			mesh_instance.material_override = mat
			add_child(mesh_instance)

			# Feuillage low-poly
			var feuilles := MeshInstance3D.new()
			var sphere := SphereMesh.new()
			sphere.radius = 0.9
			sphere.height = 1.6
			feuilles.mesh = sphere
			feuilles.position.y = 2.6
			var mat_f := mat.duplicate()
			mat_f.albedo_color = Color(0.25, 0.5, 0.2)
			feuilles.material_override = mat_f
			add_child(feuilles)

		TypeRessource.MINERAI:
			var box := BoxMesh.new()
			box.size = Vector3(1.1, 0.7, 0.9)
			mesh_instance.mesh = box
			mesh_instance.position.y = 0.35
			mat.albedo_color = Color(0.5, 0.48, 0.45)
			mesh_instance.material_override = mat
			add_child(mesh_instance)

			# Cristaux
			var cristal := MeshInstance3D.new()
			var cmesh := BoxMesh.new()
			cmesh.size = Vector3(0.25, 0.5, 0.25)
			cristal.mesh = cmesh
			cristal.position = Vector3(0.2, 0.7, 0.1)
			cristal.rotation_degrees = Vector3(15, 30, 10)
			var mat_c := mat.duplicate()
			mat_c.albedo_color = Color(0.55, 0.6, 0.7)
			cristal.material_override = mat_c
			add_child(cristal)

		_:
			var box := BoxMesh.new()
			box.size = Vector3(0.4, 0.4, 0.4)
			mesh_instance.mesh = box
			mesh_instance.position.y = 0.2
			mat.albedo_color = Color(0.3, 0.6, 0.25)
			mesh_instance.material_override = mat
			add_child(mesh_instance)


func interagir(joueur: Node) -> void:
	if coups_restants <= 0:
		return

	coups_restants -= 1

	# Feedback scale
	var tween := create_tween()
	tween.tween_property(self, "scale", Vector3(0.92, 1.05, 0.92), 0.06)
	tween.tween_property(self, "scale", Vector3.ONE, 0.08)

	if Inventaire:
		Inventaire.ajouter_par_id(id_drop, quantite_par_coup)

	# Progression titres
	if Titres:
		match type:
			TypeRessource.ARBRE:
				Titres.incrementer_progression("abattre_arbre")
			TypeRessource.MINERAI:
				Titres.incrementer_progression("miner")

	if coups_restants <= 0:
		_detruire()


func _detruire() -> void:
	var tween := create_tween()
	tween.tween_property(self, "scale", Vector3.ZERO, 0.3)
	tween.tween_callback(queue_free)
