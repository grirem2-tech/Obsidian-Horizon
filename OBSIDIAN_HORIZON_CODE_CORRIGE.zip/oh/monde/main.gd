extends Node3D

# ==========================================================
#  OBSIDIAN HORIZON — Scène principale de bootstrap
#  Attache ce script à un Node3D racine de ta scène Main.tscn
#  Il crée automatiquement : soleil, monde, joueur, HUD.
# ==========================================================

func _ready() -> void:
	_setup_eclairage()
	_setup_monde()
	_setup_joueur()
	_setup_hud()
	print("=== OBSIDIAN HORIZON prêt ===")
	print("ZQSD/WASD déplacer | Souris regarder | Clic gauche attaquer")
	print("E interagir (arbres/minerais) | Shift courir | Ctrl accroupi | Espace sauter")
	print("Échap libérer la souris")


func _setup_eclairage() -> void:
	var soleil := DirectionalLight3D.new()
	soleil.name = "Soleil"
	soleil.rotation_degrees = Vector3(-45, 30, 0)
	soleil.light_energy = 1.15
	soleil.shadow_enabled = true
	add_child(soleil)

	var env := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_COLOR
	environment.background_color = Color(0.55, 0.72, 0.9)
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.4, 0.45, 0.5)
	environment.ambient_light_energy = 0.35
	environment.tonemap_mode = Environment.TONE_MAPPER_ACES
	env.environment = environment
	add_child(env)


func _setup_monde() -> void:
	var wm := WorldManager.new()
	wm.name = "WorldManager"
	wm.add_to_group("world_manager")
	wm.CHUNK_SIZE = 64.0
	wm.WORLD_SIZE_CHUNKS = 24   # un peu plus petit pour démarrer léger
	wm.VIEW_RADIUS = 2
	wm.PRELOAD_RADIUS = 3
	wm.amplitude_relief = 10.0
	add_child(wm)

	var streamer := WorldStreamer.new()
	streamer.name = "WorldStreamer"
	streamer.world_manager = wm
	add_child(streamer)


func _setup_joueur() -> void:
	var joueur := Player.new()
	joueur.name = "Joueur"
	joueur.position = Vector3(32, 25, 32)  # au-dessus du terrain
	# Collision capsule
	var col := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.35
	shape.height = 1.6
	col.shape = shape
	col.position.y = 0.9
	joueur.add_child(col)
	add_child(joueur)

	# Équipement de départ minimal
	if Inventaire:
		Inventaire.ajouter_par_id("epee_rouillee", 1)
		Inventaire.ajouter_par_id("chemise_basique", 1)
		Inventaire.ajouter_par_id("pantalon_basique", 1)
		Inventaire.ajouter_par_id("bottes_basiques", 1)
		Inventaire.ajouter_or(50)


func _setup_hud() -> void:
	var hud := preload("res://hud.gd").new() if ResourceLoader.exists("res://hud.gd") else null
	if hud == null:
		# Fallback : charge depuis le même dossier de scripts
		hud = CanvasLayer.new()
		hud.set_script(load("res://scripts/hud.gd") if ResourceLoader.exists("res://scripts/hud.gd") else null)
	if hud:
		add_child(hud)
	else:
		# Création directe
		var h := Node.new()
		h.set_script(load("res://hud.gd"))
		if h.get_script():
			add_child(h)
		else:
			push_warning("HUD non trouvé — place hud.gd dans res://")
