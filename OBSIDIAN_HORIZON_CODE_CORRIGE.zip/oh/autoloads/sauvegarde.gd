extends Node

# ==========================================================
#  OBSIDIAN HORIZON — Autoload Sauvegarde
#  Sauvegarde de SESSION (quit / menu), pas un checkpoint anti-mort.
#
#  À la mort (runtime, géré par Player.mourir) :
#    - inventaire vidé (sauf logique déjà prévue)
#    - 20 % de l'or perdu
#    - équipement de base en FER sans stats donné
#  Les titres / compétences / flags secrets restent permanents.
#
#  Ce qui est sauvé à l'écriture :
#    - position, vivant/mort
#    - inventaire + or (l'état actuel, post-mort si tu viens de mourir)
#    - titres + progression + compétences
#    - seed monde + chunks force-load (base, tour) + région joueur
# ==========================================================

signal sauvegarde_ok(slot: int)
signal sauvegarde_echec(slot: int, raison: String)
signal chargement_ok(slot: int)
signal chargement_echec(slot: int, raison: String)

const VERSION: int = 1
const NB_SLOTS: int = 3
const DOSSIER: String = "user://sauvegardes/"
const PREFIX: String = "slot_"

## Chunks toujours prioritaires (base joueur, tour). Le WorldManager
## doit les traiter en force_load même hors VIEW_RADIUS.
var chunks_force_load: Array[Vector2i] = []


func _ready() -> void:
	DirAccess.make_dir_recursive_absolute(DOSSIER)


func _chemin(slot: int) -> String:
	return "%s%s%d.json" % [DOSSIER, PREFIX, slot]


func existe(slot: int) -> bool:
	return FileAccess.file_exists(_chemin(slot))


func infos_slot(slot: int) -> Dictionary:
	if not existe(slot):
		return {"vide": true, "slot": slot}
	var data := _lire_brut(slot)
	if data.is_empty():
		return {"vide": true, "slot": slot}
	var meta: Dictionary = data.get("meta", {})
	var joueur: Dictionary = data.get("joueur", {})
	return {
		"vide": false,
		"slot": slot,
		"version": data.get("version", 0),
		"nom": meta.get("nom", "Aventurier"),
		"timestamp": meta.get("timestamp", 0),
		"temps_jeu": meta.get("temps_jeu", 0.0),
		"est_gnome": joueur.get("est_gnome", false),
		"vivant": joueur.get("vivant", true),
		"etage_actuel": joueur.get("etage_actuel", 0),
		"or": data.get("inventaire", {}).get("or", 0),
	}


# ----------------------------------------------------------
#  SAUVER
# ----------------------------------------------------------
func sauver(slot: int, nom_perso: String = "Aventurier") -> bool:
	if slot < 0 or slot >= NB_SLOTS:
		sauvegarde_echec.emit(slot, "Slot invalide")
		return false

	var joueur := get_tree().get_first_node_in_group("joueur")
	if joueur == null:
		sauvegarde_echec.emit(slot, "Aucun joueur")
		return false

	var data := {
		"version": VERSION,
		"meta": {
			"nom": nom_perso,
			"timestamp": int(Time.get_unix_time_from_system()),
			"temps_jeu": _temps_jeu_approx(),
		},
		"joueur": _serialiser_joueur(joueur),
		"titres": _serialiser_titres(),
		"competences": _serialiser_competences(joueur),
		"inventaire": _serialiser_inventaire(),
		"monde": _serialiser_monde(joueur),
		"tour": _serialiser_tour(),
		"flags": _serialiser_flags(joueur),
	}

	var json := JSON.stringify(data, "\t")
	var path := _chemin(slot)
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		sauvegarde_echec.emit(slot, "Impossible d'écrire %s" % path)
		return false
	f.store_string(json)
	f.close()
	sauvegarde_ok.emit(slot)
	print("Sauvegarde slot %d OK (%s)" % [slot, path])
	return true


# ----------------------------------------------------------
#  CHARGER
# ----------------------------------------------------------
func charger(slot: int) -> bool:
	if not existe(slot):
		chargement_echec.emit(slot, "Slot vide")
		return false

	var data := _lire_brut(slot)
	if data.is_empty():
		chargement_echec.emit(slot, "Fichier illisible")
		return false

	if int(data.get("version", 0)) > VERSION:
		chargement_echec.emit(slot, "Version de save trop récente")
		return false

	var joueur := get_tree().get_first_node_in_group("joueur")
	if joueur == null:
		chargement_echec.emit(slot, "Aucun joueur en scène")
		return false

	_appliquer_joueur(joueur, data.get("joueur", {}))
	_appliquer_titres(data.get("titres", {}))
	_appliquer_competences(joueur, data.get("competences", {}))
	_appliquer_inventaire(data.get("inventaire", {}))
	_appliquer_monde(data.get("monde", {}))
	_appliquer_tour(data.get("tour", {}))
	_appliquer_flags(joueur, data.get("flags", {}))

	if joueur.has_method("calculer_stats_finales"):
		joueur.calculer_stats_finales()

	chargement_ok.emit(slot)
	print("Chargement slot %d OK" % slot)
	return true


func effacer(slot: int) -> void:
	var path := _chemin(slot)
	if FileAccess.file_exists(path):
		DirAccess.remove_absolute(path)


# ----------------------------------------------------------
#  MORT — règles runtime (appelé par Player.mourir)
#  Pas une "save spéciale" : on mute l'état, la prochaine
#  sauvegarde de quit écrira cet état appauvri.
# ----------------------------------------------------------
## À appeler depuis Player.mourir() AVANT le respawn.
## - vide l'inventaire (équipement de base fer sans stats)
## - retire 20 % de l'or
func appliquer_penalites_mort() -> void:
	if Inventaire == null:
		return

	# Or : -20 %
	var or_actuel: int = Inventaire.or_actuel
	var perte: int = int(floor(float(or_actuel) * 0.20))
	Inventaire.or_actuel = maxi(0, or_actuel - perte)
	Inventaire.or_modifie.emit()

	# Inventaire / barre / équipement : tout vider
	Inventaire.slots.fill(null)
	Inventaire.barre_rapide.fill(null)
	for slot in Inventaire.equipement.keys():
		Inventaire.equipement[slot] = null

	# Stuff de base en FER, sans stats (pas de bonus RNG / pas d'effets)
	_donner_equipement_fer_base()

	Inventaire.inventaire_modifie.emit()
	Inventaire.barre_rapide_modifiee.emit()
	Inventaire.equipement_modifie.emit()


func _donner_equipement_fer_base() -> void:
	# Objets fixes, stats plates minimales, aucun effet
	var epee := {
		"id": "epee_fer_base",
		"nom": "Épée de fer",
		"type": "arme",
		"type_equipement": "arme",
		"degats": 8.0,
		"max_stack": 1,
		"materiau_principal": "fer",
		"qualite": "correct",
		"effets": [],
		"description": "Épée de fer basique. Aucune propriété particulière.",
	}
	var plastron := {
		"id": "plastron_fer_base",
		"nom": "Plastron de fer",
		"type": "armure",
		"type_equipement": "plastron",
		"defense": 4.0,
		"max_stack": 1,
		"materiau_principal": "fer",
		"effets": [],
		"description": "Plastron de fer basique.",
	}
	var casque := {
		"id": "casque_fer_base",
		"nom": "Casque de fer",
		"type": "armure",
		"type_equipement": "casque",
		"defense": 2.0,
		"max_stack": 1,
		"materiau_principal": "fer",
		"effets": [],
	}
	var jambieres := {
		"id": "jambieres_fer_base",
		"nom": "Jambières de fer",
		"type": "armure",
		"type_equipement": "jambieres",
		"defense": 3.0,
		"max_stack": 1,
		"materiau_principal": "fer",
		"effets": [],
	}
	var bottes := {
		"id": "bottes_fer_base",
		"nom": "Bottes de fer",
		"type": "armure",
		"type_equipement": "bottes",
		"defense": 1.0,
		"max_stack": 1,
		"materiau_principal": "fer",
		"effets": [],
	}

	Inventaire.equipement["arme_principale"] = epee
	Inventaire.equipement["plastron"] = plastron
	Inventaire.equipement["casque"] = casque
	Inventaire.equipement["jambieres"] = jambieres
	Inventaire.equipement["bottes"] = bottes


# ----------------------------------------------------------
#  SÉRIALISATION
# ----------------------------------------------------------
func _serialiser_joueur(joueur: Node) -> Dictionary:
	var pos: Vector3 = joueur.global_position if joueur is Node3D else Vector3.ZERO
	var vivant := true
	if "PV_actuels" in joueur:
		vivant = joueur.PV_actuels > 0.0
	return {
		"position": [pos.x, pos.y, pos.z],
		"vivant": vivant,
		"PV_actuels": joueur.get("PV_actuels"),
		"PM_actuels": joueur.get("PM_actuels"),
		"PV_max": joueur.get("PV_max"),
		"PM_max": joueur.get("PM_max"),
		"vitesse_deplacement": joueur.get("vitesse_deplacement"),
		"degats_base": joueur.get("degats_base"),
		"taux_drop": joueur.get("taux_drop"),
		"est_gnome": joueur.get("est_gnome"),
		"etage_actuel": joueur.get("etage_actuel"),
		"possede_une_base": joueur.get("possede_une_base"),
		"en_route_divine": joueur.get("en_route_divine"),
		"reputation_pnj": joueur.get("reputation_pnj"),
	}


func _serialiser_titres() -> Dictionary:
	if Titres == null:
		return {}
	return {
		"debloques": Titres.titres_debloques.duplicate(),
		"progression": Titres.progression_titres.duplicate(),
	}


func _serialiser_competences(joueur: Node) -> Dictionary:
	var debloquees: Array = []
	if Competences:
		debloquees = Competences.competences_debloquees.duplicate()
	return {
		"debloquees": debloquees,
		"actives": joueur.get("competences_actives").duplicate() if "competences_actives" in joueur else [],
		"passives": joueur.get("competences_passives").duplicate() if "competences_passives" in joueur else [],
	}


func _serialiser_inventaire() -> Dictionary:
	if Inventaire == null:
		return {}
	return {
		"or": Inventaire.or_actuel,
		"slots": _serialiser_cases(Inventaire.slots),
		"barre_rapide": _serialiser_cases(Inventaire.barre_rapide),
		"equipement": Inventaire.equipement.duplicate(true),
	}


func _serialiser_cases(cases: Array) -> Array:
	var out: Array = []
	for c in cases:
		if c == null:
			out.append(null)
		else:
			out.append({"objet": c["objet"].duplicate(true), "quantite": c["quantite"]})
	return out


func _serialiser_monde(joueur: Node) -> Dictionary:
	var seed_monde := 42
	var chunks_charges: Array = []
	var wm = get_tree().get_first_node_in_group("world_manager")
	if wm:
		if "bruit" in wm and wm.bruit:
			seed_monde = wm.bruit.seed
		if "chunks_charges" in wm:
			for coord in wm.chunks_charges.keys():
				chunks_charges.append([coord.x, coord.y])

	var force: Array = []
	for c in chunks_force_load:
		force.append([c.x, c.y])

	return {
		"seed": seed_monde,
		"chunks_charges": chunks_charges,
		"chunks_force_load": force,
		# Base / Tour : le WorldManager les remettra en force_load au chargement
	}


func _serialiser_tour() -> Dictionary:
	if Tour:
		return Tour.serialiser()
	return {}


func _serialiser_flags(joueur: Node) -> Dictionary:
	return {
		"en_route_divine": joueur.get("en_route_divine") if "en_route_divine" in joueur else false,
		"possede_une_base": joueur.get("possede_une_base") if "possede_une_base" in joueur else false,
	}


# ----------------------------------------------------------
#  APPLICATION
# ----------------------------------------------------------
func _appliquer_joueur(joueur: Node, data: Dictionary) -> void:
	if data.is_empty():
		return
	var p: Array = data.get("position", [16, 20, 16])
	if joueur is Node3D and p.size() >= 3:
		joueur.global_position = Vector3(float(p[0]), float(p[1]), float(p[2]))

	for cle in ["PV_actuels", "PM_actuels", "PV_max", "PM_max", "vitesse_deplacement",
			"degats_base", "taux_drop", "est_gnome", "etage_actuel",
			"possede_une_base", "en_route_divine"]:
		if data.has(cle) and cle in joueur:
			joueur.set(cle, data[cle])

	if data.has("reputation_pnj") and "reputation_pnj" in joueur:
		joueur.reputation_pnj = data["reputation_pnj"]

	# Si la save dit "mort" (cas limite), on force un état respawn propre
	if data.get("vivant", true) == false and joueur.has_method("mourir"):
		# Déjà mort dans la save : on applique les pénalités si inventaire encore plein
		pass


func _appliquer_titres(data: Dictionary) -> void:
	if Titres == null or data.is_empty():
		return
	Titres.titres_debloques = []
	for id in data.get("debloques", []):
		Titres.titres_debloques.append(str(id))
	Titres.progression_titres = data.get("progression", {}).duplicate()

	# Ré-appliquer les effets titres sur le joueur
	var joueur := get_tree().get_first_node_in_group("joueur")
	if joueur and "titres_debloques" in joueur:
		joueur.titres_debloques = []
		for id in Titres.titres_debloques:
			if Titres.catalogue_titres.has(id):
				joueur.titres_debloques.append(Titres.catalogue_titres[id])


func _appliquer_competences(joueur: Node, data: Dictionary) -> void:
	if data.is_empty():
		return
	if Competences:
		Competences.competences_debloquees = []
		for id in data.get("debloquees", []):
			Competences.competences_debloquees.append(str(id))
	if "competences_actives" in joueur:
		joueur.competences_actives = data.get("actives", []).duplicate()
	if "competences_passives" in joueur:
		joueur.competences_passives = data.get("passives", []).duplicate()


func _appliquer_inventaire(data: Dictionary) -> void:
	if Inventaire == null or data.is_empty():
		return
	Inventaire.or_actuel = int(data.get("or", 0))
	var slots: Array = data.get("slots", [])
	for i in range(mini(slots.size(), Inventaire.slots.size())):
		Inventaire.slots[i] = slots[i]
	var barre: Array = data.get("barre_rapide", [])
	for i in range(mini(barre.size(), Inventaire.barre_rapide.size())):
		Inventaire.barre_rapide[i] = barre[i]
	var equip: Dictionary = data.get("equipement", {})
	for k in equip.keys():
		if Inventaire.equipement.has(k):
			Inventaire.equipement[k] = equip[k]
	Inventaire.inventaire_modifie.emit()
	Inventaire.barre_rapide_modifiee.emit()
	Inventaire.equipement_modifie.emit()
	Inventaire.or_modifie.emit()


func _appliquer_monde(data: Dictionary) -> void:
	if data.is_empty():
		return
	chunks_force_load.clear()
	for c in data.get("chunks_force_load", []):
		if c is Array and c.size() >= 2:
			chunks_force_load.append(Vector2i(int(c[0]), int(c[1])))

	var wm = get_tree().get_first_node_in_group("world_manager")
	if wm == null:
		return
	if "bruit" in wm and wm.bruit and data.has("seed"):
		wm.bruit.seed = int(data["seed"])
	# Force-load base / tour : le manager doit exposer une API ; fallback soft
	if wm.has_method("definir_chunks_force_load"):
		wm.definir_chunks_force_load(chunks_force_load)
	if wm.has_method("recharger_autour_joueur"):
		wm.recharger_autour_joueur()


func _appliquer_tour(data: Dictionary) -> void:
	if Tour and not data.is_empty():
		Tour.deserialiser(data)


func _appliquer_flags(joueur: Node, data: Dictionary) -> void:
	if data.is_empty():
		return
	if "en_route_divine" in joueur:
		joueur.en_route_divine = data.get("en_route_divine", false)
	if "possede_une_base" in joueur:
		joueur.possede_une_base = data.get("possede_une_base", false)


# ----------------------------------------------------------
#  UTIL
# ----------------------------------------------------------
func _lire_brut(slot: int) -> Dictionary:
	var path := _chemin(slot)
	if not FileAccess.file_exists(path):
		return {}
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return {}
	var txt := f.get_as_text()
	f.close()
	var parsed = JSON.parse_string(txt)
	if parsed is Dictionary:
		return parsed
	return {}


func _temps_jeu_approx() -> float:
	return float(Time.get_ticks_msec()) / 1000.0


## Hook pratique : sauvegarder le slot 0 à la fermeture de l'app
func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		# Sauvegarde auto slot 0 à la fermeture (optionnel, peut être retiré)
		sauver(0)
