extends Node

# ==========================================================
#  OBSIDIAN HORIZON — Autoload Inventaire
#  À déclarer en Autoload sous le nom exact "Inventaire".
# ==========================================================

signal inventaire_modifie
signal barre_rapide_modifiee
signal equipement_modifie
signal or_modifie
signal etat_ouverture_change(est_ouvert: bool)

# ----------------------------------------------------------
#  CONFIGURATION
# ----------------------------------------------------------
const NB_COLONNES: int = 8
const NB_LIGNES: int = 5
const TAILLE_TOTALE: int = NB_COLONNES * NB_LIGNES          # 40
const TAILLE_BARRE_RAPIDE: int = 9

## Slots d'équipement (ordre logique pour l'UI)
const SLOTS_EQUIPEMENT: Array[String] = [
	"casque", "collier",
	"anneau_1", "anneau_2", "anneau_3", "anneau_4",
	"plastron", "bouclier", "jambieres", "bottes",
	"arme_principale", "arme_secondaire"
]

# ----------------------------------------------------------
#  DONNÉES
# ----------------------------------------------------------
## Chaque case = null ou { "objet": Dictionary, "quantite": int }
var slots: Array = []
var barre_rapide: Array = []
var equipement: Dictionary = {}

var or_actuel: int = 0
var est_ouvert: bool = false

## Équipement de base conservé à la mort (ids d'objets)
var ids_equipement_base: Array[String] = [
	"epee_rouillee",
	"chemise_basique",
	"pantalon_basique",
	"bottes_basiques"
]


func _ready() -> void:
	_initialiser()


func _initialiser() -> void:
	slots.resize(TAILLE_TOTALE)
	slots.fill(null)

	barre_rapide.resize(TAILLE_BARRE_RAPIDE)
	barre_rapide.fill(null)

	for slot in SLOTS_EQUIPEMENT:
		equipement[slot] = null


# ----------------------------------------------------------
#  OUVERTURE / FERMETURE
# ----------------------------------------------------------
func ouvrir() -> void:
	est_ouvert = true
	etat_ouverture_change.emit(true)


func fermer() -> void:
	est_ouvert = false
	etat_ouverture_change.emit(false)


func basculer() -> void:
	if est_ouvert:
		fermer()
	else:
		ouvrir()


# ----------------------------------------------------------
#  OR
# ----------------------------------------------------------
func ajouter_or(montant: int) -> void:
	if montant <= 0:
		return
	or_actuel += montant
	or_modifie.emit()
	# Titre Millionnaire (seuil)
	if Titres:
		Titres.verifier_seuil("or_possede", float(or_actuel))


func retirer_or(montant: int) -> bool:
	if montant <= 0:
		return true
	if or_actuel < montant:
		return false
	or_actuel -= montant
	or_modifie.emit()
	return true


# ----------------------------------------------------------
#  AJOUT D'OBJETS
# ----------------------------------------------------------
## Ajoute un objet dans la première case libre (ou empile si stackable).
## Retourne true si l'ajout a réussi.
func ajouter_objet(objet: Dictionary, quantite: int = 1) -> bool:
	if quantite <= 0 or objet.is_empty():
		return false

	var id_objet: String = objet.get("id", "")
	var max_stack: int = objet.get("max_stack", 1)

	# 1. Essayer d'empiler sur des stacks existants
	if max_stack > 1:
		for i in range(TAILLE_TOTALE):
			var case = slots[i]
			if case != null and case["objet"].get("id") == id_objet:
				var place_libre: int = max_stack - case["quantite"]
				if place_libre > 0:
					var a_ajouter: int = mini(quantite, place_libre)
					case["quantite"] += a_ajouter
					quantite -= a_ajouter
					if quantite <= 0:
						inventaire_modifie.emit()
						return true

	# 2. Cases vides
	for i in range(TAILLE_TOTALE):
		if slots[i] == null:
			var a_ajouter: int = mini(quantite, max_stack)
			slots[i] = {
				"objet": objet.duplicate(true),
				"quantite": a_ajouter
			}
			quantite -= a_ajouter
			if quantite <= 0:
				inventaire_modifie.emit()
				return true

	inventaire_modifie.emit()
	return quantite <= 0


## Version pratique pour les drops / craft
func ajouter_par_id(id: String, quantite: int = 1) -> bool:
	var objet := _creer_objet_depuis_id(id)
	if objet.is_empty():
		push_warning("Inventaire : objet inconnu '%s'" % id)
		return false
	return ajouter_objet(objet, quantite)


# ----------------------------------------------------------
#  RETRAIT
# ----------------------------------------------------------
func retirer_objet(index: int, quantite: int = 1) -> bool:
	if index < 0 or index >= TAILLE_TOTALE:
		return false
	var case = slots[index]
	if case == null:
		return false

	case["quantite"] -= quantite
	if case["quantite"] <= 0:
		slots[index] = null

	inventaire_modifie.emit()
	return true


func retirer_par_id(id: String, quantite: int = 1) -> bool:
	var reste := quantite
	for i in range(TAILLE_TOTALE):
		var case = slots[i]
		if case != null and case["objet"].get("id") == id:
			var a_retirer: int = mini(reste, case["quantite"])
			case["quantite"] -= a_retirer
			reste -= a_retirer
			if case["quantite"] <= 0:
				slots[i] = null
			if reste <= 0:
				inventaire_modifie.emit()
				return true
	inventaire_modifie.emit()
	return reste <= 0


# ----------------------------------------------------------
#  ÉQUIPEMENT
# ----------------------------------------------------------
func equiper(objet: Dictionary, slot: String) -> bool:
	if not equipement.has(slot):
		return false
	# Si un objet est déjà équipé, on le range dans l'inventaire
	if equipement[slot] != null:
		ajouter_objet(equipement[slot], 1)
	equipement[slot] = objet.duplicate(true)
	equipement_modifie.emit()
	return true


func desequiper(slot: String) -> bool:
	if not equipement.has(slot) or equipement[slot] == null:
		return false
	var objet = equipement[slot]
	if ajouter_objet(objet, 1):
		equipement[slot] = null
		equipement_modifie.emit()
		return true
	return false


# ----------------------------------------------------------
#  BARRE RAPIDE
# ----------------------------------------------------------
func assigner_barre_rapide(index_barre: int, index_inventaire: int) -> void:
	if index_barre < 0 or index_barre >= TAILLE_BARRE_RAPIDE:
		return
	if index_inventaire < 0 or index_inventaire >= TAILLE_TOTALE:
		return
	barre_rapide[index_barre] = slots[index_inventaire]
	barre_rapide_modifiee.emit()


func utiliser_barre_rapide(index: int) -> void:
	if index < 0 or index >= TAILLE_BARRE_RAPIDE:
		return
	var case = barre_rapide[index]
	if case == null:
		return
	# Point d'entrée pour consommer / activer l'objet
	# (à brancher plus tard sur le système de combat / items)
	print("Utilisation barre rapide %d : %s" % [index, case["objet"].get("nom", "?")])


# ----------------------------------------------------------
#  MORT — CONSERVATION DE L'ÉQUIPEMENT DE BASE
# ----------------------------------------------------------
## Appelé par Player.mourir().
## On vide tout sauf les objets dont l'id est dans ids_equipement_base
## (et on les rééquipe si possible).
func vider_sauf_equipement_base() -> void:
	# 1. Sauvegarder l'équipement de base actuellement porté
	var a_garder: Array[Dictionary] = []
	for slot in equipement.keys():
		var obj = equipement[slot]
		if obj != null and obj.get("id", "") in ids_equipement_base:
			a_garder.append(obj.duplicate(true))
		equipement[slot] = null

	# 2. Vider inventaire + barre rapide
	slots.fill(null)
	barre_rapide.fill(null)

	# 3. Remettre l'équipement de base
	for obj in a_garder:
		var slot_cible := _trouver_slot_pour_objet(obj)
		if slot_cible != "":
			equipement[slot_cible] = obj

	inventaire_modifie.emit()
	barre_rapide_modifiee.emit()
	equipement_modifie.emit()


func _trouver_slot_pour_objet(objet: Dictionary) -> String:
	var type: String = objet.get("type_equipement", "")
	match type:
		"casque": return "casque"
		"collier": return "collier"
		"anneau":
			for s in ["anneau_1", "anneau_2", "anneau_3", "anneau_4"]:
				if equipement[s] == null:
					return s
			return "anneau_1"
		"plastron": return "plastron"
		"bouclier": return "bouclier"
		"jambieres": return "jambieres"
		"bottes": return "bottes"
		"arme": return "arme_principale"
		_: return ""


# ----------------------------------------------------------
#  UTILITAIRES
# ----------------------------------------------------------
func compter_objet(id: String) -> int:
	var total := 0
	for case in slots:
		if case != null and case["objet"].get("id") == id:
			total += case["quantite"]
	return total


func a_de_la_place() -> bool:
	for case in slots:
		if case == null:
			return true
	return false


## Catalogue minimal d'objets de base (à enrichir plus tard)
func _creer_objet_depuis_id(id: String) -> Dictionary:
	match id:
		"epee_rouillee":
			return {
				"id": "epee_rouillee",
				"nom": "Épée rouillée",
				"type": "arme",
				"type_equipement": "arme",
				"degats": 5,
				"max_stack": 1
			}
		"chemise_basique":
			return {
				"id": "chemise_basique",
				"nom": "Chemise basique",
				"type": "armure",
				"type_equipement": "plastron",
				"defense": 1,
				"max_stack": 1
			}
		"pantalon_basique":
			return {
				"id": "pantalon_basique",
				"nom": "Pantalon basique",
				"type": "armure",
				"type_equipement": "jambieres",
				"defense": 1,
				"max_stack": 1
			}
		"bottes_basiques":
			return {
				"id": "bottes_basiques",
				"nom": "Bottes basiques",
				"type": "armure",
				"type_equipement": "bottes",
				"defense": 1,
				"max_stack": 1
			}
		"bois":
			return { "id": "bois", "nom": "Bois", "type": "ressource", "max_stack": 99 }
		"minerai_fer":
			return { "id": "minerai_fer", "nom": "Minerai de fer", "type": "ressource", "max_stack": 99 }
		"potion_vie":
			return { "id": "potion_vie", "nom": "Potion de vie", "type": "consommable", "max_stack": 20, "soin": 30 }
		"potion_mana":
			return { "id": "potion_mana", "nom": "Potion de mana", "type": "consommable", "max_stack": 20, "mana": 25 }
		"fiole_sang_monstre":
			return { "id": "fiole_sang_monstre", "nom": "Fiole de sang de monstre", "type": "consommable", "max_stack": 50 }
		"poupee_vaudou":
		"peau_loup":
			return { "id": "peau_loup", "nom": "Peau de loup", "type": "ressource", "max_stack": 50 }
		"viande_cru":
			return { "id": "viande_cru", "nom": "Viande crue", "type": "consommable", "max_stack": 30, "soin": 5 }
		"poupee_vaudou":
			return {
				"id": "poupee_vaudou",
				"nom": "Poupée vaudou",
				"type": "special",
				"description": "Une poupée étrange... Sa description est vague.",
				"max_stack": 1
			}

		"minerai_cuivre":
			return { "id": "minerai_cuivre", "nom": "Minerai de cuivre", "type": "ressource", "max_stack": 99 }
		"minerai_argent":
			return { "id": "minerai_argent", "nom": "Minerai d'argent", "type": "ressource", "max_stack": 99 }
		"minerai_or":
			return { "id": "minerai_or", "nom": "Minerai d'or", "type": "ressource", "max_stack": 99 }
		"minerai_mithril":
			return { "id": "minerai_mithril", "nom": "Minerai de mithril", "type": "ressource", "max_stack": 99 }
		"minerai_obsidienne":
			return { "id": "minerai_obsidienne", "nom": "Minerai d'obsidienne", "type": "ressource", "max_stack": 99 }
		"minerai_etherium":
			return { "id": "minerai_etherium", "nom": "Minerai d'éthérium", "type": "ressource", "max_stack": 99 }
		"oeil_bestial":
			return { "id": "oeil_bestial", "nom": "Œil bestial", "type": "composant", "max_stack": 50 }
		"os_renforces":
			return { "id": "os_renforces", "nom": "Os renforcés", "type": "composant", "max_stack": 50 }
		"ecaille_reptile":
			return { "id": "ecaille_reptile", "nom": "Écaille de reptile", "type": "composant", "max_stack": 50 }
		"aile_membraneuse":
			return { "id": "aile_membraneuse", "nom": "Aile membraneuse", "type": "composant", "max_stack": 30 }
		"croc_alpha":
			return { "id": "croc_alpha", "nom": "Croc d'alpha", "type": "composant", "max_stack": 30 }
		"noyau_elementaire_feu":
			return { "id": "noyau_elementaire_feu", "nom": "Noyau élémentaire de feu", "type": "composant", "max_stack": 20 }
		"noyau_elementaire_glace":
			return { "id": "noyau_elementaire_glace", "nom": "Noyau élémentaire de glace", "type": "composant", "max_stack": 20 }
		"fragment_ombre":
			return { "id": "fragment_ombre", "nom": "Fragment d'ombre", "type": "composant", "max_stack": 20 }
		"glande_venin":
			return { "id": "glande_venin", "nom": "Glande à venin", "type": "composant", "max_stack": 30 }


		"minerai_diamant":
			return { "id": "minerai_diamant", "nom": "Minerai de diamant", "type": "ressource", "max_stack": 99 }
		"minerai_adamantium":
			return { "id": "minerai_adamantium", "nom": "Minerai d'adamantium", "type": "ressource", "max_stack": 99 }
		"minerai_cristal":
			return { "id": "minerai_cristal", "nom": "Minerai de cristal", "type": "ressource", "max_stack": 99 }
		"minerai_orichalque":
			return { "id": "minerai_orichalque", "nom": "Minerai d'orichalque", "type": "ressource", "max_stack": 99 }
		"minerai_ebonite":
			return { "id": "minerai_ebonite", "nom": "Minerai d'ébonite", "type": "ressource", "max_stack": 99 }
		"minerai_metal_celeste":
			return { "id": "minerai_metal_celeste", "nom": "Métal céleste", "type": "ressource", "max_stack": 99 }

		_:
			return {}
