extends Node

# ==========================================================
#  OBSIDIAN HORIZON — Autoload Tour
#  Génération de la Tour (100 étages / 10 sections).
#
#  Niveau 1 : identité de section (DA, matériaux, monstres…)
#  Niveau 2 : layout procédural de chaque étage sous ces contraintes
#
#  Types d'étage :
#    - normal  : combat / exploration procédurale
#    - tp      : hub safe (5, 15, 25…) — entrée/sortie, pas de monstres
#    - boss    : arène + boss (10, 20, 30… 100)
# ==========================================================

signal etage_genere(numero: int, data: Dictionary)
signal section_changee(index_section: int)
signal hub_tp_decouvert(numero: int)
signal boss_vaincu(numero: int, id_boss: String)

const NB_ETAGES: int = 100
const TAILLE_SECTION: int = 10
const NB_SECTIONS: int = 10

## Hubs TP découverts (progression permanente) — à sauvegarder
var hubs_decouverts: Array[int] = []

## Seed de run (change la structure des étages, pas l'ordre des sections)
var seed_run: int = 0

## Cache des étages déjà générés cette session { numero: Dictionary }
var cache_etages: Dictionary = {}

## Étage actuellement chargé (0 = hors Tour / monde extérieur)
var etage_actuel: int = 0


func _ready() -> void:
	if seed_run == 0:
		seed_run = randi()


# ----------------------------------------------------------
#  CATALOGUE DES SECTIONS (DA fixe)
# ----------------------------------------------------------
const SECTIONS: Array[Dictionary] = [
	{
		"index": 0,
		"id": "ruines_pierre",
		"nom": "Ruines de pierre ancienne",
		"etages": [1, 10],
		"palette": {"primary": Color(0.45, 0.42, 0.38), "accent": Color(0.55, 0.5, 0.35), "fog": Color(0.3, 0.28, 0.25)},
		"materiaux": ["pierre_ancienne", "colonne_brisee", "dalle_fissuree"],
		"architecture": ["grandes_salles", "couloirs_etroits", "cours_interieures"],
		"familles_monstres": ["squelette_faible", "rat_geant", "golem_pierre_mineur"],
		"pieges": ["dalle_effondree", "fleche_mur"],
		"ambiance": "poussiere_echo",
		"boss": {"id": "gardien_des_ruines", "nom": "Gardien des Ruines"},
	},
	{
		"index": 1,
		"id": "foret_ancienne",
		"nom": "Forêt ancienne",
		"etages": [11, 20],
		"palette": {"primary": Color(0.2, 0.35, 0.18), "accent": Color(0.35, 0.5, 0.25), "fog": Color(0.15, 0.22, 0.12)},
		"materiaux": ["bois_vivant", "mousse", "racines"],
		"architecture": ["clairieres", "sentiers", "arbres_creux"],
		"familles_monstres": ["loup", "treant_jeune", "fée_hostile"],
		"pieges": ["racine_fouet", "brume_toxique"],
		"ambiance": "vent_feuilles",
		"boss": {"id": "coeur_de_la_foret", "nom": "Cœur de la Forêt"},
	},
	{
		"index": 2,
		"id": "volcan_magma",
		"nom": "Volcan / magma",
		"etages": [21, 30],
		"palette": {"primary": Color(0.35, 0.15, 0.1), "accent": Color(0.9, 0.35, 0.1), "fog": Color(0.25, 0.08, 0.05)},
		"materiaux": ["roche_volcanique", "lave", "obsidienne_brute"],
		"architecture": ["grandes_salles", "ponts", "ruines_calcinees"],
		"familles_monstres": ["elementaire_feu", "salamandre", "golem_magma"],
		"pieges": ["flaque_lave", "geyser_brulant"],
		"ambiance": "chaleur_cendre",
		"boss": {"id": "seigneur_magma", "nom": "Seigneur du Magma"},
	},
	{
		"index": 3,
		"id": "crypte_morts",
		"nom": "Crypte / morts-vivants",
		"etages": [31, 40],
		"palette": {"primary": Color(0.25, 0.28, 0.3), "accent": Color(0.4, 0.55, 0.45), "fog": Color(0.12, 0.15, 0.14)},
		"materiaux": ["pierre_tombale", "ossements", "chaines"],
		"architecture": ["couloirs_bas", "salles_sarcophages", "catacombes"],
		"familles_monstres": ["mort_vivant", "spectre", "nécrophage"],
		"pieges": ["gaz_mephitique", "main_squelette"],
		"ambiance": "froid_silence",
		"boss": {"id": "roi_squelette", "nom": "Roi Squelette"},
	},
	{
		"index": 4,
		"id": "cite_abandonnee",
		"nom": "Cité abandonnée",
		"etages": [41, 50],
		"palette": {"primary": Color(0.4, 0.38, 0.42), "accent": Color(0.55, 0.4, 0.35), "fog": Color(0.22, 0.2, 0.25)},
		"materiaux": ["brique", "tuile", "fer_rouille"],
		"architecture": ["rues", "places", "interieurs_maisons"],
		"familles_monstres": ["brigand_spectral", "golem_urbain", "chien_errant"],
		"pieges": ["plancher_effondre", "piege_arbalete"],
		"ambiance": "vent_urbain",
		"boss": {"id": "maire_fantome", "nom": "Maire Fantôme"},
	},
	{
		"index": 5,
		"id": "cavernes_cristallines",
		"nom": "Cavernes cristallines",
		"etages": [51, 60],
		"palette": {"primary": Color(0.35, 0.4, 0.55), "accent": Color(0.6, 0.45, 0.85), "fog": Color(0.2, 0.22, 0.35)},
		"materiaux": ["cristal", "quartz", "minerai_rare"],
		"architecture": ["grottes", "ponts_cristal", "salles_reflets"],
		"familles_monstres": ["elementaire_cristal", "araignee_gemme", "golem_cristal"],
		"pieges": ["pic_cristal", "resonance_aveuglante"],
		"ambiance": "echo_lumineux",
		"boss": {"id": "matriarche_cristal", "nom": "Matriarche de Cristal"},
	},
	{
		"index": 6,
		"id": "temple_celeste",
		"nom": "Temple céleste",
		"etages": [61, 70],
		"palette": {"primary": Color(0.75, 0.78, 0.85), "accent": Color(0.95, 0.9, 0.55), "fog": Color(0.55, 0.6, 0.7)},
		"materiaux": ["marbre_blanc", "or_sacré", "vitrail"],
		"architecture": ["nefs", "colonnes_hautes", "terrasses"],
		"familles_monstres": ["sentinelle_celeste", "esprit_lumiere", "ange_dechu_mineur"],
		"pieges": ["rayon_sacré", "dalle_jugement"],
		"ambiance": "choeur_lointain",
		"boss": {"id": "archonte_celeste", "nom": "Archonte Céleste"},
	},
	{
		"index": 7,
		"id": "royaume_demoniaque",
		"nom": "Royaume démoniaque",
		"etages": [71, 80],
		"palette": {"primary": Color(0.25, 0.08, 0.1), "accent": Color(0.7, 0.15, 0.2), "fog": Color(0.15, 0.05, 0.08)},
		"materiaux": ["basalte_noir", "sang_seche", "fer_maudit"],
		"architecture": ["arches_tordues", "fosses", "salles_trones"],
		"familles_monstres": ["demon_mineur", "diablotin", "molosse_infernal"],
		"pieges": ["flammes_infernales", "chaine_maudite"],
		"ambiance": "cris_lointains",
		"boss": {"id": "seigneur_demon", "nom": "Seigneur Démon"},
	},
	{
		"index": 8,
		"id": "dimension_corrompue",
		"nom": "Dimension corrompue",
		"etages": [81, 90],
		"palette": {"primary": Color(0.3, 0.15, 0.35), "accent": Color(0.6, 0.2, 0.7), "fog": Color(0.18, 0.1, 0.22)},
		"materiaux": ["matiere_instable", "cristal_noir", "chair_pierre"],
		"architecture": ["geometrie_impossible", "salles_inversées", "failles"],
		"familles_monstres": ["aberration", "ombre_corrompue", "héraut_du_vide"],
		"pieges": ["gravite_inversee", "zone_folie"],
		"ambiance": "distorsion",
		"boss": {"id": "avatar_corruption", "nom": "Avatar de la Corruption"},
	},
	{
		"index": 9,
		"id": "palais_divin",
		"nom": "Palais divin",
		"etages": [91, 100],
		"palette": {"primary": Color(0.85, 0.82, 0.7), "accent": Color(1.0, 0.85, 0.4), "fog": Color(0.65, 0.62, 0.55)},
		"materiaux": ["or_divin", "marbre_eternel", "lumiere_solide"],
		"architecture": ["salles_du_trone", "jardins_suspendus", "escaliers_infinis"],
		"familles_monstres": ["gardien_divin", "seraphin", "jugement"],
		"pieges": ["epreuve_foi", "lame_de_lumiere"],
		"ambiance": "silence_sacré",
		"boss": {"id": "gardien_du_trone", "nom": "Gardien du Trône"},
	},
]


# ----------------------------------------------------------
#  REQUÊTES DE BASE
# ----------------------------------------------------------
func index_section(etage: int) -> int:
	if etage < 1 or etage > NB_ETAGES:
		return -1
	return (etage - 1) / TAILLE_SECTION


func obtenir_section(etage: int) -> Dictionary:
	var idx := index_section(etage)
	if idx < 0 or idx >= SECTIONS.size():
		return {}
	return SECTIONS[idx]


func type_etage(etage: int) -> String:
	if etage < 1 or etage > NB_ETAGES:
		return "invalide"
	if etage % 10 == 5:
		return "tp"
	if etage % 10 == 0:
		return "boss"
	return "normal"


func est_hub_tp(etage: int) -> bool:
	return type_etage(etage) == "tp"


func est_boss(etage: int) -> bool:
	return type_etage(etage) == "boss"


func hub_est_decouvert(etage: int) -> bool:
	return etage in hubs_decouverts


func decouvrir_hub(etage: int) -> void:
	if not est_hub_tp(etage):
		return
	if etage in hubs_decouverts:
		return
	hubs_decouverts.append(etage)
	hub_tp_decouvert.emit(etage)


# ----------------------------------------------------------
#  GÉNÉRATION D'ÉTAGE
# ----------------------------------------------------------
## Point d'entrée : retourne la data complète d'un étage (cache si déjà fait).
func generer_etage(etage: int) -> Dictionary:
	if etage < 1 or etage > NB_ETAGES:
		push_warning("Tour : étage invalide %d" % etage)
		return {}

	if cache_etages.has(etage):
		return cache_etages[etage]

	var section := obtenir_section(etage)
	var type_e := type_etage(etage)
	var rng := RandomNumberGenerator.new()
	# Seed déterministe par run + numéro d'étage
	rng.seed = hash(str(seed_run) + ":" + str(etage))

	var data: Dictionary = {
		"numero": etage,
		"type": type_e,
		"section_index": section.get("index", 0),
		"section_id": section.get("id", ""),
		"section_nom": section.get("nom", ""),
		"palette": section.get("palette", {}),
		"materiaux": section.get("materiaux", []).duplicate(),
		"architecture": section.get("architecture", []).duplicate(),
		"ambiance": section.get("ambiance", ""),
		"pieges_pool": section.get("pieges", []).duplicate(),
		"familles_monstres": section.get("familles_monstres", []).duplicate(),
		"salles": [],
		"ennemis": [],
		"coffres": [],
		"secrets": [],
		"evenements": [],
		"boss": null,
		"safe": false,
	}

	match type_e:
		"tp":
			_generer_hub_tp(data, section, rng)
		"boss":
			_generer_etage_boss(data, section, rng)
		_:
			_generer_etage_normal(data, section, rng)

	cache_etages[etage] = data
	etage_genere.emit(etage, data)
	return data


func _generer_hub_tp(data: Dictionary, section: Dictionary, rng: RandomNumberGenerator) -> void:
	data["safe"] = true
	data["salles"] = [
		{
			"id": "hub_central",
			"type": "hub",
			"taille": "grande",
			"liens": ["sortie_monde", "monte", "descend"],
			"props": ["autel_tp", "banc", "feu_camp"],
		}
	]
	# Boutique occasionnelle selon section
	if rng.randf() < 0.55:
		data["salles"].append({
			"id": "boutique_hub",
			"type": "boutique",
			"taille": "petite",
			"liens": ["hub_central"],
			"props": ["comptoir", "etagere"],
		})
	# Checkpoint toujours présent
	data["evenements"] = [{"type": "checkpoint", "id": "lit_hub"}]
	data["ennemis"] = []  # aucun monstre


func _generer_etage_boss(data: Dictionary, section: Dictionary, rng: RandomNumberGenerator) -> void:
	data["safe"] = false
	var boss_def: Dictionary = section.get("boss", {})
	data["boss"] = {
		"id": boss_def.get("id", "boss_section"),
		"nom": boss_def.get("nom", "Boss"),
		"section_id": section.get("id", ""),
	}
	data["salles"] = [
		{
			"id": "vestibule",
			"type": "couloir",
			"taille": "moyenne",
			"liens": ["arene"],
			"props": ["colonnes", "torches"],
		},
		{
			"id": "arene",
			"type": "arene_boss",
			"taille": "tres_grande",
			"liens": ["vestibule", "sortie_apres_boss"],
			"props": _props_arene(section, rng),
		},
	]
	# Loot boss : 2 objets + 1 livre de compétence (selon design doc)
	data["coffres"] = [
		{"id": "loot_boss", "rarete": "boss", "garanti_livre_competence": true, "nb_objets": 2}
	]
	data["ennemis"] = []  # le boss est géré à part


func _props_arene(section: Dictionary, rng: RandomNumberGenerator) -> Array:
	var base: Array = ["sol_arene", "murs_hauts"]
	var mats: Array = section.get("materiaux", [])
	if mats.size() > 0:
		base.append(mats[rng.randi() % mats.size()])
	return base


func _generer_etage_normal(data: Dictionary, section: Dictionary, rng: RandomNumberGenerator) -> void:
	data["safe"] = false

	# Nombre de salles selon profondeur (un peu plus densé plus haut)
	var profondeur: float = float(data["numero"]) / float(NB_ETAGES)
	var nb_salles: int = rng.randi_range(5, 8) + int(profondeur * 3)

	var types_salle := ["combat", "combat", "couloir", "vide", "ressource", "piege"]
	var archi: Array = section.get("architecture", ["salle"])

	var salles: Array = []
	# Entrée
	salles.append({
		"id": "entree",
		"type": "entree",
		"taille": "petite",
		"liens": [],
		"props": [archi[0] if archi.size() > 0 else "porte"],
	})

	for i in range(1, nb_salles):
		var t: String = types_salle[rng.randi() % types_salle.size()]
		# Moins de salles vides en fin de Tour
		if t == "vide" and profondeur > 0.6 and rng.randf() < 0.5:
			t = "combat"
		var salle := {
			"id": "salle_%d" % i,
			"type": t,
			"taille": ["petite", "moyenne", "grande"][rng.randi() % 3],
			"liens": [],
			"props": _props_salle(section, t, rng),
		}
		salles.append(salle)

	# Sortie (vers étage suivant conceptuellement)
	salles.append({
		"id": "sortie",
		"type": "sortie",
		"taille": "petite",
		"liens": [],
		"props": ["escalier"],
	})

	# Graphe simple : chaîne + quelques embranchements
	_relier_salles(salles, rng)

	# Salles secrètes (1–2 max)
	var nb_secrets := 0
	if rng.randf() < 0.35:
		nb_secrets = 1
	if rng.randf() < 0.12:
		nb_secrets = 2
	for s in range(nb_secrets):
		var host_idx := rng.randi_range(1, salles.size() - 2)
		var secret := {
			"id": "secret_%d" % s,
			"type": "secret",
			"taille": "petite",
			"liens": [salles[host_idx]["id"]],
			"props": ["mur_fissure", "cachette"],
		}
		salles[host_idx]["liens"].append(secret["id"])
		salles.append(secret)
		data["secrets"].append({"salle": secret["id"], "host": salles[host_idx]["id"]})

	data["salles"] = salles

	# Ennemis
	data["ennemis"] = _placer_ennemis(salles, section, data["numero"], rng)

	# Coffres
	data["coffres"] = _placer_coffres(salles, data["numero"], rng)

	# Événements mineurs
	if rng.randf() < 0.2:
		data["evenements"].append({
			"type": "evenement_aleatoire",
			"id": "event_%d" % data["numero"],
		})


func _props_salle(section: Dictionary, type_salle: String, rng: RandomNumberGenerator) -> Array:
	var props: Array = []
	var mats: Array = section.get("materiaux", [])
	var archi: Array = section.get("architecture", [])
	if mats.size() > 0:
		props.append(mats[rng.randi() % mats.size()])
	if archi.size() > 0 and rng.randf() < 0.6:
		props.append(archi[rng.randi() % archi.size()])
	match type_salle:
		"piege":
			var pieges: Array = section.get("pieges", [])
			if pieges.size() > 0:
				props.append(pieges[rng.randi() % pieges.size()])
		"ressource":
			props.append("veine_minerai" if rng.randf() < 0.5 else "coffre_bois")
		"combat":
			props.append("debris")
	return props


func _relier_salles(salles: Array, rng: RandomNumberGenerator) -> void:
	# Chaîne principale
	for i in range(salles.size() - 1):
		var a: Dictionary = salles[i]
		var b: Dictionary = salles[i + 1]
		if not b["id"] in a["liens"]:
			a["liens"].append(b["id"])
		if not a["id"] in b["liens"]:
			b["liens"].append(a["id"])

	# Embranchements (raccourcis / boucles)
	var nb_extra := rng.randi_range(1, 3)
	for _e in range(nb_extra):
		var i := rng.randi_range(0, salles.size() - 1)
		var j := rng.randi_range(0, salles.size() - 1)
		if i == j:
			continue
		var a: Dictionary = salles[i]
		var b: Dictionary = salles[j]
		if not b["id"] in a["liens"]:
			a["liens"].append(b["id"])
		if not a["id"] in b["liens"]:
			b["liens"].append(a["id"])


func _placer_ennemis(salles: Array, section: Dictionary, etage: int, rng: RandomNumberGenerator) -> Array:
	var familles: Array = section.get("familles_monstres", ["monstre"])
	var ennemis: Array = []
	var densite: float = 0.45 + float(etage) / 200.0  # un peu plus dense en haut

	for salle in salles:
		if salle["type"] in ["entree", "sortie", "secret", "vide", "hub"]:
			continue
		if salle["type"] == "couloir" and rng.randf() > densite * 0.5:
			continue
		if rng.randf() > densite and salle["type"] != "combat":
			continue

		var nb := 1
		if salle["type"] == "combat":
			nb = rng.randi_range(1, 3)
		elif salle["taille"] == "grande":
			nb = rng.randi_range(1, 2)

		for k in range(nb):
			var fam: String = familles[rng.randi() % familles.size()]
			ennemis.append({
				"id_template": fam,
				"salle": salle["id"],
				"niveau_approx": 1 + (etage - 1) / 10,
			})
	return ennemis


func _placer_coffres(salles: Array, etage: int, rng: RandomNumberGenerator) -> Array:
	var coffres: Array = []
	for salle in salles:
		var chance := 0.08
		if salle["type"] == "secret":
			chance = 0.85
		elif salle["type"] == "ressource":
			chance = 0.4
		elif salle["type"] == "combat":
			chance = 0.15
		if rng.randf() < chance:
			var rarete := "commun"
			if salle["type"] == "secret":
				rarete = "rare" if rng.randf() < 0.5 else "inhabituel"
			elif etage > 50 and rng.randf() < 0.15:
				rarete = "inhabituel"
			coffres.append({
				"id": "coffre_%s" % salle["id"],
				"salle": salle["id"],
				"rarete": rarete,
			})
	return coffres


# ----------------------------------------------------------
#  NAVIGATION / RUNTIME
# ----------------------------------------------------------
## Charge un étage (génère si besoin) et met à jour etage_actuel.
func entrer_etage(numero: int) -> Dictionary:
	var data := generer_etage(numero)
	if data.is_empty():
		return {}
	etage_actuel = numero
	if est_hub_tp(numero):
		decouvrir_hub(numero)

	var joueur := get_tree().get_first_node_in_group("joueur")
	if joueur and "etage_actuel" in joueur:
		joueur.etage_actuel = numero

	var sec_idx := index_section(numero)
	section_changee.emit(sec_idx)
	return data


func sortir_tour() -> void:
	etage_actuel = 0
	var joueur := get_tree().get_first_node_in_group("joueur")
	if joueur and "etage_actuel" in joueur:
		joueur.etage_actuel = 0


## Liste des hubs TP utilisables (découverts)
func hubs_disponibles() -> Array[int]:
	var out: Array[int] = []
	for h in hubs_decouverts:
		out.append(h)
	out.sort()
	return out


## Invalide le cache (nouvelle run / nouveau seed)
func nouvelle_run(nouveau_seed: int = 0) -> void:
	seed_run = nouveau_seed if nouveau_seed != 0 else randi()
	cache_etages.clear()
	# hubs_decouverts restent (progression permanente) — ou clear si tu veux soft-reset
	print("Tour : nouvelle run, seed=%d" % seed_run)


# ----------------------------------------------------------
#  SÉRIALISATION (pour Sauvegarde)
# ----------------------------------------------------------
func serialiser() -> Dictionary:
	return {
		"seed_run": seed_run,
		"hubs_decouverts": hubs_decouverts.duplicate(),
		"etage_actuel": etage_actuel,
	}


func deserialiser(data: Dictionary) -> void:
	if data.is_empty():
		return
	seed_run = int(data.get("seed_run", seed_run))
	hubs_decouverts.clear()
	for h in data.get("hubs_decouverts", []):
		hubs_decouverts.append(int(h))
	etage_actuel = int(data.get("etage_actuel", 0))
	cache_etages.clear()  # régénérés à la demande avec le même seed
