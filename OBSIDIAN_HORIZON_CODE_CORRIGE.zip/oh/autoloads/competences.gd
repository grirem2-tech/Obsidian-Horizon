extends Node

# ==========================================================
#  OBSIDIAN HORIZON — Autoload Compétences
#  À déclarer en Autoload sous le nom "Competences".
#
#  Gère le catalogue des compétences (actives + passives),
#  le déblocage, et l'application des effets passifs.
# ==========================================================

signal competence_debloquee(id: String)
signal slots_modifies

## Catalogue complet
var catalogue: Dictionary = {}

## Ids débloqués (permanents une fois obtenus)
var competences_debloquees: Array[String] = []


func _ready() -> void:
	_enregistrer_competences()


func _ajouter(def: Dictionary) -> void:
	catalogue[def["id"]] = def


# ----------------------------------------------------------
#  DÉBLOCAGE
# ----------------------------------------------------------
func debloquer(id: String) -> void:
	if id in competences_debloquees or not catalogue.has(id):
		return
	competences_debloquees.append(id)
	competence_debloquee.emit(id)
	print("Compétence débloquée : %s" % catalogue[id]["nom"])


func est_debloquee(id: String) -> bool:
	return id in competences_debloquees


func obtenir_definition(id: String) -> Dictionary:
	return catalogue.get(id, {})


# ----------------------------------------------------------
#  APPLICATION DES PASSIFS (appelé depuis Player)
# ----------------------------------------------------------
## Parcourt les compétences passives équipées du joueur et
## ajoute leurs effets dans bonus_generique / etc.
## Appelé automatiquement par Player.calculer_stats_finales()
## si on branche le lien.
func appliquer_passifs_au_joueur(joueur: Node) -> void:
	if joueur == null:
		return

	for competence in joueur.competences_passives:
		var id: String = ""
		if competence is String:
			id = competence
		elif competence is Dictionary:
			id = competence.get("id", "")
		else:
			continue

		var def: Dictionary = catalogue.get(id, {})
		if def.is_empty():
			continue

		for effet in def.get("effets", []):
			var type_effet: String = effet.get("type", "")
			var valeur: float = effet.get("valeur", 0.0)

			# Boost Gnome uniquement sur les effets positifs
			if joueur.est_gnome and valeur > 0.0:
				valeur *= 1.5

			match type_effet:
				"degats_pourcent_contre_cible":
					var cible: String = effet.get("cible", "")
					joueur.bonus_degats_contre[cible] = joueur.bonus_degats_contre.get(cible, 0.0) + valeur
				"reduction_degats_recus_pourcent_contre_cible":
					var cible2: String = effet.get("cible", "")
					joueur.bonus_reduction_degats_recus_de[cible2] = joueur.bonus_reduction_degats_recus_de.get(cible2, 0.0) + valeur
				_:
					joueur.bonus_generique[type_effet] = joueur.bonus_generique.get(type_effet, 0.0) + valeur


# ----------------------------------------------------------
#  CATALOGUE — COMPÉTENCES PASSIVES
# ----------------------------------------------------------
func _enregistrer_competences() -> void:
	# --- Passifs de base ---
	_ajouter({
		"id": "peau_de_metal",
		"nom": "Peau de métal",
		"type": "passive",
		"description": "Augmente l'efficacité du bouclier.",
		"effets": [{"type": "bouclier_pourcent", "valeur": 15.0}],
		"source": "livre"  # drop / livre
	})

	_ajouter({
		"id": "peau_de_pierre",
		"nom": "Peau de pierre",
		"type": "passive",
		"description": "Réduit légèrement les dégâts reçus.",
		"effets": [{"type": "defense_pourcent", "valeur": 8.0}],
		"source": "livre"
	})

	_ajouter({
		"id": "peau_de_diamant",
		"nom": "Peau de diamant",
		"type": "passive",
		"description": "Forte réduction des dégâts reçus, mais malus de vitesse.",
		"effets": [
			{"type": "defense_pourcent", "valeur": 20.0},
			{"type": "vitesse_pourcent", "valeur": -10.0}
		],
		"source": "livre"
	})

	_ajouter({
		"id": "medecin",
		"nom": "Médecin",
		"type": "passive",
		"description": "Régénération naturelle des PV.",
		"effets": [{"type": "regeneration_pv_par_minute", "valeur": 2.0}],
		"source": "livre"
	})

	_ajouter({
		"id": "resistant",
		"nom": "Résistant",
		"type": "passive",
		"description": "Plus de PV, mais moins de vitesse.",
		"effets": [
			{"type": "pv_max_pourcent", "valeur": 15.0},
			{"type": "vitesse_pourcent", "valeur": -8.0}
		],
		"source": "livre"
	})

	_ajouter({
		"id": "monstre",
		"nom": "Monstre",
		"type": "passive",
		"description": "+ dégâts contre les êtres vivants.",
		"effets": [{"type": "degats_pourcent_contre_cible", "cible": "etre_vivant", "valeur": 15.0}],
		"source": "livre"
	})

	_ajouter({
		"id": "cannibale",
		"nom": "Cannibale",
		"type": "passive",
		"description": "Permet de manger des membres de sa propre espèce pour récupérer PV/PM.",
		"effets": [{"type": "comportemental"}],  # géré par le système d'items
		"source": "secret"
	})

	_ajouter({
		"id": "omnivore",
		"nom": "Omnivore",
		"type": "passive",
		"description": "Permet de manger des morceaux de monstres pour récupérer PV/PM.",
		"effets": [{"type": "comportemental"}],
		"source": "livre"
	})

	_ajouter({
		"id": "nictalope",
		"nom": "Nictalope",
		"type": "passive",
		"description": "Permet de voir dans le noir.",
		"effets": [{"type": "vision_nocturne", "valeur": 1.0}],
		"source": "livre"
	})

	# --- Forgeron ---
	_ajouter({
		"id": "forgeron_apprenti",
		"nom": "Forgeron apprenti",
		"type": "passive",
		"description": "+ chance de réussite à la forge.",
		"effets": [{"type": "chance_forge_pourcent", "valeur": 10.0}],
		"source": "craft"
	})

	_ajouter({
		"id": "forgeron_chevronne",
		"nom": "Forgeron chevronné",
		"type": "passive",
		"description": "Meilleure chance de réussite + qualité.",
		"effets": [
			{"type": "chance_forge_pourcent", "valeur": 20.0},
			{"type": "qualite_forge_pourcent", "valeur": 10.0}
		],
		"source": "craft"
	})

	_ajouter({
		"id": "forgeron_maitre",
		"nom": "Forgeron maître",
		"type": "passive",
		"description": "Maîtrise totale de la forge.",
		"effets": [
			{"type": "chance_forge_pourcent", "valeur": 35.0},
			{"type": "qualite_forge_pourcent", "valeur": 25.0}
		],
		"source": "craft"
	})

	# --- Compétences spéciales / Easter Eggs (conditions manuelles) ---
	_ajouter({
		"id": "route_du_sacrifice",
		"nom": "Route du Sacrifice",
		"type": "passive",
		"description": "Ignore les malus liés à la mort.",
		"effets": [{"type": "ignore_malus_mort", "valeur": 1.0}],
		"source": "secret",  # poupée vaudou étage 5 + sacrifice étage 100
		"condition_secrete": true
	})

	_ajouter({
		"id": "dernier_rempart",
		"nom": "Dernier Rempart",
		"type": "passive",
		"description": "À 1 PV : +1000 % dégâts pendant 10 s et régénère 20 % des PV.",
		"effets": [{"type": "comportemental"}],  # géré en combat
		"source": "secret",  # No Hit Perfect 100 étages
		"condition_secrete": true
	})

	_ajouter({
		"id": "zombie",
		"nom": "Zombie",
		"type": "passive",
		"description": "Survie temporaire à 1 PV pendant 10 s une fois par période.",
		"effets": [{"type": "comportemental"}],
		"source": "secret",  # 1 PV plus de 100 fois sans mourir
		"condition_secrete": true
	})

	_ajouter({
		"id": "berserker",
		"nom": "Berserker",
		"type": "passive",
		"description": "Chaque élimination donne +1 % PV/PM max.",
		"effets": [{"type": "comportemental"}],
		"source": "secret",  # titre Monstre + 100 fioles de sang avant étage 50
		"condition_secrete": true
	})

	_ajouter({
		"id": "archimage",
		"nom": "Archimage",
		"type": "passive",
		"description": "+30 % dégâts magiques, -10 % consommation de mana.",
		"effets": [
			{"type": "degats_magiques_pourcent", "valeur": 30.0},
			{"type": "consommation_mana_pourcent", "valeur": -10.0}
		],
		"source": "secret",  # toutes les compétences magiques
		"condition_secrete": true
	})

	_ajouter({
		"id": "doppelganger",
		"nom": "Doppelgänger",
		"type": "passive",
		"description": "40 % de chance de doubler une attaque sans coût de mana.",
		"effets": [{"type": "chance_double_attaque", "valeur": 40.0}],
		"source": "secret",  # étage caché + noyau
		"condition_secrete": true
	})

	# --- Quelques actives de base (exemples) ---
	_ajouter({
		"id": "boule_de_feu",
		"nom": "Boule de feu",
		"type": "active",
		"description": "Lance une boule de feu.",
		"cout_mana": 15,
		"degats_base": 25,
		"element": "feu",
		"source": "livre"
	})

	_ajouter({
		"id": "soin",
		"nom": "Soin",
		"type": "active",
		"description": "Restaure des PV.",
		"cout_mana": 20,
		"soin_base": 40,
		"source": "livre"
	})

	_ajouter({
		"id": "dash",
		"nom": "Dash",
		"type": "active",
		"description": "Esquive rapide vers l'avant.",
		"cout_mana": 8,
		"source": "livre"
	})

	_ajouter({
		"id": "cri_de_guerre",
		"nom": "Cri de guerre",
		"type": "active",
		"description": "Augmente temporairement les dégâts.",
		"cout_mana": 12,
		"duree": 8.0,
		"effets": [{"type": "degats_pourcent", "valeur": 20.0}],
		"source": "livre"
	})
