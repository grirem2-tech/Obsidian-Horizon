extends Node

# ==========================================================
#  OBSIDIAN HORIZON — Système de Forge
#  Pas de minijeu "tape-tape" : choix guidés + matériaux + RNG.
#
#  Flux :
#    1. Catégorie   → arme / armure / bonus
#    2. Type pièce  → épée, lance, plastron, anneau…
#    3. Matériau principal (minerai) → base stats + tier
#    4. Matériau secondaire (drop mob) → direction des effets + teinte
#    5. RNG → variance (une épée de fer peut sortir exceptionnelle)
#
#  Autoload recommandé sous le nom "Forge".
# ==========================================================

signal forge_reussie(objet: Dictionary)
signal forge_echouee(raison: String)

# ----------------------------------------------------------
#  CATÉGORIES & TYPES DE PIÈCES
# ----------------------------------------------------------
const CATEGORIES := {
	"arme": {
		"nom": "Arme",
		"types": {
			"epee": {"nom": "Épée", "slot": "arme_principale", "stat_principale": "degats"},
			"lance": {"nom": "Lance", "slot": "arme_principale", "stat_principale": "degats"},
			"arc": {"nom": "Arc", "slot": "arme_principale", "stat_principale": "degats"},
			"hache": {"nom": "Hache", "slot": "arme_principale", "stat_principale": "degats"},
			"baton_mage": {"nom": "Bâton de mage", "slot": "arme_principale", "stat_principale": "degats_magiques"},
		}
	},
	"armure": {
		"nom": "Armure",
		"types": {
			"casque": {"nom": "Casque", "slot": "casque", "stat_principale": "defense"},
			"plastron": {"nom": "Plastron", "slot": "plastron", "stat_principale": "defense"},
			"jambieres": {"nom": "Jambières", "slot": "jambieres", "stat_principale": "defense"},
			"bottes": {"nom": "Bottes", "slot": "bottes", "stat_principale": "defense"},
		}
	},
	"bonus": {
		"nom": "Bonus",
		"types": {
			"anneau": {"nom": "Anneau", "slot": "anneau", "stat_principale": "special"},
			"amulette": {"nom": "Amulette", "slot": "collier", "stat_principale": "special"},
		}
	}
}

# ----------------------------------------------------------
#  MATÉRIAUX PRINCIPAUX (minerais)
#  - effet_garanti : toujours appliqué (sauf Fer = aucun)
#  - nb_effets_rng  : nombre d'effets aléatoires EN PLUS
#    de l'effet de base et de ceux du secondaire
# ----------------------------------------------------------
const MATERIAUX_PRINCIPAUX := {
	"fer": {
		"nom": "Fer",
		"tier": 1,
		"couleur": Color(0.55, 0.55, 0.58),
		"mult_stat": 1.0,
		"id_item": "minerai_fer",
		"quantite": 5,
		"effet_garanti": null,           # Aucun
		"nb_effets_rng": 0,
	},
	"argent": {
		"nom": "Argent",
		"tier": 2,
		"couleur": Color(0.78, 0.80, 0.85),
		"mult_stat": 1.15,
		"id_item": "minerai_argent",
		"quantite": 4,
		# Bonus contre les morts-vivants
		"effet_garanti": {
			"type": "degats_pourcent_contre_cible",
			"cible": "mort_vivant",
			"min": 8.0, "max": 15.0,
		},
		"nb_effets_rng": 1,
	},
	"or": {
		"nom": "Or",
		"tier": 2,
		"couleur": Color(0.85, 0.72, 0.2),
		"mult_stat": 1.2,
		"id_item": "minerai_or",
		"quantite": 4,
		# Bonus de résistance
		"effet_garanti": {
			"type": "defense_pourcent",
			"min": 4.0, "max": 10.0,
		},
		"nb_effets_rng": 1,
	},
	"diamant": {
		"nom": "Diamant",
		"tier": 3,
		"couleur": Color(0.7, 0.85, 0.95),
		"mult_stat": 1.4,
		"id_item": "minerai_diamant",
		"quantite": 3,
		# Résistance + orientation aléatoire (résistance à un élément tiré)
		"effet_garanti": {
			"type": "resistance_orientee",  # résolu à la forge
			"min": 8.0, "max": 18.0,
		},
		"nb_effets_rng": 2,
	},
	"adamantium": {
		"nom": "Adamantium",
		"tier": 3,
		"couleur": Color(0.45, 0.48, 0.55),
		"mult_stat": 1.55,
		"id_item": "minerai_adamantium",
		"quantite": 3,
		# Bonus de dégâts physiques
		"effet_garanti": {
			"type": "degats_physiques_pourcent",
			"min": 8.0, "max": 16.0,
		},
		"nb_effets_rng": 2,
	},
	"mithril": {
		"nom": "Mithril",
		"tier": 3,
		"couleur": Color(0.55, 0.72, 0.88),
		"mult_stat": 1.5,
		"id_item": "minerai_mithril",
		"quantite": 3,
		# Bonus magique
		"effet_garanti": {
			"type": "degats_magiques_pourcent",
			"min": 8.0, "max": 16.0,
		},
		"nb_effets_rng": 2,
	},
	"obsidienne": {
		"nom": "Obsidienne",
		"tier": 4,
		"couleur": Color(0.12, 0.08, 0.16),
		"mult_stat": 1.65,
		"id_item": "minerai_obsidienne",
		"quantite": 3,
		# Résistance élémentaire (élément tiré)
		"effet_garanti": {
			"type": "resistance_elementaire",
			"min": 10.0, "max": 22.0,
		},
		"nb_effets_rng": 3,
	},
	"cristal": {
		"nom": "Cristal",
		"tier": 4,
		"couleur": Color(0.75, 0.55, 0.95),
		"mult_stat": 1.45,
		"id_item": "minerai_cristal",
		"quantite": 3,
		# Amplification du matériau secondaire (mult sur ses effets)
		"effet_garanti": {
			"type": "amplification_secondaire",
			"min": 1.25, "max": 1.6,  # multiplicateur
		},
		"nb_effets_rng": 3,
	},
	"orichalque": {
		"nom": "Orichalque",
		"tier": 4,
		"couleur": Color(0.7, 0.55, 0.25),
		"mult_stat": 1.7,
		"id_item": "minerai_orichalque",
		"quantite": 2,
		# Bonus polyvalent (dégâts + défense légers)
		"effet_garanti": {
			"type": "bonus_polyvalent",
			"min": 4.0, "max": 9.0,
		},
		"nb_effets_rng": 3,
	},
	"ebonite": {
		"nom": "Ébonite",
		"tier": 5,
		"couleur": Color(0.08, 0.06, 0.1),
		"mult_stat": 1.85,
		"id_item": "minerai_ebonite",
		"quantite": 2,
		# Affinité avec les ténèbres
		"effet_garanti": {
			"type": "degats_ombre_pourcent",
			"min": 12.0, "max": 24.0,
		},
		"nb_effets_rng": 4,
	},
	"metal_celeste": {
		"nom": "Métal céleste",
		"tier": 5,
		"couleur": Color(0.95, 0.92, 0.7),
		"mult_stat": 2.0,
		"id_item": "minerai_metal_celeste",
		"quantite": 2,
		# Bonus contre les créatures divines
		"effet_garanti": {
			"type": "degats_pourcent_contre_cible",
			"cible": "divin",
			"min": 15.0, "max": 30.0,
		},
		"nb_effets_rng": 4,
	},
}

# ----------------------------------------------------------
#  POOLS RNG — effets tirés selon nb_effets_rng du minerai
#  "poids" : proba relative dans le tirage
#  "rare"  : true → pool rare (faible proba globale)
#  element_aleatoire : un seul type qui choisit feu/glace/etc. à la résolution
# ----------------------------------------------------------
const ELEMENTS_DEGATS := ["feu", "glace", "electricite", "lumiere", "tenebres", "metal"]

## Pool commune (référencée par catégorie avec des poids adaptés)
const POOL_RNG_OFFENSIF := [
	{"type": "degats_pourcent", "min": 2.0, "max": 12.0, "poids": 12, "cat": "offensif"},
	{"type": "tranchant_pourcent", "min": 3.0, "max": 12.0, "poids": 8, "cat": "offensif"},
	{"type": "perforation_pourcent", "min": 3.0, "max": 14.0, "poids": 8, "cat": "offensif"},
	{"type": "brutalite_pourcent", "min": 4.0, "max": 14.0, "poids": 6, "cat": "offensif"},  # vs PV hauts
	{"type": "degats_critique_pourcent", "min": 5.0, "max": 20.0, "poids": 8, "cat": "offensif"},
	{"type": "vitesse_attaque_pourcent", "min": 2.0, "max": 10.0, "poids": 8, "cat": "offensif"},
	{"type": "vol_de_vie_pourcent", "min": 1.0, "max": 8.0, "poids": 7, "cat": "offensif"},
	{"type": "absorption_pm_pourcent", "min": 1.0, "max": 7.0, "poids": 5, "cat": "offensif"},
	{"type": "execution_pourcent", "min": 4.0, "max": 16.0, "poids": 5, "cat": "offensif"},  # vs PV bas
	# Un seul effet "élément" : l'élément est tiré à la résolution
	{"type": "degats_elementaires", "min": 4.0, "max": 16.0, "poids": 10, "cat": "elementaire", "element_aleatoire": true},
]

const POOL_RNG_DEFENSIF := [
	{"type": "pv_max_pourcent", "min": 2.0, "max": 12.0, "poids": 10, "cat": "defensif"},
	{"type": "resistance_pourcent", "min": 2.0, "max": 10.0, "poids": 10, "cat": "defensif"},
	{"type": "resistance_physique_pourcent", "min": 3.0, "max": 14.0, "poids": 8, "cat": "defensif"},
	{"type": "resistance_magique_pourcent", "min": 3.0, "max": 14.0, "poids": 8, "cat": "defensif"},
	{"type": "resistance_elementaire_pourcent", "min": 3.0, "max": 12.0, "poids": 7, "cat": "defensif"},
	{"type": "resistance_element_aleatoire", "min": 5.0, "max": 18.0, "poids": 8, "cat": "defensif", "element_aleatoire": true},
	{"type": "reduction_degats_recus_pourcent", "min": 2.0, "max": 10.0, "poids": 6, "cat": "defensif"},
	{"type": "reduction_degats_critiques_recus_pourcent", "min": 4.0, "max": 15.0, "poids": 5, "cat": "defensif"},
]

const POOL_RNG_REGEN := [
	{"type": "regeneration_pv_restants_par_seconde", "min": 1.0, "max": 9.0, "poids": 6, "cat": "regen"},  # % des PV restants / s
	{"type": "regeneration_pm_pourcent", "min": 1.0, "max": 6.0, "poids": 6, "cat": "regen"},
	{"type": "regeneration_apres_degat_pourcent", "min": 3.0, "max": 12.0, "poids": 4, "cat": "regen"},
	{"type": "recuperation_pv_sur_attaque", "min": 1.0, "max": 5.0, "poids": 5, "cat": "regen"},
	{"type": "recuperation_pm_sur_attaque", "min": 1.0, "max": 5.0, "poids": 4, "cat": "regen"},
]

const POOL_RNG_SPECIAL := [
	{"type": "reduction_cout_pm_pourcent", "min": 3.0, "max": 12.0, "poids": 5, "cat": "special"},
	{"type": "vitesse_pourcent", "min": 2.0, "max": 10.0, "poids": 7, "cat": "special"},
	{"type": "resistance_effets_negatifs_pourcent", "min": 5.0, "max": 18.0, "poids": 4, "cat": "special"},
	{"type": "resistance_alterations_elementaires_pourcent", "min": 5.0, "max": 18.0, "poids": 4, "cat": "special"},
	{"type": "durabilite_pourcent", "min": 10.0, "max": 40.0, "poids": 5, "cat": "special"},
	{"type": "puissance_forge_secondaire_pourcent", "min": 5.0, "max": 20.0, "poids": 3, "cat": "special"},
	{"type": "affinite_categorie", "min": 1.0, "max": 1.0, "poids": 2, "cat": "special"},  # flag comportemental
]

const POOL_RNG_CIBLE := [
	{"type": "degats_pourcent_contre_cible", "cible": "mort_vivant", "min": 5.0, "max": 18.0, "poids": 4, "cat": "cible"},
	{"type": "degats_pourcent_contre_cible", "cible": "monstre", "min": 4.0, "max": 14.0, "poids": 5, "cat": "cible"},
	{"type": "degats_pourcent_contre_cible", "cible": "humain", "min": 4.0, "max": 14.0, "poids": 3, "cat": "cible"},
	{"type": "degats_pourcent_contre_cible", "cible": "magique", "min": 4.0, "max": 14.0, "poids": 4, "cat": "cible"},
	{"type": "degats_pourcent_contre_cible", "cible": "boss", "min": 5.0, "max": 16.0, "poids": 3, "cat": "cible"},
	{"type": "degats_pourcent_contre_cible", "cible": "divin", "min": 6.0, "max": 20.0, "poids": 2, "cat": "cible"},
]

## Très rares — proba globale faible (poids petits + filtre séparé)
const POOL_RNG_RARE := [
	{"type": "dernier_souffle", "min": 1.0, "max": 1.0, "poids": 1, "cat": "rare", "rare": true},
	{"type": "second_souffle", "min": 1.0, "max": 1.0, "poids": 1, "cat": "rare", "rare": true},
	{"type": "reflexion_degats_pourcent", "min": 3.0, "max": 12.0, "poids": 1, "cat": "rare", "rare": true},
	{"type": "double_impact_chance", "min": 3.0, "max": 12.0, "poids": 1, "cat": "rare", "rare": true},
	{"type": "drain_pourcent", "min": 2.0, "max": 8.0, "poids": 1, "cat": "rare", "rare": true},  # vol vie + abs PM
	{"type": "amplification_effets_pourcent", "min": 5.0, "max": 15.0, "poids": 1, "cat": "rare", "rare": true},
]

## Chance (0–1) qu'un effet RNG tiré vienne de la pool rare
const CHANCE_EFFET_RARE := 0.04

# ----------------------------------------------------------
#  MATÉRIAUX SECONDAIRES (drops de mobs) — direction d'effet + teinte
#  Pas les livres / équipements : organes, fluides, fragments…
# ----------------------------------------------------------
const MATERIAUX_SECONDAIRES := {
	# --- Offensifs / armes ---
	"fiole_sang_monstre": {
		"nom": "Fiole de sang de monstre",
		"teinte": Color(0.7, 0.1, 0.12),
		"tags": ["sang", "vie", "sauvage"],
		"effets_arme": [
			{"type": "vol_de_vie_pourcent", "min": 2.0, "max": 8.0},
			{"type": "degats_pourcent", "min": 3.0, "max": 10.0},
		],
		"effets_armure": [
			{"type": "regeneration_pv_par_minute", "min": 0.5, "max": 2.0},
		],
		"effets_bonus": [
			{"type": "vol_de_vie_pourcent", "min": 1.0, "max": 5.0},
		],
	},
	"oeil_bestial": {
		"nom": "Œil bestial",
		"teinte": Color(0.9, 0.2, 0.15),
		"tags": ["precision", "critique", "vision"],
		"effets_arme": [
			{"type": "chance_critique_pourcent", "min": 3.0, "max": 12.0},
			{"type": "degats_critique_pourcent", "min": 5.0, "max": 20.0},
		],
		"effets_armure": [
			{"type": "detection_ennemis_pourcent", "min": 5.0, "max": 15.0},
		],
		"effets_bonus": [
			{"type": "chance_critique_pourcent", "min": 2.0, "max": 8.0},
		],
	},
	"os_renforces": {
		"nom": "Os renforcés",
		"teinte": Color(0.9, 0.88, 0.8),
		"tags": ["robustesse", "percant"],
		"effets_arme": [
			{"type": "penetration_armure_pourcent", "min": 4.0, "max": 14.0},
			{"type": "degats_pourcent", "min": 2.0, "max": 7.0},
		],
		"effets_armure": [
			{"type": "defense_pourcent", "min": 3.0, "max": 10.0},
			{"type": "resistance_physique_pourcent", "min": 4.0, "max": 12.0},
		],
		"effets_bonus": [
			{"type": "pv_max_pourcent", "min": 2.0, "max": 8.0},
		],
	},
	"ecaille_reptile": {
		"nom": "Écaille de reptile",
		"teinte": Color(0.25, 0.55, 0.3),
		"tags": ["ecaille", "resistance", "poison"],
		"effets_arme": [
			{"type": "chance_poison_pourcent", "min": 5.0, "max": 18.0},
			{"type": "degats_poison_pourcent", "min": 4.0, "max": 12.0},
		],
		"effets_armure": [
			{"type": "resistance_poison_pourcent", "min": 8.0, "max": 25.0},
			{"type": "defense_pourcent", "min": 2.0, "max": 6.0},
		],
		"effets_bonus": [
			{"type": "resistance_poison_pourcent", "min": 5.0, "max": 15.0},
		],
	},
	"aile_membraneuse": {
		"nom": "Aile membraneuse",
		"teinte": Color(0.45, 0.35, 0.55),
		"tags": ["legerete", "vitesse", "air"],
		"effets_arme": [
			{"type": "vitesse_attaque_pourcent", "min": 4.0, "max": 14.0},
		],
		"effets_armure": [
			{"type": "vitesse_pourcent", "min": 3.0, "max": 10.0},
			{"type": "reduction_poids_armure_pourcent", "min": 5.0, "max": 15.0},
		],
		"effets_bonus": [
			{"type": "vitesse_pourcent", "min": 2.0, "max": 8.0},
		],
	},
	"croc_alpha": {
		"nom": "Croc d'alpha",
		"teinte": Color(0.85, 0.85, 0.9),
		"tags": ["sauvage", "degats", "fear"],
		"effets_arme": [
			{"type": "degats_pourcent", "min": 6.0, "max": 16.0},
			{"type": "degats_pourcent_contre_cible", "cible": "sauvage", "min": 5.0, "max": 15.0},
		],
		"effets_armure": [
			{"type": "reduction_degats_recus_pourcent_contre_cible", "cible": "sauvage", "min": 5.0, "max": 12.0},
		],
		"effets_bonus": [
			{"type": "degats_pourcent", "min": 3.0, "max": 9.0},
		],
	},
	"noyau_elementaire_feu": {
		"nom": "Noyau élémentaire de feu",
		"teinte": Color(1.0, 0.4, 0.1),
		"tags": ["feu", "elementaire"],
		"effets_arme": [
			{"type": "degats_feu_pourcent", "min": 8.0, "max": 22.0},
			{"type": "chance_brulure_pourcent", "min": 5.0, "max": 15.0},
		],
		"effets_armure": [
			{"type": "resistance_feu_pourcent", "min": 10.0, "max": 30.0},
		],
		"effets_bonus": [
			{"type": "degats_feu_pourcent", "min": 4.0, "max": 12.0},
		],
	},
	"noyau_elementaire_glace": {
		"nom": "Noyau élémentaire de glace",
		"teinte": Color(0.5, 0.75, 1.0),
		"tags": ["glace", "elementaire", "ralentissement"],
		"effets_arme": [
			{"type": "degats_glace_pourcent", "min": 8.0, "max": 22.0},
			{"type": "chance_ralentissement_pourcent", "min": 5.0, "max": 15.0},
		],
		"effets_armure": [
			{"type": "resistance_glace_pourcent", "min": 10.0, "max": 30.0},
		],
		"effets_bonus": [
			{"type": "degats_glace_pourcent", "min": 4.0, "max": 12.0},
		],
	},
	"fragment_ombre": {
		"nom": "Fragment d'ombre",
		"teinte": Color(0.2, 0.15, 0.3),
		"tags": ["ombre", "critique", "furtif"],
		"effets_arme": [
			{"type": "degats_ombre_pourcent", "min": 7.0, "max": 18.0},
			{"type": "chance_critique_pourcent", "min": 2.0, "max": 8.0},
		],
		"effets_armure": [
			{"type": "resistance_ombre_pourcent", "min": 8.0, "max": 22.0},
			{"type": "furtivite_pourcent", "min": 5.0, "max": 15.0},
		],
		"effets_bonus": [
			{"type": "furtivite_pourcent", "min": 4.0, "max": 12.0},
		],
	},
	"glande_venin": {
		"nom": "Glande à venin",
		"teinte": Color(0.4, 0.8, 0.2),
		"tags": ["poison", "dot"],
		"effets_arme": [
			{"type": "chance_poison_pourcent", "min": 8.0, "max": 25.0},
			{"type": "degats_poison_pourcent", "min": 6.0, "max": 18.0},
		],
		"effets_armure": [
			{"type": "resistance_poison_pourcent", "min": 12.0, "max": 35.0},
		],
		"effets_bonus": [
			{"type": "chance_poison_pourcent", "min": 4.0, "max": 12.0},
		],
	},
}

# Stats de base par type d'arme / armure (avant matériau & RNG)
const STATS_BASE_ARME := {
	"epee": 12.0,
	"lance": 11.0,
	"arc": 10.0,
	"hache": 15.0,
	"baton_mage": 9.0,
}

const STATS_BASE_ARMURE := {
	"casque": 4.0,
	"plastron": 10.0,
	"jambieres": 6.0,
	"bottes": 3.0,
}

# Multiplicateurs RNG de qualité
# Une forge "normale" peut sortir médiocre… ou exceptionnelle.
const PALIERS_QUALITE := [
	{"id": "mediocre", "nom": "Médiocre", "poids": 15, "mult": 0.75, "couleur_nom": "#888888"},
	{"id": "correct", "nom": "Correct", "poids": 35, "mult": 1.0, "couleur_nom": "#cccccc"},
	{"id": "bon", "nom": "Bon", "poids": 25, "mult": 1.2, "couleur_nom": "#55dd9e"},
	{"id": "excellent", "nom": "Excellent", "poids": 15, "mult": 1.45, "couleur_nom": "#4a9eff"},
	{"id": "exceptionnel", "nom": "Exceptionnel", "poids": 7, "mult": 1.8, "couleur_nom": "#b44aff"},
	{"id": "legendaire", "nom": "Légendaire", "poids": 3, "mult": 2.3, "couleur_nom": "#ffaa00"},
]


# ----------------------------------------------------------
#  API PUBLIQUE
# ----------------------------------------------------------

## Retourne les catégories disponibles
func obtenir_categories() -> Array[String]:
	return CATEGORIES.keys()


## Types de pièce pour une catégorie
func obtenir_types(categorie: String) -> Array[String]:
	if not CATEGORIES.has(categorie):
		return []
	return CATEGORIES[categorie]["types"].keys()


## Matériaux principaux disponibles (ceux dont le joueur a assez)
func obtenir_materiaux_principaux_disponibles() -> Array[Dictionary]:
	var resultat: Array[Dictionary] = []
	for id in MATERIAUX_PRINCIPAUX.keys():
		var mat: Dictionary = MATERIAUX_PRINCIPAUX[id]
		var qte_requise: int = mat.get("quantite", 1)
		var possede := 0
		if Inventaire:
			possede = Inventaire.compter_objet(mat.get("id_item", id))
		var effet_g = mat.get("effet_garanti", null)
		var desc_garanti := "Aucun"
		if effet_g != null:
			desc_garanti = str(effet_g.get("type", "?"))
		resultat.append({
			"id": id,
			"nom": mat["nom"],
			"tier": mat["tier"],
			"quantite_requise": qte_requise,
			"quantite_possedee": possede,
			"disponible": possede >= qte_requise,
			"couleur": mat["couleur"],
			"effet_garanti_desc": desc_garanti,
			"nb_effets_rng": int(mat.get("nb_effets_rng", 0)),
		})
	return resultat


## Matériaux secondaires disponibles
func obtenir_materiaux_secondaires_disponibles() -> Array[Dictionary]:
	var resultat: Array[Dictionary] = []
	for id in MATERIAUX_SECONDAIRES.keys():
		var mat: Dictionary = MATERIAUX_SECONDAIRES[id]
		var possede := 0
		if Inventaire:
			possede = Inventaire.compter_objet(id)
		resultat.append({
			"id": id,
			"nom": mat["nom"],
			"quantite_requise": 1,
			"quantite_possedee": possede,
			"disponible": possede >= 1,
			"teinte": mat["teinte"],
			"tags": mat.get("tags", []),
		})
	return resultat


## Chance de réussite brute (avant titres / compétences)
## Les titres Forgeron / Maître artisan modifient ça via le joueur.
func calculer_chance_reussite(joueur: Node, materiau_principal_id: String) -> float:
	var base := 70.0
	var tier: int = MATERIAUX_PRINCIPAUX.get(materiau_principal_id, {}).get("tier", 1)
	# Plus le tier est haut, plus c'est risqué sans maîtrise
	base -= float(tier - 1) * 8.0

	if joueur and joueur.has_method("obtenir_bonus"):
		base += joueur.obtenir_bonus("chance_forge_pourcent")

	return clampf(base, 5.0, 98.0)


## Point d'entrée principal de la forge.
## Retourne l'objet créé (Dictionary) ou {} en cas d'échec / matériaux manquants.
func forger(
	categorie: String,
	type_piece: String,
	materiau_principal_id: String,
	materiau_secondaire_id: String,
	joueur: Node = null
) -> Dictionary:
	# --- Validation ---
	if not CATEGORIES.has(categorie):
		forge_echouee.emit("Catégorie invalide.")
		return {}
	if not CATEGORIES[categorie]["types"].has(type_piece):
		forge_echouee.emit("Type de pièce invalide.")
		return {}
	if not MATERIAUX_PRINCIPAUX.has(materiau_principal_id):
		forge_echouee.emit("Matériau principal inconnu.")
		return {}
	if not MATERIAUX_SECONDAIRES.has(materiau_secondaire_id):
		forge_echouee.emit("Matériau secondaire inconnu.")
		return {}

	var mat_p: Dictionary = MATERIAUX_PRINCIPAUX[materiau_principal_id]
	var mat_s: Dictionary = MATERIAUX_SECONDAIRES[materiau_secondaire_id]
	var def_type: Dictionary = CATEGORIES[categorie]["types"][type_piece]

	# --- Vérif inventaire ---
	if Inventaire:
		var id_p: String = mat_p.get("id_item", materiau_principal_id)
		var qte_p: int = mat_p.get("quantite", 1)
		if Inventaire.compter_objet(id_p) < qte_p:
			forge_echouee.emit("Pas assez de %s." % mat_p["nom"])
			return {}
		if Inventaire.compter_objet(materiau_secondaire_id) < 1:
			forge_echouee.emit("Pas de %s." % mat_s["nom"])
			return {}

	# --- Jet de réussite ---
	var chance := calculer_chance_reussite(joueur, materiau_principal_id)
	if randf() * 100.0 > chance:
		# Échec : on consomme quand même une partie des matériaux (choix design)
		_consommer_materiaux(mat_p, materiau_secondaire_id, true)
		if Titres:
			# Pas de progression "réussite" mais on pourrait tracker les échecs plus tard
			pass
		forge_echouee.emit("La forge a échoué… (%d%% de chance)" % int(chance))
		return {}

	# --- Consommation matériaux ---
	_consommer_materiaux(mat_p, materiau_secondaire_id, false)

	# --- Qualité RNG ---
	var qualite := _tirer_qualite(joueur)
	var mult_qualite: float = qualite["mult"]

	# Bonus compétence qualité forge
	if joueur and joueur.has_method("obtenir_bonus"):
		mult_qualite *= (1.0 + joueur.obtenir_bonus("qualite_forge_pourcent") / 100.0)

	# --- Construction de l'objet ---
	var objet := _construire_objet(
		categorie, type_piece, def_type,
		materiau_principal_id, mat_p,
		materiau_secondaire_id, mat_s,
		qualite, mult_qualite
	)

	# --- Ajout inventaire ---
	if Inventaire:
		Inventaire.ajouter_objet(objet, 1)

	# --- Progression titres ---
	if Titres:
		Titres.incrementer_progression("forger_reussite")
		# Qualité max éventuelle
		if qualite["id"] in ["exceptionnel", "legendaire"]:
			Titres.incrementer_progression("craft_qualite_max")

	forge_reussie.emit(objet)
	return objet


# ----------------------------------------------------------
#  INTERNE
# ----------------------------------------------------------
func _consommer_materiaux(mat_p: Dictionary, id_secondaire: String, echec: bool) -> void:
	if not Inventaire:
		return
	var id_p: String = mat_p.get("id_item", "")
	var qte: int = mat_p.get("quantite", 1)
	if echec:
		# En cas d'échec : moitié du principal (arrondi sup), secondaire perdu
		qte = maxi(1, ceili(float(qte) / 2.0))
	Inventaire.retirer_par_id(id_p, qte)
	Inventaire.retirer_par_id(id_secondaire, 1)


func _tirer_qualite(joueur: Node) -> Dictionary:
	var poids_total := 0
	var table: Array = []
	for p in PALIERS_QUALITE:
		var w: int = p["poids"]
		# Les titres / compétences peuvent légèrement biaiser vers le haut
		if joueur and joueur.has_method("obtenir_bonus"):
			var bias: float = joueur.obtenir_bonus("chance_forge_pourcent") * 0.15
			if p["mult"] >= 1.2:
				w = int(w * (1.0 + bias / 100.0))
		table.append({"def": p, "w": w})
		poids_total += w

	var jet := randi() % maxi(poids_total, 1)
	var cumul := 0
	for entry in table:
		cumul += entry["w"]
		if jet < cumul:
			return entry["def"]
	return PALIERS_QUALITE[1]  # fallback "correct"


func _construire_objet(
	categorie: String,
	type_piece: String,
	def_type: Dictionary,
	id_principal: String,
	mat_p: Dictionary,
	id_secondaire: String,
	mat_s: Dictionary,
	qualite: Dictionary,
	mult_qualite: float
) -> Dictionary:
	var nom_piece: String = def_type["nom"]
	var nom_mat: String = mat_p["nom"]
	var nom_qualite: String = qualite["nom"]

	# Nom : "Épée de Fer [Sang] — Excellent"
	var suffixe_sec: String = mat_s["nom"].split(" ")[0]  # court
	var nom := "%s de %s (%s) — %s" % [nom_piece, nom_mat, suffixe_sec, nom_qualite]

	# Couleur finale = lerp matériau principal ↔ teinte secondaire
	var couleur: Color = mat_p["couleur"].lerp(mat_s["teinte"], 0.45)

	var objet := {
		"id": "forge_%s_%s_%s_%d" % [type_piece, id_principal, id_secondaire, randi() % 100000],
		"nom": nom,
		"type": categorie,
		"type_equipement": _resoudre_slot(def_type.get("slot", "")),
		"categorie_forge": categorie,
		"type_piece": type_piece,
		"materiau_principal": id_principal,
		"materiau_secondaire": id_secondaire,
		"qualite": qualite["id"],
		"qualite_nom": nom_qualite,
		"tier": mat_p["tier"],
		"couleur": couleur,
		"max_stack": 1,
		"effets": [],
		"description": "",
	}

	# --- Stat principale ---
	var mult_mat: float = mat_p.get("mult_stat", 1.0)
	var stat_base := 0.0
	match categorie:
		"arme":
			stat_base = STATS_BASE_ARME.get(type_piece, 10.0)
			var degats := stat_base * mult_mat * mult_qualite
			# Petite variance RNG supplémentaire (±8 %)
			degats *= randf_range(0.92, 1.08)
			objet["degats"] = snappedf(degats, 0.1)
			if type_piece == "baton_mage":
				objet["degats_magiques"] = objet["degats"]
				objet["degats"] = snappedf(objet["degats"] * 0.4, 0.1)
		"armure":
			stat_base = STATS_BASE_ARMURE.get(type_piece, 5.0)
			var defense := stat_base * mult_mat * mult_qualite
			defense *= randf_range(0.92, 1.08)
			objet["defense"] = snappedf(defense, 0.1)
		"bonus":
			# Les bonus n'ont pas de grosse stat plate : tout passe par les effets
			pass

	# =====================================================
	#  EFFETS : 1) garanti minerai  2) secondaire  3) RNG minerai
	# =====================================================
	var effets_choisis: Array = []
	var amplif_secondaire: float = 1.0  # Cristal augmente les effets du secondaire

	# --- 1. Effet garanti du minerai principal ---
	var effet_garanti = mat_p.get("effet_garanti", null)
	if effet_garanti != null:
		var resolus := _resoudre_effet_garanti(effet_garanti, categorie, mult_qualite)
		for e in resolus:
			if e.get("type", "") == "amplification_secondaire":
				amplif_secondaire = e.get("valeur", 1.25)
			else:
				effets_choisis.append(e)

	# --- 2. Effets du matériau secondaire (direction + teinte) ---
	var pool_key := "effets_arme"
	match categorie:
		"armure":
			pool_key = "effets_armure"
		"bonus":
			pool_key = "effets_bonus"

	var pool_sec: Array = mat_s.get(pool_key, [])
	var nb_sec := 1
	if qualite["mult"] >= 1.45 and pool_sec.size() >= 2:
		nb_sec = 2
	if qualite["mult"] >= 2.0:
		nb_sec = mini(2, pool_sec.size())

	var pool_sec_mix := pool_sec.duplicate()
	pool_sec_mix.shuffle()
	for i in range(mini(nb_sec, pool_sec_mix.size())):
		var modele: Dictionary = pool_sec_mix[i]
		var valeur: float = randf_range(modele.get("min", 1.0), modele.get("max", 5.0))
		valeur *= mult_qualite * 0.85 * amplif_secondaire
		valeur = snappedf(valeur, 0.1)
		var effet := {"type": modele["type"], "valeur": valeur}
		if modele.has("cible"):
			effet["cible"] = modele["cible"]
		effets_choisis.append(effet)

	# --- 3. Effets RNG supplémentaires selon le minerai (nb_effets_rng) ---
	var nb_rng: int = int(mat_p.get("nb_effets_rng", 0))
	if nb_rng > 0:
		var types_deja: Array[String] = []
		for e in effets_choisis:
			types_deja.append(e.get("type", ""))
		for _i in range(nb_rng):
			var modele := _tirer_effet_rng(categorie, types_deja)
			if modele.is_empty():
				break
			var effet_resolu := _resoudre_effet_rng(modele, mult_qualite)
			effets_choisis.append(effet_resolu)
			# Enregistre type résolu + éventuelle clé modèle pour éviter doublons
			types_deja.append(effet_resolu.get("type", ""))
			if modele.has("cible"):
				types_deja.append("%s:%s" % [modele["type"], modele["cible"]])
			if modele.get("element_aleatoire", false):
				types_deja.append(modele["type"])  # bloque un 2e élément aléatoire

	objet["effets"] = effets_choisis
	if amplif_secondaire > 1.0:
		objet["amplification_secondaire"] = amplif_secondaire

	# Description lisible
	var lignes: PackedStringArray = []
	lignes.append("%s · %s" % [nom_qualite, nom_mat])
	if objet.has("degats"):
		lignes.append("Dégâts : %.1f" % objet["degats"])
	if objet.has("degats_magiques"):
		lignes.append("Dégâts magiques : %.1f" % objet["degats_magiques"])
	if objet.has("defense"):
		lignes.append("Défense : %.1f" % objet["defense"])
	if amplif_secondaire > 1.0:
		lignes.append("Amplification secondaire : ×%.2f" % amplif_secondaire)
	for e in effets_choisis:
		var txt := _format_effet(e)
		if txt != "":
			lignes.append(txt)
	objet["description"] = "\n".join(lignes)

	return objet


## Résout les effets garantis spéciaux (diamant, obsidienne, cristal, orichalque…)
func _resoudre_effet_garanti(modele: Dictionary, categorie: String, mult_qualite: float) -> Array:
	var resultat: Array = []
	var type_g: String = modele.get("type", "")
	var vmin: float = modele.get("min", 1.0)
	var vmax: float = modele.get("max", 5.0)
	var valeur: float = randf_range(vmin, vmax) * mult_qualite * 0.9
	valeur = snappedf(valeur, 0.1)

	match type_g:
		"resistance_orientee", "resistance_elementaire":
			# Tire un élément au hasard
			var elements := ["feu", "glace", "poison", "ombre", "foudre"]
			var elem: String = elements[randi() % elements.size()]
			resultat.append({
				"type": "resistance_%s_pourcent" % elem,
				"valeur": valeur,
			})
		"amplification_secondaire":
			# Pas un effet affiché sur le joueur : multiplicateur interne
			resultat.append({
				"type": "amplification_secondaire",
				"valeur": snappedf(randf_range(vmin, vmax), 0.01),
			})
		"bonus_polyvalent":
			# Petit bonus dégâts + défense
			resultat.append({"type": "degats_pourcent", "valeur": valeur})
			resultat.append({"type": "defense_pourcent", "valeur": snappedf(valeur * 0.8, 0.1)})
		"degats_pourcent_contre_cible":
			var effet := {
				"type": "degats_pourcent_contre_cible",
				"cible": modele.get("cible", ""),
				"valeur": valeur,
			}
			resultat.append(effet)
		_:
			var effet := {"type": type_g, "valeur": valeur}
			if modele.has("cible"):
				effet["cible"] = modele["cible"]
			resultat.append(effet)

	return resultat


func _resoudre_slot(slot: String) -> String:
	if slot == "anneau":
		return "anneau"
	return slot


## Construit la pool pondérée selon la catégorie d'équipement
func _pool_rng_pour_categorie(categorie: String) -> Array:
	var pool: Array = []
	match categorie:
		"arme":
			pool.append_array(POOL_RNG_OFFENSIF)
			pool.append_array(POOL_RNG_CIBLE)
			pool.append_array(POOL_RNG_SPECIAL)
			# Un peu de regen offensive
			for e in POOL_RNG_REGEN:
				if e["type"] in ["recuperation_pv_sur_attaque", "recuperation_pm_sur_attaque", "absorption_pm_pourcent"]:
					pool.append(e)
		"armure":
			pool.append_array(POOL_RNG_DEFENSIF)
			pool.append_array(POOL_RNG_REGEN)
			pool.append_array(POOL_RNG_SPECIAL)
		"bonus":
			pool.append_array(POOL_RNG_OFFENSIF)
			pool.append_array(POOL_RNG_DEFENSIF)
			pool.append_array(POOL_RNG_REGEN)
			pool.append_array(POOL_RNG_SPECIAL)
			pool.append_array(POOL_RNG_CIBLE)
		_:
			pool.append_array(POOL_RNG_OFFENSIF)
			pool.append_array(POOL_RNG_DEFENSIF)
	return pool


## Tire un modèle d'effet RNG (avec chance rare + poids)
func _tirer_effet_rng(categorie: String, types_deja: Array[String]) -> Dictionary:
	# Chance de tirer dans la pool rare
	if randf() < CHANCE_EFFET_RARE:
		var rares_dispo: Array = []
		for e in POOL_RNG_RARE:
			var cle := e["type"]
			if cle not in types_deja:
				rares_dispo.append(e)
		if rares_dispo.size() > 0:
			return _tirer_pondere(rares_dispo)

	var pool := _pool_rng_pour_categorie(categorie)
	var dispo: Array = []
	for e in pool:
		# Clé unique : type ou type:cible pour les bonus spécialisés
		var cle: String = e["type"]
		if e.has("cible"):
			cle = "%s:%s" % [e["type"], e["cible"]]
		# Les éléments se distinguent après résolution — on autorise un seul "degats_elementaires"
		if cle in types_deja:
			continue
		if e.get("element_aleatoire", false) and e["type"] in types_deja:
			continue
		# Même type sans cible = doublon (sauf contre_cible déjà géré)
		if not e.has("cible") and e["type"] in types_deja:
			continue
		dispo.append(e)

	if dispo.is_empty():
		return {}
	return _tirer_pondere(dispo)


func _tirer_pondere(pool: Array) -> Dictionary:
	var total := 0
	for e in pool:
		total += int(e.get("poids", 1))
	if total <= 0:
		return pool[randi() % pool.size()]
	var jet := randi() % total
	var cumul := 0
	for e in pool:
		cumul += int(e.get("poids", 1))
		if jet < cumul:
			return e
	return pool[pool.size() - 1]


## Résout un modèle en effet concret (élément aléatoire, valeur, etc.)
func _resoudre_effet_rng(modele: Dictionary, mult_qualite: float) -> Dictionary:
	var valeur: float = randf_range(modele.get("min", 1.0), modele.get("max", 5.0))
	valeur *= mult_qualite * 0.8
	valeur = snappedf(valeur, 0.1)

	var type_final: String = modele["type"]
	var effet := {"type": type_final, "valeur": valeur}

	# Élément aléatoire pour dégâts ou résistance
	if modele.get("element_aleatoire", false):
		var elem: String = ELEMENTS_DEGATS[randi() % ELEMENTS_DEGATS.size()]
		if type_final == "degats_elementaires":
			effet["type"] = "degats_%s_pourcent" % elem
		elif type_final == "resistance_element_aleatoire":
			effet["type"] = "resistance_%s_pourcent" % elem
		effet["element"] = elem

	if modele.has("cible"):
		effet["cible"] = modele["cible"]

	# Flags purement comportementaux (valeur symbolique)
	if type_final in ["dernier_souffle", "second_souffle", "affinite_categorie"]:
		effet["valeur"] = 1.0
		effet["comportemental"] = true

	return effet


func _format_effet(effet: Dictionary) -> String:
	var t: String = effet.get("type", "")
	var v: float = effet.get("valeur", 0.0)
	var cible: String = effet.get("cible", "")
	var elem: String = effet.get("element", "")

	match t:
		"degats_pourcent":
			return "+%.1f %% dégâts" % v
		"tranchant_pourcent":
			return "+%.1f %% dégâts tranchants" % v
		"perforation_pourcent":
			return "+%.1f %% perforation" % v
		"brutalite_pourcent":
			return "+%.1f %% brutalité (vs PV hauts)" % v
		"execution_pourcent":
			return "+%.1f %% exécution (vs PV bas)" % v
		"degats_critique_pourcent":
			return "+%.1f %% dégâts critiques" % v
		"chance_critique_pourcent":
			return "+%.1f %% chance critique" % v
		"vitesse_attaque_pourcent":
			return "+%.1f %% vitesse d'attaque" % v
		"vol_de_vie_pourcent":
			return "+%.1f %% vol de vie" % v
		"absorption_pm_pourcent":
			return "+%.1f %% absorption de PM" % v
		"degats_feu_pourcent":
			return "+%.1f %% dégâts de feu" % v
		"degats_glace_pourcent":
			return "+%.1f %% dégâts de glace" % v
		"degats_electricite_pourcent":
			return "+%.1f %% dégâts électriques" % v
		"degats_lumiere_pourcent":
			return "+%.1f %% dégâts de lumière" % v
		"degats_tenebres_pourcent":
			return "+%.1f %% dégâts de ténèbres" % v
		"degats_metal_pourcent":
			return "+%.1f %% dégâts métalliques" % v
		"degats_ombre_pourcent":
			return "+%.1f %% dégâts d'ombre" % v
		"pv_max_pourcent":
			return "+%.1f %% PV max" % v
		"resistance_pourcent", "defense_pourcent":
			return "+%.1f %% résistance" % v
		"resistance_physique_pourcent":
			return "+%.1f %% rés. physique" % v
		"resistance_magique_pourcent":
			return "+%.1f %% rés. magique" % v
		"resistance_elementaire_pourcent":
			return "+%.1f %% rés. élémentaire" % v
		"resistance_feu_pourcent":
			return "+%.1f %% rés. feu" % v
		"resistance_glace_pourcent":
			return "+%.1f %% rés. glace" % v
		"resistance_electricite_pourcent":
			return "+%.1f %% rés. électrique" % v
		"resistance_lumiere_pourcent":
			return "+%.1f %% rés. lumière" % v
		"resistance_tenebres_pourcent":
			return "+%.1f %% rés. ténèbres" % v
		"resistance_metal_pourcent":
			return "+%.1f %% rés. métal" % v
		"reduction_degats_recus_pourcent":
			return "-%.1f %% dégâts reçus" % v
		"reduction_degats_critiques_recus_pourcent":
			return "-%.1f %% dégâts critiques reçus" % v
		"regeneration_pv_restants_par_seconde":
			return "Régén. %.1f %% PV restants / s" % v
		"regeneration_pm_pourcent":
			return "+%.1f %% régén. PM" % v
		"regeneration_apres_degat_pourcent":
			return "+%.1f %% régén. après dégât" % v
		"recuperation_pv_sur_attaque":
			return "+%.1f PV récupérés par attaque" % v
		"recuperation_pm_sur_attaque":
			return "+%.1f PM récupérés par attaque" % v
		"reduction_cout_pm_pourcent":
			return "-%.1f %% coût en PM" % v
		"vitesse_pourcent":
			return "+%.1f %% vitesse" % v
		"resistance_effets_negatifs_pourcent":
			return "+%.1f %% rés. effets négatifs" % v
		"resistance_alterations_elementaires_pourcent":
			return "+%.1f %% rés. altérations élémentaires" % v
		"durabilite_pourcent":
			return "+%.1f %% durabilité" % v
		"puissance_forge_secondaire_pourcent":
			return "+%.1f %% puissance du secondaire" % v
		"degats_pourcent_contre_cible":
			return "+%.1f %% dégâts vs %s" % [v, cible]
		"dernier_souffle":
			return "Dernier souffle (bonus à PV bas)"
		"second_souffle":
			return "Second souffle (récup. après PV critiques)"
		"reflexion_degats_pourcent":
			return "+%.1f %% réflexion des dégâts" % v
		"double_impact_chance":
			return "+%.1f %% chance de double impact" % v
		"drain_pourcent":
			return "+%.1f %% drain (vie + PM)" % v
		"amplification_effets_pourcent":
			return "+%.1f %% amplification des autres effets" % v
		"affinite_categorie":
			return "Affinité (biaise les prochains RNG)"
		_:
			if elem != "":
				return "+%.1f %% %s (%s)" % [v, t.replace("_", " "), elem]
			return "+%.1f %% %s" % [v, t.replace("_", " ")]
