extends Node

# ==========================================================
#  OBSIDIAN HORIZON — Autoload Bestiaire
#  Persistant et GLOBAL, VOLONTAIREMENT séparé de Sauvegarde (slots) :
#  le bestiaire est une progression de méta-jeu (comme un codex), pas liée
#  à un personnage précis. Il survit à la mort ET à la suppression d'une
#  sauvegarde — un seul fichier, pas un par slot.
# ==========================================================

signal entree_decouverte(id_mob: String)
signal bestiaire_modifie(id_mob: String)

const CHEMIN_FICHIER: String = "user://bestiaire.json"

## id_mob -> {"decouvert": bool, "kills": int}
## Autres infos (environnement, résistances...) à ajouter ici plus tard
## quand le catalogue de créatures sera écrit quelque part (voir note en
## bas de fichier sur obtenir_pour_affichage()).
var entrees: Dictionary = {}


func _ready() -> void:
	charger()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		sauvegarder()  # filet de sécurité, en plus de la sauvegarde à chaque découverte/kill


# ----------------------------------------------------------
#  PROGRESSION
# ----------------------------------------------------------
## À appeler dès qu'un monstre est rencontré (pas forcément tué) — ex.
## depuis Ennemi.gd au premier contact visuel, ou simplement au premier kill.
func decouvrir(id_mob: String) -> void:
	if est_decouvert(id_mob):
		return

	if not entrees.has(id_mob):
		entrees[id_mob] = {"decouvert": true, "kills": 0}
	else:
		entrees[id_mob]["decouvert"] = true

	entree_decouverte.emit(id_mob)
	bestiaire_modifie.emit(id_mob)

	# Titre Observateur : "compléter une série importante d'entrées du bestiaire"
	if Titres:
		Titres.incrementer_progression("bestiaire_entree")

	sauvegarder()


## À appeler par le combat à chaque monstre tué (en plus de
## Titres.incrementer_progression("tuer", ...) qui reste séparé).
func enregistrer_kill(id_mob: String) -> void:
	decouvrir(id_mob)  # tuer un mob le découvre forcément au passage
	entrees[id_mob]["kills"] = entrees[id_mob].get("kills", 0) + 1
	bestiaire_modifie.emit(id_mob)
	sauvegarder()


func est_decouvert(id_mob: String) -> bool:
	return entrees.has(id_mob) and entrees[id_mob].get("decouvert", false)


func obtenir_kills(id_mob: String) -> int:
	return entrees.get(id_mob, {}).get("kills", 0)


# ----------------------------------------------------------
#  AFFICHAGE (respecte le secret des créatures jamais rencontrées)
# ----------------------------------------------------------
## catalogue_mobs : dictionnaire id_mob -> {"nom": ..., ...} listant TOUTES
## les créatures du jeu (découvertes ou non). Ce catalogue n'existe pas
## encore ailleurs dans le projet — à écrire quand l'UI Bestiaire sera
## construite (même principe que Titres.catalogue_titres). En attendant,
## Bestiaire ne connaît que ce qui a déjà été rencontré.
func obtenir_pour_affichage(catalogue_mobs: Dictionary) -> Array[Dictionary]:
	var resultat: Array[Dictionary] = []
	for id_mob in catalogue_mobs.keys():
		if est_decouvert(id_mob):
			var def: Dictionary = catalogue_mobs[id_mob]
			resultat.append({
				"id": id_mob,
				"nom": def.get("nom", id_mob),
				"decouvert": true,
				"kills": obtenir_kills(id_mob),
			})
		else:
			resultat.append({"id": id_mob, "nom": "???", "decouvert": false, "kills": 0})
	return resultat


# ----------------------------------------------------------
#  PERSISTANCE — fichier dédié, indépendant des slots de Sauvegarde
# ----------------------------------------------------------
func sauvegarder() -> void:
	var f := FileAccess.open(CHEMIN_FICHIER, FileAccess.WRITE)
	if f == null:
		push_warning("Bestiaire : impossible d'écrire '%s'." % CHEMIN_FICHIER)
		return
	f.store_string(JSON.stringify(entrees))
	f.close()


func charger() -> void:
	if not FileAccess.file_exists(CHEMIN_FICHIER):
		return
	var f := FileAccess.open(CHEMIN_FICHIER, FileAccess.READ)
	if f == null:
		return
	var texte := f.get_as_text()
	f.close()
	var parsed = JSON.parse_string(texte)
	if parsed is Dictionary:
		entrees = parsed
