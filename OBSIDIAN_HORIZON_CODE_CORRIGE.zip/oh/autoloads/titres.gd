extends Node

# ==========================================================
#  OBSIDIAN HORIZON — Gestionnaire des Titres
#  À déclarer en Autoload (Project Settings > Autoload) sous
#  le nom "Titres".
#
#  Principes :
#  - Un titre non débloqué est un succès caché : nom, description et
#    condition ne sont jamais exposés côté UI (voir obtenir_titres_pour_affichage).
#  - Les titres sont PERMANENTS : jamais retirés, y compris à la mort.
#  - 3 types de conditions, pour couvrir toute la fiche de conception sans
#    connaître à l'avance le détail de chaque système du jeu (combat,
#    craft, exploration...) :
#      "compteur" : une action se répète N fois (ex: 100 kills de loup).
#                   -> incrementer_progression(action, cible, contexte)
#      "seuil"    : une valeur ACTUELLE dépasse un seuil à un instant T
#                   (ex: posséder 100 000 or simultanément), pas cumulatif.
#                   -> verifier_seuil(action, valeur_actuelle)
#      "manuel"   : condition trop spécifique/évènementielle pour un suivi
#                   générique (ex: "terminer les 100 étages sans dégât").
#                   -> le système concerné appelle debloquer_titre(id)
#                   lui-même au moment où IL constate que c'est rempli.
# ==========================================================

signal titre_debloque(id_titre: String)

## Catalogue complet, y compris les titres non débloqués. Jamais exposé
## tel quel à l'UI.
var catalogue_titres: Dictionary = {}

## Ids des titres débloqués, dans l'ordre d'obtention. Permanent : à
## sauvegarder tel quel, jamais vidé (y compris à la mort).
var titres_debloques: Array[String] = []

## Progression des conditions de type "compteur", clé = id du titre
## (et non l'action seule, car deux titres peuvent suivre la même action
## avec des filtres différents, ex: "sans magie").
var progression_titres: Dictionary = {}


func _ready() -> void:
	_enregistrer_titres()


func _ajouter_titre(definition: Dictionary) -> void:
	catalogue_titres[definition["id"]] = definition


# ----------------------------------------------------------
#  SUIVI DE PROGRESSION — TYPE "compteur"
# ----------------------------------------------------------
## Point d'entrée générique à appeler depuis N'IMPORTE QUEL système quand
## une action pertinente se produit, ex :
##   Titres.incrementer_progression("tuer", "loup", ["etre_vivant", "sauvage"])
##   Titres.incrementer_progression("miner")
##   Titres.incrementer_progression("forger_reussite")
##   Titres.incrementer_progression("vaincre", "ennemi", [], {"sans_magie": true})
##
## - action    : le type d'évènement (voir la liste des "action" utilisées
##               dans _enregistrer_titres ci-dessous).
## - cible     : id précis concerné (ex: id du mob), optionnel.
## - categories: tags applicables à cet évènement (ex: ["monstre","boss"]),
##               pour les conditions qui visent une catégorie plutôt qu'un
##               id précis.
## - contexte  : infos additionnelles utilisées par les conditions qui ont
##               un filtre (ex: {"sans_magie": true}, {"seul": true},
##               {"element": "feu"}).
func incrementer_progression(action: String, cible: String = "", categories: Array = [], contexte: Dictionary = {}, quantite: int = 1) -> void:
	for id_titre in catalogue_titres.keys():
		if id_titre in titres_debloques:
			continue

		var definition: Dictionary = catalogue_titres[id_titre]
		var condition: Dictionary = definition.get("condition", {})

		if condition.get("type", "") != "compteur":
			continue
		if condition.get("action", "") != action:
			continue

		var cible_condition: String = condition.get("cible", "")
		if cible_condition != "" and cible_condition != cible and not (cible_condition in categories):
			continue

		var contexte_requis: Dictionary = condition.get("contexte_requis", {})
		var contexte_ok := true
		for cle in contexte_requis.keys():
			if contexte.get(cle) != contexte_requis[cle]:
				contexte_ok = false
				break
		if not contexte_ok:
			continue

		progression_titres[id_titre] = progression_titres.get(id_titre, 0) + quantite
		if progression_titres[id_titre] >= condition.get("quantite", 0):
			debloquer_titre(id_titre)


## Compteur actuel d'un titre de type "compteur" (utile pour un affichage
## "87 / 100" dans l'onglet Titre une fois le titre découvert).
func obtenir_progression(id_titre: String) -> int:
	return progression_titres.get(id_titre, 0)


# ----------------------------------------------------------
#  SUIVI — TYPE "seuil"
# ----------------------------------------------------------
## À appeler quand une valeur qui peut monter ET descendre change (ex: or
## possédé), pour les titres du type "Posséder simultanément X" :
##   Titres.verifier_seuil("or_possede", Inventaire.or_actuel)
func verifier_seuil(action: String, valeur_actuelle: float) -> void:
	for id_titre in catalogue_titres.keys():
		if id_titre in titres_debloques:
			continue
		var definition: Dictionary = catalogue_titres[id_titre]
		var condition: Dictionary = definition.get("condition", {})
		if condition.get("type", "") == "seuil" and condition.get("action", "") == action:
			if valeur_actuelle >= condition.get("quantite", 0):
				debloquer_titre(id_titre)


# ----------------------------------------------------------
#  DÉBLOCAGE
# ----------------------------------------------------------
## Débloque définitivement un titre et applique ses effets au joueur.
## C'est aussi le point d'entrée pour tous les titres "manuel" : le
## système qui constate la condition remplie appelle directement
## Titres.debloquer_titre("pacifiste") par exemple.
func debloquer_titre(id_titre: String) -> void:
	if id_titre in titres_debloques or not catalogue_titres.has(id_titre):
		return

	titres_debloques.append(id_titre)
	var definition: Dictionary = catalogue_titres[id_titre]

	var joueur := get_tree().get_first_node_in_group("joueur")
	if joueur != null:
		joueur.debloquer_titre(definition)
	else:
		push_warning("Titre '%s' débloqué mais aucun joueur trouvé (groupe 'joueur') pour appliquer ses effets." % id_titre)

	titre_debloque.emit(id_titre)


func est_debloque(id_titre: String) -> bool:
	return id_titre in titres_debloques


# ----------------------------------------------------------
#  AFFICHAGE (respecte le secret des titres non débloqués)
# ----------------------------------------------------------
func obtenir_titres_pour_affichage() -> Array[Dictionary]:
	var resultat: Array[Dictionary] = []

	for id_titre in catalogue_titres.keys():
		var est_deb: bool = id_titre in titres_debloques

		if est_deb:
			var definition: Dictionary = catalogue_titres[id_titre]
			resultat.append({
				"id": id_titre,
				"nom": definition["nom"],
				"description": definition["description"],
				"debloque": true,
			})
		else:
			resultat.append({
				"id": id_titre,
				"nom": "???",
				"description": "Titre non découvert.",
				"debloque": false,
			})

	return resultat


# ----------------------------------------------------------
#  CATALOGUE
# ----------------------------------------------------------
## IMPORTANT — titres marqués condition.type == "manuel" : aucun suivi
## automatique n'est possible sans connaître le détail des systèmes
## concernés (combat, cycle jour/nuit, streaks, etc.). Le bon endroit pour
## appeler Titres.debloquer_titre(id) est noté dans chaque description.
func _enregistrer_titres() -> void:
	_ajouter_titre({
		"id": "tueur_de_loups",
		"nom": "Tueur de Loups",
		"description": "Tuer 100 Loups.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "loup", "quantite": 100},
		"effets": [
			{"type": "degats_pourcent_contre_cible", "cible": "loup", "valeur": 5.0},
		],
	})

	_ajouter_titre({
		"id": "pacifiste",
		"nom": "Pacifiste",
		"description": "Terminer les 100 étages sans infliger de dégâts ni tuer. Aucun bonus direct : débloque certaines interactions pacifistes.",
		"condition": {"type": "manuel"},  # à appeler depuis le script de fin de Tour si le run entier est sans dégât/kill
		"effets": [{"type": "comportemental"}],
	})

	_ajouter_titre({
		"id": "monstre",
		"nom": "Monstre",
		"description": "Éliminer 1000 créatures vivantes. +20% dégâts contre les êtres vivants.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "etre_vivant", "quantite": 1000},
		"effets": [{"type": "degats_pourcent_contre_cible", "cible": "etre_vivant", "valeur": 20.0}],
	})

	_ajouter_titre({
		"id": "tueur_de_monstres",
		"nom": "Tueur de Monstres",
		"description": "Éliminer 100 monstres. +5% dégâts contre les monstres.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "monstre", "quantite": 100},
		"effets": [{"type": "degats_pourcent_contre_cible", "cible": "monstre", "valeur": 5.0}],
	})

	_ajouter_titre({
		"id": "boucher",
		"nom": "Boucher",
		"description": "Éliminer 500 créatures sans utiliser de magie. +15% dégâts contre les ennemis ayant plus de 50% de leurs PV.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "etre_vivant", "quantite": 500, "contexte_requis": {"sans_magie": true}},
		# "degats_pourcent_contre_pv_haut" est conditionnel (PV cible > 50%) : à consulter via
		# Player.obtenir_bonus("degats_pourcent_contre_pv_haut") depuis le calcul de dégâts du combat.
		"effets": [{"type": "degats_pourcent_contre_pv_haut", "valeur": 15.0}],
	})

	_ajouter_titre({
		"id": "massacreur",
		"nom": "Massacreur",
		"description": "Réaliser une série de 100 éliminations. +1% dégâts par ennemi tué consécutivement (max +20%), remis à zéro en quittant la zone.",
		# Streak avec reset : nécessite un compteur dédié côté combat (pas
		# un simple cumul) -> le système de combat gère lui-même le streak
		# et appelle Titres.debloquer_titre("massacreur") en atteignant 100,
		# puis applique son propre bonus progressif (indépendant de ce système).
		"condition": {"type": "manuel"},
		"effets": [{"type": "comportemental"}],  # le bonus de streak est géré en direct par le combat, pas par bonus_generique
	})

	_ajouter_titre({
		"id": "ennemi_naturel_des_dieux",
		"nom": "Ennemi Naturel des Dieux",
		"description": "Vaincre une entité divine cachée sans utiliser de compétence divine. +50% dégâts contre les entités divines et -20% dégâts reçus de celles-ci.",
		"condition": {"type": "manuel"},  # combat de boss caché spécifique -> debloquer_titre() appelé par ce combat
		"effets": [
			{"type": "degats_pourcent_contre_cible", "cible": "divin", "valeur": 50.0},
			{"type": "reduction_degats_recus_pourcent_contre_cible", "cible": "divin", "valeur": 20.0},
		],
	})

	_ajouter_titre({
		"id": "duelliste",
		"nom": "Duelliste",
		"description": "Vaincre 100 ennemis sans qu'aucun autre ennemi ne participe au combat. +15% dégâts en combat 1 contre 1.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "ennemi", "quantite": 100, "contexte_requis": {"seul": true}},
		"effets": [{"type": "degats_pourcent_duel", "valeur": 15.0}],  # conditionnel : à appliquer par le combat seulement si 1v1
	})

	_ajouter_titre({
		"id": "dernier_survivant",
		"nom": "Dernier Survivant",
		"description": "Survivre à 10 combats de groupe où tous les alliés sont tombés. +20% défense quand il ne reste qu'un seul membre vivant dans le groupe.",
		"condition": {"type": "compteur", "action": "survivre_combat_groupe", "quantite": 10, "contexte_requis": {"seul_survivant": true}},
		"effets": [{"type": "defense_pourcent_dernier_survivant", "valeur": 20.0}],
	})

	_ajouter_titre({
		"id": "chasseur",
		"nom": "Chasseur",
		"description": "Chasser 250 créatures sauvages. +10% dégâts contre les créatures sauvages.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "sauvage", "quantite": 250},
		"effets": [{"type": "degats_pourcent_contre_cible", "cible": "sauvage", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "mage",
		"nom": "Mage",
		"description": "Utiliser de la magie pour vaincre 500 ennemis. +10% dégâts magiques.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "ennemi", "quantite": 500, "contexte_requis": {"avec_magie": true}},
		"effets": [{"type": "degats_magiques_pourcent", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "pyromancien",
		"nom": "Pyromancien",
		"description": "Vaincre 100 ennemis uniquement avec des dégâts de feu. +15% dégâts de feu.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "ennemi", "quantite": 100, "contexte_requis": {"element": "feu"}},
		"effets": [{"type": "degats_feu_pourcent", "valeur": 15.0}],
	})

	_ajouter_titre({
		"id": "cryomancien",
		"nom": "Cryomancien",
		"description": "Appliquer un effet de froid 500 fois. Les effets de ralentissement appliqués par le joueur durent +25%.",
		"condition": {"type": "compteur", "action": "appliquer_effet_froid", "quantite": 500},
		"effets": [{"type": "duree_ralentissement_pourcent", "valeur": 25.0}],
	})

	_ajouter_titre({
		"id": "forgeron",
		"nom": "Forgeron",
		"description": "Réussir 100 créations à la forge. +5% chance de réussite à la forge.",
		"condition": {"type": "compteur", "action": "forger_reussite", "quantite": 100},
		"effets": [{"type": "chance_forge_pourcent", "valeur": 5.0}],
	})

	_ajouter_titre({
		"id": "maitre_artisan",
		"nom": "Maître artisan",
		"description": "Fabriquer 50 objets de qualité maximale. +10% chance de réussite à la forge et au craft avancé.",
		"condition": {"type": "compteur", "action": "craft_qualite_max", "quantite": 50},
		"effets": [
			{"type": "chance_forge_pourcent", "valeur": 10.0},
			{"type": "chance_craft_avance_pourcent", "valeur": 10.0},
		],
	})

	_ajouter_titre({
		"id": "marchand",
		"nom": "Marchand",
		"description": "Acheter et vendre pour une valeur totale de 100 000 pièces. Prix d'achat -5%, prix de vente +5%.",
		"condition": {"type": "compteur", "action": "valeur_commerce", "quantite": 100000},
		"effets": [
			{"type": "prix_achat_pourcent", "valeur": -5.0},
			{"type": "prix_vente_pourcent", "valeur": 5.0},
		],
	})

	_ajouter_titre({
		"id": "millionnaire",
		"nom": "Millionnaire",
		"description": "Posséder simultanément une importante somme d'or. +5% d'or obtenu.",
		"condition": {"type": "seuil", "action": "or_possede", "quantite": 100000},  # seuil à ajuster selon l'équilibrage
		"effets": [{"type": "or_obtenu_pourcent", "valeur": 5.0}],
	})

	_ajouter_titre({
		"id": "mineur",
		"nom": "Mineur",
		"description": "Extraire 1000 minerais. +10% de ressources obtenues lors de l'extraction de minerais.",
		"condition": {"type": "compteur", "action": "miner", "quantite": 1000},
		"effets": [{"type": "ressources_minerai_pourcent", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "bucheron",
		"nom": "Bûcheron",
		"description": "Abattre 500 arbres. +10% de bois obtenu sur les arbres.",
		"condition": {"type": "compteur", "action": "abattre_arbre", "quantite": 500},
		"effets": [{"type": "bois_obtenu_pourcent", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "explorateur",
		"nom": "Explorateur",
		"description": "Découvrir 50 lieux différents. +10% vitesse hors combat.",
		"condition": {"type": "compteur", "action": "decouvrir_lieu", "quantite": 50},
		"effets": [{"type": "vitesse_hors_combat_pourcent", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "cartographe",
		"nom": "Cartographe",
		"description": "Explorer une grande partie du monde extérieur. Les lieux secrets proches sont légèrement plus faciles à détecter.",
		"condition": {"type": "manuel"},  # % de carte explorée -> à appeler par le système de monde ouvert quand le seuil est atteint
		"effets": [{"type": "comportemental"}],
	})

	_ajouter_titre({
		"id": "architecte",
		"nom": "Architecte",
		"description": "Construire une base remplissant plusieurs critères précis. Les blocs de construction placés peuvent être récupérés plus facilement.",
		"condition": {"type": "manuel"},  # critères multiples -> à vérifier par le système de construction
		"effets": [{"type": "comportemental"}],
	})

	_ajouter_titre({
		"id": "sedentaire",
		"nom": "Sédentaire",
		"description": "Dormir dans sa propre base 50 fois. Bonus de régénération lorsque le joueur se trouve dans sa base.",
		"condition": {"type": "compteur", "action": "dormir_base", "quantite": 50},
		"effets": [{"type": "regeneration_pourcent_dans_base", "valeur": 0.0}],  # valeur à définir selon l'équilibrage
	})

	_ajouter_titre({
		"id": "vagabond",
		"nom": "Vagabond",
		"description": "Parcourir une très grande distance sans dormir. +10% vitesse tant que le joueur n'a pas dormi depuis un certain temps.",
		"condition": {"type": "manuel"},  # distance cumulée sans sommeil -> à suivre par le système de déplacement/sommeil
		"effets": [{"type": "vitesse_pourcent_sans_sommeil", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "enfant_de_la_nuit",
		"nom": "Enfant de la Nuit",
		"description": "Survivre à une nuit complète dans le monde extérieur sans dormir. +15% efficacité pendant la nuit.",
		"condition": {"type": "manuel"},  # -> appelé par le cycle jour/nuit au lever du soleil si la nuit a été passée sans dormir
		"effets": [{"type": "efficacite_nuit_pourcent", "valeur": 15.0}],
	})

	_ajouter_titre({
		"id": "enfant_du_soleil",
		"nom": "Enfant du Soleil",
		"description": "Vaincre 100 ennemis uniquement pendant la journée. +10% dégâts pendant le jour.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "ennemi", "quantite": 100, "contexte_requis": {"moment": "jour"}},
		"effets": [{"type": "degats_pourcent_jour", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "observateur",
		"nom": "Observateur",
		"description": "Compléter une série importante d'entrées du bestiaire. Les créatures déjà étudiées affichent davantage d'informations.",
		"condition": {"type": "compteur", "action": "bestiaire_entree", "quantite": 30},  # quantité à ajuster selon la taille du bestiaire
		"effets": [{"type": "comportemental"}],
	})

	_ajouter_titre({
		"id": "erudit",
		"nom": "Érudit",
		"description": "Découvrir un grand nombre de livres et secrets. +5% efficacité des compétences.",
		"condition": {"type": "compteur", "action": "decouvrir_livre_ou_secret", "quantite": 50},
		"effets": [{"type": "efficacite_competences_pourcent", "valeur": 5.0}],
	})

	_ajouter_titre({
		"id": "alchimiste",
		"nom": "Alchimiste",
		"description": "Fabriquer 100 potions différentes. Les potions fabriquées durent +15%.",
		"condition": {"type": "compteur", "action": "fabriquer_potion_differente", "quantite": 100},
		"effets": [{"type": "duree_potions_pourcent", "valeur": 15.0}],
	})

	_ajouter_titre({
		"id": "medecin_de_guerre",
		"nom": "Médecin de guerre",
		"description": "Soigner une quantité cumulée importante de PV. Les soins reçus sont +10% efficaces.",
		"condition": {"type": "compteur", "action": "soin_cumule", "quantite": 10000},  # en PV cumulés, à ajuster
		"effets": [{"type": "soins_recus_pourcent", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "survivant",
		"nom": "Survivant",
		"description": "Survivre à 50 situations où les PV passent sous 10%. +5% défense lorsque les PV sont inférieurs à 25%.",
		"condition": {"type": "compteur", "action": "survivre_pv_critique", "quantite": 50},
		"effets": [{"type": "defense_pourcent_pv_bas", "valeur": 5.0}],
	})

	_ajouter_titre({
		"id": "rescape",
		"nom": "Rescapé",
		"description": "Revenir vivant de 25 situations extrêmement dangereuses. +10% vitesse lorsque les PV sont inférieurs à 20%.",
		"condition": {"type": "compteur", "action": "survivre_situation_extreme", "quantite": 25},
		"effets": [{"type": "vitesse_pourcent_pv_bas", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "fuyard",
		"nom": "Fuyard",
		"description": "Fuir volontairement 100 combats sans mourir. +20% vitesse pendant quelques secondes après avoir quitté un combat.",
		"condition": {"type": "compteur", "action": "fuir_combat", "quantite": 100},
		"effets": [{"type": "vitesse_pourcent_apres_fuite", "valeur": 20.0}],  # temporaire : à appliquer par le combat pendant X secondes
	})

	_ajouter_titre({
		"id": "patient",
		"nom": "Patient",
		"description": "Vaincre un boss sans se déplacer pendant certaines phases du combat. +10% défense tant que le joueur reste immobile.",
		"condition": {"type": "manuel"},  # -> appelé par le combat de boss concerné
		"effets": [{"type": "defense_pourcent_immobile", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "poing_dacier",
		"nom": "Poing d'acier",
		"description": "Vaincre 100 ennemis uniquement à mains nues. +25% dégâts des attaques sans arme.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "ennemi", "quantite": 100, "contexte_requis": {"arme": "aucune"}},
		"effets": [{"type": "degats_pourcent_sans_arme", "valeur": 25.0}],
	})

	_ajouter_titre({
		"id": "lame_parfaite",
		"nom": "Lame parfaite",
		"description": "Réussir 100 attaques critiques consécutives sans subir de dégâts. +10% dégâts avec les armes de mêlée.",
		"condition": {"type": "manuel"},  # streak sans dégât reçu -> géré par le combat, comme Massacreur
		"effets": [{"type": "degats_pourcent_melee", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "conquerant",
		"nom": "Conquérant",
		"description": "Atteindre plusieurs fois un étage élevé de la Tour. +5% dégâts dans la Tour.",
		"condition": {"type": "manuel"},  # "plusieurs fois" + "élevé" sont flous -> à trancher côté système de Tour puis debloquer_titre()
		"effets": [{"type": "degats_pourcent_dans_tour", "valeur": 5.0}],
	})

	_ajouter_titre({
		"id": "aventurier_de_la_tour",
		"nom": "Aventurier de la Tour",
		"description": "Découvrir 25 salles secrètes de la Tour. +5% résistance aux pièges dans la Tour.",
		"condition": {"type": "compteur", "action": "salle_secrete_tour", "quantite": 25},
		"effets": [{"type": "resistance_pieges_pourcent_dans_tour", "valeur": 5.0}],
	})

	_ajouter_titre({
		"id": "tueur_de_boss",
		"nom": "Tueur de Boss",
		"description": "Vaincre 10 boss. +10% dégâts contre les boss.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "boss", "quantite": 10},
		"effets": [{"type": "degats_pourcent_contre_cible", "cible": "boss", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "briseur_de_boss",
		"nom": "Briseur de Boss",
		"description": "Vaincre plusieurs boss ayant moins de 25% de leurs PV lors du coup final. +20% dégâts contre un boss sous ce seuil.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "boss", "quantite": 5, "contexte_requis": {"pv_bas": true}},
		"effets": [{"type": "degats_pourcent_contre_boss_pv_bas", "valeur": 20.0}],
	})

	_ajouter_titre({
		"id": "maudit",
		"nom": "Maudit",
		"description": "Découvrir et accepter une malédiction secrète. +10% dégâts, mais -5% défense.",
		"condition": {"type": "manuel"},  # choix ponctuel du joueur -> debloquer_titre() appelé au moment de l'acceptation
		"effets": [
			{"type": "degats_pourcent", "valeur": 10.0},
			{"type": "defense_pourcent", "valeur": -5.0},
		],
	})

	_ajouter_titre({
		"id": "chanceux",
		"nom": "Chanceux",
		"description": "Obtenir plusieurs objets extrêmement rares. +5% taux de drop.",
		"condition": {"type": "compteur", "action": "obtenir_objet_rare", "quantite": 5},
		"effets": [{"type": "taux_drop_pourcent", "valeur": 5.0}],
	})

	_ajouter_titre({
		"id": "miracule",
		"nom": "Miraculé",
		"description": "Survivre à une situation où une attaque aurait normalement tué le joueur. Petite chance d'éviter une attaque létale une fois par période.",
		"condition": {"type": "manuel"},  # -> le combat détecte le coup fatal évité et appelle debloquer_titre() directement
		"effets": [{"type": "comportemental"}],  # la chance d'esquive létale elle-même doit être gérée en direct par le combat, pas via bonus_generique
	})

	_ajouter_titre({
		"id": "stratege",
		"nom": "Stratège",
		"description": "Vaincre 100 ennemis après avoir découvert leurs informations dans le bestiaire. +10% efficacité contre les ennemis dont les résistances sont connues.",
		"condition": {"type": "compteur", "action": "tuer", "cible": "ennemi", "quantite": 100, "contexte_requis": {"bestiaire_connu": true}},
		"effets": [{"type": "degats_pourcent_contre_ennemi_connu", "valeur": 10.0}],
	})

	_ajouter_titre({
		"id": "chercheur_de_secrets",
		"nom": "Chercheur de secrets",
		"description": "Découvrir 20 secrets cachés. Les objets secrets émettent un indice sonore très discret à proximité.",
		"condition": {"type": "compteur", "action": "decouvrir_secret", "quantite": 20},
		"effets": [{"type": "comportemental"}],
	})

	_ajouter_titre({
		"id": "idiot",
		"nom": "Idiot",
		"description": "Réaliser une série d'actions volontairement absurdes. Aucun bonus. Certains PNJ réagissent différemment au joueur.",
		"condition": {"type": "manuel"},
		"effets": [{"type": "comportemental"}],
	})

	_ajouter_titre({
		"id": "rat_de_donjon",
		"nom": "Rat de donjon",
		"description": "Passer un nombre important d'heures cumulées dans les donjons. +15% ressources trouvées dans les donjons.",
		"condition": {"type": "compteur", "action": "heure_en_donjon", "quantite": 100},
		"effets": [{"type": "ressources_donjon_pourcent", "valeur": 15.0}],
	})

	_ajouter_titre({
		"id": "collectionneur",
		"nom": "Collectionneur",
		"description": "Obtenir un grand nombre d'objets différents. +5% chance de trouver des objets inhabituels.",
		"condition": {"type": "compteur", "action": "obtenir_objet_different", "quantite": 100},
		"effets": [{"type": "chance_objet_inhabituel_pourcent", "valeur": 5.0}],
	})

	_ajouter_titre({
		"id": "mort_vivant",
		"nom": "Mort-vivant",
		"description": "Découvrir une zone secrète liée aux morts. Certains effets de soin fonctionnent différemment.",
		"condition": {"type": "manuel"},
		"effets": [{"type": "comportemental"}],
	})
