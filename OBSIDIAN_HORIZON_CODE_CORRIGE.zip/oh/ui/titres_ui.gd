extends Control

# ==========================================================
#  OBSIDIAN HORIZON — UI de l'onglet Titres
#  Affiche les titres débloqués + les ??? pour les secrets.
# ==========================================================

var conteneur: VBoxContainer
var scroll: ScrollContainer


func _ready() -> void:
	_construire()
	# On se connecte au signal pour rafraîchir automatiquement
	if Titres:
		Titres.titre_debloque.connect(_on_titre_debloque)


func _construire() -> void:
	scroll = ScrollContainer.new()
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(scroll)

	conteneur = VBoxContainer.new()
	conteneur.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(conteneur)

	rafraichir()


func rafraichir() -> void:
	# Nettoyer
	for enfant in conteneur.get_children():
		enfant.queue_free()

	if not Titres:
		var label := Label.new()
		label.text = "Système de titres non chargé."
		conteneur.add_child(label)
		return

	var titres: Array = Titres.obtenir_titres_pour_affichage()

	# Tri : débloqués en premier
	titres.sort_custom(func(a, b): return a["debloque"] and not b["debloque"])

	for t in titres:
		var ligne := HBoxContainer.new()
		conteneur.add_child(ligne)

		var nom := Label.new()
		nom.text = t["nom"]
		nom.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		if t["debloque"]:
			nom.add_theme_color_override("font_color", Color(0.9, 0.75, 0.2))  # doré
		else:
			nom.add_theme_color_override("font_color", Color(0.5, 0.5, 0.5))
		ligne.add_child(nom)

		var desc := Label.new()
		desc.text = t["description"]
		desc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		if not t["debloque"]:
			desc.add_theme_color_override("font_color", Color(0.4, 0.4, 0.4))
		ligne.add_child(desc)

		# Progression si compteur et déjà découvert
		if t["debloque"] and Titres.catalogue_titres.has(t["id"]):
			var cond: Dictionary = Titres.catalogue_titres[t["id"]].get("condition", {})
			if cond.get("type") == "compteur":
				var prog := Titres.obtenir_progression(t["id"])
				var maxi: int = cond.get("quantite", 0)
				var label_prog := Label.new()
				label_prog.text = "(%d / %d)" % [prog, maxi]
				ligne.add_child(label_prog)


func _on_titre_debloque(_id: String) -> void:
	rafraichir()
