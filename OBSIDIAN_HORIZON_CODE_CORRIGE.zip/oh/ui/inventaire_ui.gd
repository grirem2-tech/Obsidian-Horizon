extends Control

# ==========================================================
#  OBSIDIAN HORIZON — Interface visuelle de l'inventaire
#  À attacher à un nœud Control racine (ex: InventaireUI.tscn).
#  Reproduit la structure de la maquette :
#    - Onglets en haut (Principal / Compétences / Titre / Bestiaire)
#    - Grille d'inventaire (8x5) à gauche
#    - Panneau personnage + slots d'équipement à droite
#    - Barre rapide (9 cases) en bas, liée au HUD
#    - Compteur d'or en bas à droite
#  Toute la mise en page est faite en code (pas de scène à designer à la
#  main) pour que tu puisses avancer sans DA finale ; à remplacer plus
#  tard par de vrais thèmes/textures.
# ==========================================================

const TAILLE_CASE: int = 64
const TAILLE_CASE_EQUIPEMENT: int = 56

## Ordre d'affichage des slots d'équipement, aligné sur la silhouette
## de la maquette (casque en haut, anneaux autour du torse, bottes en bas).
const ORDRE_SLOTS_EQUIPEMENT: Array[String] = [
	"casque", "collier",
	"anneau_1", "anneau_2", "anneau_3", "anneau_4",
	"plastron", "bouclier", "jambieres", "bottes",
]

var onglet_actif: String = "principal"

# Références aux nœuds construits dynamiquement
var conteneur_onglets: HBoxContainer
var panneau_principal: Control
var panneau_titres: Control  # instance de titres_ui.gd (voir Titres.tscn/.gd)
var grid_container: GridContainer
var boutons_slots: Array[Button] = []
var conteneur_barre_rapide: HBoxContainer
var boutons_barre_rapide: Array[Button] = []
var boutons_equipement: Dictionary = {}
var label_or: Label


func _ready() -> void:
	visible = false

	_construire_onglets()
	_construire_panneau_principal()
	_construire_panneau_titres()
	_construire_barre_rapide()
	_construire_affichage_or()

	Inventaire.etat_ouverture_change.connect(_on_etat_ouverture_change)
	Inventaire.inventaire_modifie.connect(_rafraichir_grille)
	Inventaire.barre_rapide_modifiee.connect(_rafraichir_barre_rapide)
	Inventaire.equipement_modifie.connect(_rafraichir_equipement)
	Inventaire.or_modifie.connect(_rafraichir_or)


# ----------------------------------------------------------
#  ONGLETS (Principal / Compétences / Titre / Bestiaire)
# ----------------------------------------------------------
## Seul l'onglet Principal est construit ici. Les trois autres affichent
## un panneau vide en attendant les systèmes correspondants (compétences,
## titres, bestiaire) : branche leurs propres UI sur _afficher_onglet().
func _construire_onglets() -> void:
	conteneur_onglets = HBoxContainer.new()
	add_child(conteneur_onglets)

	for nom_onglet in ["principal", "competences", "titre", "bestiaire"]:
		var bouton := Button.new()
		bouton.text = nom_onglet.capitalize()
		bouton.pressed.connect(_afficher_onglet.bind(nom_onglet))
		conteneur_onglets.add_child(bouton)


func _afficher_onglet(nom_onglet: String) -> void:
	onglet_actif = nom_onglet
	panneau_principal.visible = (nom_onglet == "principal")
	panneau_titres.visible = (nom_onglet == "titre")
	if nom_onglet == "titre":
		panneau_titres.rafraichir()
	# TODO : afficher/masquer les panneaux Compétences / Bestiaire une fois
	# ces systèmes créés (même logique que panneau_principal/panneau_titres).


## Instancie le panneau de l'onglet Titre (titres_ui.gd). Adapte le chemin
## ci-dessous à l'emplacement réel du script dans ton projet, ou glisse
## directement une scène TitresUI.tscn préconfigurée si tu préfères.
func _construire_panneau_titres() -> void:
	# Adapte le chemin selon l'emplacement réel dans ton projet
	var script_titres = load("res://scripts/titres_ui.gd")
	if script_titres == null:
		script_titres = load("res://titres_ui.gd")
	panneau_titres = Control.new()
	if script_titres:
		panneau_titres.set_script(script_titres)
	panneau_titres.visible = false
	add_child(panneau_titres)


# ----------------------------------------------------------
#  PANNEAU PRINCIPAL (grille + équipement)
# ----------------------------------------------------------
func _construire_panneau_principal() -> void:
	panneau_principal = HBoxContainer.new()
	add_child(panneau_principal)

	# --- Grille d'inventaire (8 colonnes x 5 lignes) ---
	grid_container = GridContainer.new()
	grid_container.columns = Inventaire.NB_COLONNES
	panneau_principal.add_child(grid_container)

	for i in range(Inventaire.TAILLE_TOTALE):
		var bouton := Button.new()
		bouton.custom_minimum_size = Vector2(TAILLE_CASE, TAILLE_CASE)
		bouton.pressed.connect(_on_slot_grille_presse.bind(i))
		grid_container.add_child(bouton)
		boutons_slots.append(bouton)

	# --- Panneau équipement (silhouette du personnage) ---
	var conteneur_equipement := GridContainer.new()
	conteneur_equipement.columns = 2
	panneau_principal.add_child(conteneur_equipement)

	for slot in ORDRE_SLOTS_EQUIPEMENT:
		var bouton := Button.new()
		bouton.custom_minimum_size = Vector2(TAILLE_CASE_EQUIPEMENT, TAILLE_CASE_EQUIPEMENT)
		bouton.text = slot.capitalize()
		bouton.pressed.connect(_on_slot_equipement_presse.bind(slot))
		conteneur_equipement.add_child(bouton)
		boutons_equipement[slot] = bouton


# ----------------------------------------------------------
#  BARRE RAPIDE (séparée de la grille, sous le panneau principal)
# ----------------------------------------------------------
func _construire_barre_rapide() -> void:
	conteneur_barre_rapide = HBoxContainer.new()
	add_child(conteneur_barre_rapide)

	for i in range(Inventaire.TAILLE_BARRE_RAPIDE):
		var bouton := Button.new()
		bouton.custom_minimum_size = Vector2(TAILLE_CASE, TAILLE_CASE)
		bouton.text = str(i + 1)  # numéros 1 à 9 visibles sur la maquette
		bouton.pressed.connect(_on_slot_barre_rapide_presse.bind(i))
		conteneur_barre_rapide.add_child(bouton)
		boutons_barre_rapide.append(bouton)


# ----------------------------------------------------------
#  OR
# ----------------------------------------------------------
func _construire_affichage_or() -> void:
	label_or = Label.new()
	add_child(label_or)
	_rafraichir_or()


# ----------------------------------------------------------
#  RAFRAÎCHISSEMENT DE L'AFFICHAGE
# ----------------------------------------------------------
func _rafraichir_grille() -> void:
	for i in range(Inventaire.TAILLE_TOTALE):
		_rafraichir_bouton_case(boutons_slots[i], Inventaire.slots[i])


func _rafraichir_barre_rapide() -> void:
	for i in range(Inventaire.TAILLE_BARRE_RAPIDE):
		var case_actuelle = Inventaire.barre_rapide[i]
		if case_actuelle == null:
			boutons_barre_rapide[i].text = str(i + 1)
		else:
			var objet: Dictionary = case_actuelle["objet"]
			boutons_barre_rapide[i].text = "%s\nx%d" % [objet.get("nom", "?"), case_actuelle["quantite"]]


func _rafraichir_equipement() -> void:
	for slot in ORDRE_SLOTS_EQUIPEMENT:
		var objet = Inventaire.equipement[slot]
		var bouton: Button = boutons_equipement[slot]
		bouton.text = objet.get("nom", "?") if objet != null else slot.capitalize()


func _rafraichir_or() -> void:
	label_or.text = "Or : %d" % Inventaire.or_actuel


func _rafraichir_bouton_case(bouton: Button, case_actuelle) -> void:
	if case_actuelle == null:
		bouton.text = ""
		bouton.tooltip_text = ""
	else:
		var objet: Dictionary = case_actuelle["objet"]
		bouton.text = "%s\nx%d" % [objet.get("nom", "?"), case_actuelle["quantite"]]
		bouton.tooltip_text = objet.get("nom", "?")


# ----------------------------------------------------------
#  OUVERTURE / FERMETURE
# ----------------------------------------------------------
func _on_etat_ouverture_change(est_ouvert: bool) -> void:
	visible = est_ouvert
	if est_ouvert:
		_rafraichir_grille()
		_rafraichir_barre_rapide()
		_rafraichir_equipement()
		_rafraichir_or()


# ----------------------------------------------------------
#  INTERACTIONS (points d'entrée à étoffer : drag & drop, clic droit, etc.)
# ----------------------------------------------------------
func _on_slot_grille_presse(index: int) -> void:
	var case_actuelle = Inventaire.slots[index]
	if case_actuelle != null:
		print("Case grille cliquée %d : %s" % [index, case_actuelle["objet"].get("nom", "?")])


func _on_slot_barre_rapide_presse(index: int) -> void:
	var case_actuelle = Inventaire.barre_rapide[index]
	if case_actuelle != null:
		print("Case barre rapide cliquée %d : %s" % [index, case_actuelle["objet"].get("nom", "?")])


func _on_slot_equipement_presse(slot: String) -> void:
	var objet = Inventaire.equipement[slot]
	if objet != null:
		print("Slot équipement '%s' cliqué : %s" % [slot, objet.get("nom", "?")])
