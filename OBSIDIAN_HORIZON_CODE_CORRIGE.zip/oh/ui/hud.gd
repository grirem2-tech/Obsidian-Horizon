extends CanvasLayer

# ==========================================================
#  OBSIDIAN HORIZON — HUD minimal (PV / PM / or / info)
#  Style discret, ne surcharge pas l'écran.
# ==========================================================

var barre_pv: ProgressBar
var barre_pm: ProgressBar
var label_or: Label
var label_info: Label
var joueur: Node = null


func _ready() -> void:
	layer = 10
	_construire()
	await get_tree().process_frame
	joueur = get_tree().get_first_node_in_group("joueur")


func _construire() -> void:
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	# --- Barres bas-gauche ---
	var conteneur := VBoxContainer.new()
	conteneur.position = Vector2(24, 24)
	conteneur.custom_minimum_size = Vector2(220, 0)
	root.add_child(conteneur)

	barre_pv = ProgressBar.new()
	barre_pv.custom_minimum_size = Vector2(220, 18)
	barre_pv.max_value = 100
	barre_pv.value = 100
	barre_pv.show_percentage = false
	barre_pv.modulate = Color(0.9, 0.25, 0.25)
	conteneur.add_child(barre_pv)

	var label_pv := Label.new()
	label_pv.name = "LabelPV"
	label_pv.text = "PV"
	label_pv.add_theme_font_size_override("font_size", 12)
	conteneur.add_child(label_pv)

	barre_pm = ProgressBar.new()
	barre_pm.custom_minimum_size = Vector2(220, 14)
	barre_pm.max_value = 50
	barre_pm.value = 50
	barre_pm.show_percentage = false
	barre_pm.modulate = Color(0.3, 0.5, 0.95)
	conteneur.add_child(barre_pm)

	# --- Or bas-droite ---
	label_or = Label.new()
	label_or.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	label_or.position = Vector2(-180, -48)
	label_or.text = "Or : 0"
	label_or.add_theme_font_size_override("font_size", 18)
	root.add_child(label_or)

	# --- Info centre-bas (interaction) ---
	label_info = Label.new()
	label_info.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	label_info.position = Vector2(-100, -80)
	label_info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label_info.text = ""
	label_info.add_theme_font_size_override("font_size", 14)
	root.add_child(label_info)


func _process(_delta: float) -> void:
	if joueur == null:
		joueur = get_tree().get_first_node_in_group("joueur")
		return

	if "PV_actuels" in joueur:
		barre_pv.max_value = joueur.PV_max
		barre_pv.value = joueur.PV_actuels
		var lp := barre_pv.get_parent().get_node_or_null("LabelPV")
		if lp:
			lp.text = "PV  %d / %d" % [int(joueur.PV_actuels), int(joueur.PV_max)]

	if "PM_actuels" in joueur:
		barre_pm.max_value = joueur.PM_max
		barre_pm.value = joueur.PM_actuels

	if Inventaire:
		label_or.text = "Or : %d" % Inventaire.or_actuel
