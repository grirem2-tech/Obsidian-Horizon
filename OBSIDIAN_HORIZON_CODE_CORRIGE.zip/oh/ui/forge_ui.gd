extends Control

# ==========================================================
#  OBSIDIAN HORIZON — Interface de Forge (choix guidés)
#  Étapes : Catégorie → Type → Principal → Secondaire → Forger
# ==========================================================

signal fermer_demande

var etape: int = 0  # 0 cat, 1 type, 2 principal, 3 secondaire, 4 résumé

var categorie_choisie: String = ""
var type_choisi: String = ""
var principal_choisi: String = ""
var secondaire_choisi: String = ""

var conteneur: VBoxContainer
var label_titre: Label
var label_chance: Label
var conteneur_choix: VBoxContainer
var bouton_retour: Button
var bouton_forger: Button
var label_resultat: Label

var joueur: Node = null


func _ready() -> void:
	visible = false
	_construire()
	joueur = get_tree().get_first_node_in_group("joueur")


func ouvrir() -> void:
	visible = true
	etape = 0
	categorie_choisie = ""
	type_choisi = ""
	principal_choisi = ""
	secondaire_choisi = ""
	label_resultat.text = ""
	_rafraichir()


func fermer() -> void:
	visible = false
	fermer_demande.emit()


func _construire() -> void:
	set_anchors_preset(Control.PRESET_CENTER)
	custom_minimum_size = Vector2(480, 520)

	var fond := Panel.new()
	fond.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(fond)

	conteneur = VBoxContainer.new()
	conteneur.set_anchors_preset(Control.PRESET_FULL_RECT)
	conteneur.add_theme_constant_override("separation", 8)
	add_child(conteneur)

	label_titre = Label.new()
	label_titre.text = "Forge"
	label_titre.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label_titre.add_theme_font_size_override("font_size", 22)
	conteneur.add_child(label_titre)

	label_chance = Label.new()
	label_chance.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	conteneur.add_child(label_chance)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.custom_minimum_size = Vector2(0, 280)
	conteneur.add_child(scroll)

	conteneur_choix = VBoxContainer.new()
	conteneur_choix.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(conteneur_choix)

	label_resultat = Label.new()
	label_resultat.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label_resultat.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	conteneur.add_child(label_resultat)

	var ligne_boutons := HBoxContainer.new()
	conteneur.add_child(ligne_boutons)

	bouton_retour = Button.new()
	bouton_retour.text = "Retour"
	bouton_retour.pressed.connect(_on_retour)
	ligne_boutons.add_child(bouton_retour)

	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ligne_boutons.add_child(spacer)

	bouton_forger = Button.new()
	bouton_forger.text = "Forger"
	bouton_forger.pressed.connect(_on_forger)
	ligne_boutons.add_child(bouton_forger)

	var bouton_fermer := Button.new()
	bouton_fermer.text = "Fermer"
	bouton_fermer.pressed.connect(fermer)
	ligne_boutons.add_child(bouton_fermer)


func _rafraichir() -> void:
	for c in conteneur_choix.get_children():
		c.queue_free()

	bouton_forger.disabled = true
	label_chance.text = ""

	match etape:
		0:
			label_titre.text = "Forge — Choisir une catégorie"
			for cat in Forge.obtenir_categories():
				var def = Forge.CATEGORIES[cat]
				_ajouter_bouton_choix(def["nom"], _choisir_categorie.bind(cat))
		1:
			label_titre.text = "Forge — Type de pièce (%s)" % Forge.CATEGORIES[categorie_choisie]["nom"]
			for t in Forge.obtenir_types(categorie_choisie):
				var def = Forge.CATEGORIES[categorie_choisie]["types"][t]
				_ajouter_bouton_choix(def["nom"], _choisir_type.bind(t))
		2:
			label_titre.text = "Forge — Matériau principal"
			for mat in Forge.obtenir_materiaux_principaux_disponibles():
				var txt := "%s (×%d) · T%d · +%d RNG" % [
					mat["nom"], mat["quantite_requise"], mat["tier"], mat.get("nb_effets_rng", 0)
				]
				var eg: String = str(mat.get("effet_garanti_desc", "Aucun"))
				if eg != "Aucun":
					txt += " | Garanti : %s" % eg
				if not mat["disponible"]:
					txt += "  [manque]"
				var btn := _ajouter_bouton_choix(txt, _choisir_principal.bind(mat["id"]))
				btn.disabled = not mat["disponible"]
		3:
			label_titre.text = "Forge — Matériau secondaire (drop)"
			for mat in Forge.obtenir_materiaux_secondaires_disponibles():
				var tags: String = ", ".join(mat.get("tags", []))
				var txt := "%s  [%s]" % [mat["nom"], tags]
				if not mat["disponible"]:
					txt += "  [manque]"
				var btn := _ajouter_bouton_choix(txt, _choisir_secondaire.bind(mat["id"]))
				btn.disabled = not mat["disponible"]
		4:
			label_titre.text = "Forge — Confirmer"
			var resume := "Catégorie : %s\nPièce : %s\nPrincipal : %s\nSecondaire : %s" % [
				categorie_choisie, type_choisi, principal_choisi, secondaire_choisi
			]
			var lbl := Label.new()
			lbl.text = resume
			lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
			conteneur_choix.add_child(lbl)

			if joueur == null:
				joueur = get_tree().get_first_node_in_group("joueur")
			var chance := Forge.calculer_chance_reussite(joueur, principal_choisi)
			label_chance.text = "Chance de réussite : %d %%" % int(chance)
			bouton_forger.disabled = false


func _ajouter_bouton_choix(texte: String, callable: Callable) -> Button:
	var btn := Button.new()
	btn.text = texte
	btn.pressed.connect(callable)
	conteneur_choix.add_child(btn)
	return btn


func _choisir_categorie(cat: String) -> void:
	categorie_choisie = cat
	etape = 1
	_rafraichir()


func _choisir_type(t: String) -> void:
	type_choisi = t
	etape = 2
	_rafraichir()


func _choisir_principal(id: String) -> void:
	principal_choisi = id
	etape = 3
	_rafraichir()


func _choisir_secondaire(id: String) -> void:
	secondaire_choisi = id
	etape = 4
	_rafraichir()


func _on_retour() -> void:
	if etape <= 0:
		fermer()
		return
	etape -= 1
	label_resultat.text = ""
	_rafraichir()


func _on_forger() -> void:
	if joueur == null:
		joueur = get_tree().get_first_node_in_group("joueur")

	var objet := Forge.forger(
		categorie_choisie,
		type_choisi,
		principal_choisi,
		secondaire_choisi,
		joueur
	)

	if objet.is_empty():
		label_resultat.text = "Échec de la forge…"
		label_resultat.modulate = Color(1.0, 0.4, 0.4)
	else:
		label_resultat.text = "Succès !\n%s\n%s" % [objet.get("nom", "?"), objet.get("description", "")]
		label_resultat.modulate = Color(0.5, 1.0, 0.5)
		# Reset pour enchaîner
		etape = 0
		categorie_choisie = ""
		type_choisi = ""
		principal_choisi = ""
		secondaire_choisi = ""
		_rafraichir()
